import React, { useState, useEffect } from 'react';
import {
  Brain,
  Star,
  CheckCircle2,
  ArrowRight,
  Send,
  FileDown,
} from 'lucide-react';
import { Mission, StudentReflectionSubmission } from '../../types';
import { storage } from '../../services/storage';
import { exportRefleksiToPdf } from '../../utils/pdfExport';
import { exportRefleksiToExcel } from '../../utils/excelExport';
import { ExportDropdown } from '../common/ExportDropdown';
import headerScienceImg from '../../assets/images/misi_header_science_1791603210843.jpg';

interface Misi5RefleksiProps {
  studentId: string;
  studentName?: string;
  classId?: string;
  className?: string;
  missionId: string;
  mission?: Mission;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose?: () => void;
}

// 7 Aspek Rubrik Penilaian Diri Sendiri (Baku & Selaras Guru/Murid)
const DEFAULT_7_RUBRIC_ASPECTS = [
  { id: 'kemandirian', label: '1. Kemandirian', desc: 'Inisiatif, kedisiplinan dan belajar tanpa bergantung penuh pada orang lain' },
  { id: 'keaktifan', label: '2. Keaktifan Belajar', desc: 'Antusiasme bertanya, mencoba simulasi, dan berpartisipasi aktif' },
  { id: 'pemahaman', label: '2. Pemahaman Konsep & Penalaran Ilmiah', desc: 'Kedalaman pemahaman teori dan penalaran prinsip saintifik' },
  { id: 'pemecahan_masalah', label: '3. Keterampilan Pemecahan Masalah', desc: 'Kemampuan menganalisis data, merumuskan hipotesis, dan memecahkan persoalan' },
  { id: 'sikap_kritis', label: '4. Sikap Kritis dan Teliti', desc: 'Kecermatan observasi, verifikasi data, dan ketelitian penarikan kesimpulan' },
  { id: 'kerjasama', label: '5. Kerjasama dalam Kelompok', desc: 'Kolaborasi yang saling menghargai dan berkontribusi dalam tim' },
  { id: 'tanggung_jawab', label: '6. Bertanggung Jawab', desc: 'Integritas akademik, ketuntasan tugas, dan komitmen belajar' },
];

// Pertanyaan Baku Guru (Mode Online Fallback)
const DEFAULT_TEACHER_QUESTIONS = {
  q1: 'Konsep sains apa yang paling bermakna dan paling Anda pahami setelah menyelesaikan misi pembelajaran ini?',
  q2: 'Apa kendala atau kesulitan terbesar yang Anda hadapi saat belajar, dan bagaimana strategi Anda mengatasinya?',
  q3: 'Bagaimana konsep yang dipelajari dapat diterapkan dalam kehidupan nyata, teknologi, atau penyelidikan sains?',
  q4: 'Apa rencana tindak lanjut atau target pengembangan diri Anda untuk meningkatkan pemahaman materi selanjutnya?',
};

export const Misi5Refleksi: React.FC<Misi5RefleksiProps> = ({
  studentId,
  studentName = 'Murid TI SENANG',
  classId = 'cls-xii-1',
  className = 'XII-1',
  missionId,
  mission,
  onCompleted,
  onNextMission,
  onClose,
}) => {
  // Menu Tab: Online vs Offline (terletak di header di bawah judul)
  const [activeMenu, setActiveMenu] = useState<'online' | 'offline'>('online');

  // Existing online submission if any
  const existingSubmissions = storage.getStudentReflections(classId, studentId);
  const existing = existingSubmissions.find((r) => r.missionId === missionId);

  // --- STATE MENU ONLINE (TERKONEKSI GURU, 7 ASPEK PENILAIAN DIRI) ---
  const [teacherQuestions, setTeacherQuestions] = useState(DEFAULT_TEACHER_QUESTIONS);
  const [teacherRubrics, setTeacherRubrics] = useState(DEFAULT_7_RUBRIC_ASPECTS);

  const [onlineAns1, setOnlineAns1] = useState<string>(existing?.refleksiAnswers?.[0] || '');
  const [onlineAns2, setOnlineAns2] = useState<string>(existing?.refleksiAnswers?.[1] || '');
  const [onlineAns3, setOnlineAns3] = useState<string>(existing?.refleksiAnswers?.[2] || '');
  const [onlineAns4, setOnlineAns4] = useState<string>(existing?.refleksiAnswers?.[3] || '');

  const [onlineScores, setOnlineScores] = useState<number[]>([
    existing?.selfAssessment?.kemandirian || 4,
    existing?.selfAssessment?.keaktifan || 4,
    existing?.selfAssessment?.pemahamanKonsep || 3,
    existing?.selfAssessment?.keterampilanAnalisis || existing?.selfAssessment?.keterampilanData || 3,
    existing?.selfAssessment?.sikapKritis || 4,
    existing?.selfAssessment?.kerjasama || 4,
    existing?.selfAssessment?.tanggungJawab || 4,
  ]);

  const [onlineKomitmen, setOnlineKomitmen] = useState<string>(
    existing?.selfAssessment?.komitmenDiri || existing?.selfAssessment?.komitmen || '',
  );

  const [isOnlineSubmitted, setIsOnlineSubmitted] = useState<boolean>(!!existing);
  const [isSubmittingOnline, setIsSubmittingOnline] = useState<boolean>(false);

  // --- STATE MENU OFFLINE (LEMBAR MANDIRI & SIMPAN PDF) ---
  const offlineStorageKey = `ti_senang_refleksi_offline_${studentId}_${missionId}`;
  const savedOfflineDraft = (() => {
    try {
      const raw = localStorage.getItem(offlineStorageKey);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  })();

  const [offlineAns1, setOfflineAns1] = useState<string>(savedOfflineDraft?.ans1 || '');
  const [offlineAns2, setOfflineAns2] = useState<string>(savedOfflineDraft?.ans2 || '');
  const [offlineAns3, setOfflineAns3] = useState<string>(savedOfflineDraft?.ans3 || '');
  const [offlineAns4, setOfflineAns4] = useState<string>(savedOfflineDraft?.ans4 || '');

  const [offlineScores, setOfflineScores] = useState<number[]>(
    savedOfflineDraft?.scores || [4, 4, 3, 3, 4, 4, 4],
  );
  const [offlineKomitmen, setOfflineKomitmen] = useState<string>(
    savedOfflineDraft?.komitmen || '',
  );
  const [offlineSavedMessage, setOfflineSavedMessage] = useState<string | null>(null);

  // Load konfigurasi pertanyaan & 7 rubrik dari Guru (Sinkronisasi Online)
  useEffect(() => {
    const loadTeacherConfig = () => {
      // 1. Cek dari payload mission jika guru menyimpannya di mission
      if (mission?.reflectionPrompt) {
        try {
          const parsed = JSON.parse(mission.reflectionPrompt);
          if (parsed.questions) {
            setTeacherQuestions({
              q1: parsed.questions.q1 || DEFAULT_TEACHER_QUESTIONS.q1,
              q2: parsed.questions.q2 || DEFAULT_TEACHER_QUESTIONS.q2,
              q3: parsed.questions.q3 || DEFAULT_TEACHER_QUESTIONS.q3,
              q4: parsed.questions.q4 || DEFAULT_TEACHER_QUESTIONS.q4,
            });
          } else if (parsed.q1) {
            setTeacherQuestions({
              q1: parsed.q1 || DEFAULT_TEACHER_QUESTIONS.q1,
              q2: parsed.q2 || DEFAULT_TEACHER_QUESTIONS.q2,
              q3: parsed.q3 || DEFAULT_TEACHER_QUESTIONS.q3,
              q4: parsed.q4 || DEFAULT_TEACHER_QUESTIONS.q4,
            });
          }
          if (Array.isArray(parsed.rubrics) && parsed.rubrics.length > 0) {
            setTeacherRubrics(parsed.rubrics);
            return;
          }
        } catch {
          // fallback ke storage helper
        }
      }

      // 2. Cek dari storage teacher reflection config
      const teacherConfig = storage.getTeacherReflectionConfig(classId, missionId);
      if (teacherConfig) {
        if (teacherConfig.questions) {
          setTeacherQuestions({
            q1: teacherConfig.questions.q1 || DEFAULT_TEACHER_QUESTIONS.q1,
            q2: teacherConfig.questions.q2 || DEFAULT_TEACHER_QUESTIONS.q2,
            q3: teacherConfig.questions.q3 || DEFAULT_TEACHER_QUESTIONS.q3,
            q4: teacherConfig.questions.q4 || DEFAULT_TEACHER_QUESTIONS.q4,
          });
        }
        if (Array.isArray(teacherConfig.rubrics) && teacherConfig.rubrics.length > 0) {
          setTeacherRubrics(teacherConfig.rubrics);
        }
      }
    };

    loadTeacherConfig();

    const handleUpdate = () => {
      loadTeacherConfig();
    };

    window.addEventListener('tisenang_teacher_refleksi_config_updated', handleUpdate);
    return () => {
      window.removeEventListener('tisenang_teacher_refleksi_config_updated', handleUpdate);
    };
  }, [classId, missionId, mission]);

  // Hitung rata-rata skor Online (%) berdasarkan 7 aspek
  const totalOnlineMax = (teacherRubrics.length || 7) * 4;
  const currentOnlineTotal = onlineScores.reduce((a, b) => a + b, 0);
  const onlineScoreAverage = Math.round((currentOnlineTotal / (totalOnlineMax || 28)) * 100);

  // Hitung rata-rata skor Offline (%) berdasarkan 7 aspek
  const offlineScoreAverage = Math.round(
    (offlineScores.reduce((a, b) => a + b, 0) / (DEFAULT_7_RUBRIC_ASPECTS.length * 4)) * 100,
  );

  // Simpan draft offline ke localStorage secara berkala
  useEffect(() => {
    try {
      localStorage.setItem(
        offlineStorageKey,
        JSON.stringify({
          ans1: offlineAns1,
          ans2: offlineAns2,
          ans3: offlineAns3,
          ans4: offlineAns4,
          scores: offlineScores,
          komitmen: offlineKomitmen,
        }),
      );
    } catch {
      // ignore
    }
  }, [offlineAns1, offlineAns2, offlineAns3, offlineAns4, offlineScores, offlineKomitmen, offlineStorageKey]);

  // --- HANDLER MENU ONLINE: KIRIM REFLEKSI ---
  const handleKirimRefleksiOnline = (e: React.FormEvent) => {
    e.preventDefault();

    if (!onlineAns1.trim() || !onlineAns2.trim()) {
      alert('Mohon jawab minimal pertanyaan refleksi 1 dan 2 sebelum mengirim ke guru.');
      return;
    }

    setIsSubmittingOnline(true);
    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();

    const submission: StudentReflectionSubmission = {
      id: existing?.id || `refl-${Date.now()}`,
      studentId,
      studentName: cleanStudentName,
      classId,
      className,
      missionId,
      missionTitle: mission?.title || 'Refleksi & Penilaian Diri',
      submittedAt: new Date().toISOString(),
      reflectionAnswers: {
        pemahaman: onlineAns1.trim(),
        tantangan: onlineAns2.trim(),
        halMenarik: onlineAns3.trim(),
        rencanaPerbaikan: onlineAns4.trim(),
      },
      refleksiAnswers: [
        onlineAns1.trim(),
        onlineAns2.trim(),
        onlineAns3.trim() || 'Memahami keterkaitan konsep sains dengan fenomena sehari-hari.',
        onlineAns4.trim() || 'Berkomitmen untuk terus belajar mandiri dan berefleksi kritis.',
      ],
      selfAssessment: {
        kemandirian: onlineScores[0] || 4,
        keaktifan: onlineScores[1] || 4,
        pemahamanKonsep: onlineScores[2] || 3,
        keterampilanAnalisis: onlineScores[3] || 3,
        sikapReflektif: onlineScores[4] || 4,
        keterampilanData: onlineScores[3] || 3,
        sikapKritis: onlineScores[4] || 4,
        kerjasama: onlineScores[5] || 4,
        tanggungJawab: onlineScores[6] || 4,
        totalScorePercentage: onlineScoreAverage,
        komitmen: onlineKomitmen.trim() || 'Berkomitmen untuk belajar mandiri dan berintegritas.',
        komitmenDiri: onlineKomitmen.trim() || 'Berkomitmen untuk belajar mandiri dan berintegritas.',
      },
      averageSelfScore: onlineScoreAverage,
      teacherFeedback: existing?.teacherFeedback || '',
      mode: 'online',
    };

    // 1. Simpan ke storage dan sinkronisasi ke review guru
    storage.saveStudentReflection(submission);

    // 2. Tandai Misi 5 selesai & buka Misi 6
    storage.completeMission(studentId, missionId, onlineScoreAverage, mission?.xpReward || 110);

    setIsSubmittingOnline(false);
    setIsOnlineSubmitted(true);

    if (onCompleted) {
      onCompleted();
    }
  };

  // --- HANDLER MENU OFFLINE: SIMPAN PDF ---
  const handleSimpanPdfOffline = () => {
    if (!offlineAns1.trim() && !offlineAns2.trim() && !offlineAns3.trim()) {
      alert('Mohon isi catatan refleksi pembelajaran Anda sebelum menyimpan dokumen PDF.');
      return;
    }

    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();

    // Custom Rubrics untuk 7 Aspek Offline
    const customRubrics = DEFAULT_7_RUBRIC_ASPECTS.map((asp, idx) => ({
      label: asp.label,
      val: offlineScores[idx] || 4,
    }));

    // Custom Questions untuk 4 Pertanyaan Offline
    const customQuestions = [
      {
        q: '1. Konsep apa yang paling Anda pahami dengan jelas pada pembelajaran ini?',
        a: offlineAns1.trim() || 'Memahami konsep esensial dengan baik.',
      },
      {
        q: '2. Apa kendala terbesar yang Anda hadapi saat pembelajaran dan bagaimana Anda mengatasinya?',
        a: offlineAns2.trim() || 'Menyelesaikan kendala belajar secara mandiri dan reflektif.',
      },
      {
        q: '3. Bagaimana perasaan saya selama mengikuti pembelajaran hari ini?',
        a: offlineAns3.trim() || 'Merasa termotivasi dan antusias dalam belajar.',
      },
      {
        q: '4. Apa rencana aksi/perbaikan diri Anda untuk materi pembelajaran berikutnya?',
        a: offlineAns4.trim() || 'Meningkatkan kedisiplinan dan literasi saintifik.',
      },
    ];

    // Ekspor ke PDF dengan format khusus Offline
    exportRefleksiToPdf({
      studentName: cleanStudentName,
      className,
      subjectName: mission?.subjectName || 'Fisika & Sains Terapan',
      teacherName: 'Guru Pengampu MIPA',
      missionTitle: 'Misi 5 • Lembar Refleksi & Penilaian Diri (Offline)',
      submittedAt: new Date().toISOString(),
      isOffline: true,
      customRubrics,
      customQuestions,
      komitmen: offlineKomitmen.trim() || 'Berkomitmen untuk terus aktif, disiplin, dan bertanggung jawab.',
      selfAssessment: {
        totalScorePercentage: offlineScoreAverage,
      },
    });

    // Simpan juga status progres agar membuka Misi 6
    storage.completeMission(studentId, missionId, offlineScoreAverage, mission?.xpReward || 110);
    setOfflineSavedMessage('Dokumen PDF lembar refleksi offline berhasil diunduh dan tersimpan!');
    setTimeout(() => {
      setOfflineSavedMessage(null);
    }, 6000);

    if (onCompleted) {
      onCompleted();
    }
  };

  const handleDownloadOnlinePdf = () => {
    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    exportRefleksiToPdf({
      studentName: cleanStudentName,
      className,
      subjectName: mission?.subjectName || 'Fisika & Literasi Sains',
      teacherName: 'Guru Pengampu MIPA',
      missionTitle: mission?.title || 'Refleksi Pembelajaran (Online)',
      submittedAt: existing?.submittedAt || new Date().toISOString(),
      customQuestions: [
        { q: `1. ${teacherQuestions.q1}`, a: onlineAns1 },
        { q: `2. ${teacherQuestions.q2}`, a: onlineAns2 },
        { q: `3. ${teacherQuestions.q3}`, a: onlineAns3 },
        { q: `4. ${teacherQuestions.q4}`, a: onlineAns4 },
      ],
      customRubrics: teacherRubrics.map((r, i) => ({
        label: r.label,
        val: onlineScores[i] || 4,
      })),
      komitmen: onlineKomitmen,
      selfAssessment: {
        totalScorePercentage: onlineScoreAverage,
      },
    });
  };

  const handleDownloadOnlineExcel = () => {
    const cleanStudentName = (studentName || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    exportRefleksiToExcel({
      studentName: cleanStudentName,
      className,
      subjectName: mission?.subjectName || 'Fisika & Literasi Sains',
      missionTitle: mission?.title || 'Refleksi Pembelajaran (Online)',
      submittedAt: existing?.submittedAt || new Date().toISOString(),
      reflectionAnswers: {
        pemahaman: onlineAns1,
        tantangan: onlineAns2,
        halMenarik: onlineAns3,
        rencanaPerbaikan: onlineAns4,
      },
      selfAssessment: {
        kemandirian: onlineScores[0] || 4,
        pemahamanKonsep: onlineScores[2] || 3,
        keterampilanAnalisis: onlineScores[3] || 3,
        sikapReflektif: onlineScores[4] || 4,
        totalScorePercentage: onlineScoreAverage,
        komitmen: onlineKomitmen,
      },
    });
  };

  const renderRatingStars = (
    value: number,
    onChange: (val: number) => void,
    label: string,
    desc?: string,
    disabled = false,
  ) => {
    const starLabels = ['Perlu Bimbingan', 'Cukup', 'Baik / Aktif', 'Sangat Baik / Mandiri'];
    return (
      <div className="p-3 sm:p-3.5 rounded-2xl bg-slate-50 border border-slate-200/90 space-y-1.5 transition-all hover:border-purple-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
          <label className="text-xs font-bold text-slate-800">{label}</label>
          <span className="text-[10px] sm:text-[11px] font-semibold text-purple-700">
            {starLabels[value - 1] || 'Baik'}
          </span>
        </div>
        {desc && <p className="text-[10px] text-slate-500 line-clamp-1">{desc}</p>}
        <div className="flex items-center gap-1.5 pt-0.5">
          {[1, 2, 3, 4].map((star) => (
            <button
              key={star}
              type="button"
              disabled={disabled}
              onClick={() => onChange(star)}
              className={`p-1 rounded-xl transition-all cursor-pointer ${
                star <= value
                  ? 'text-amber-500 hover:scale-110'
                  : 'text-slate-300 hover:text-amber-300'
              }`}
            >
              <Star className="w-5 h-5" fill={star <= value ? 'currentColor' : 'none'} />
            </button>
          ))}
          <span className="text-xs font-mono font-bold text-slate-600 ml-1">
            {value} / 4
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6 w-full min-w-0 pb-12 sm:pb-8">
      {/* Header Banner - Menu Online dan Offline terletak di header di bawah judul seperti Misi 1 */}
      <div className="bg-slate-950 rounded-2xl sm:rounded-3xl p-4 sm:p-6 text-white shadow-xl relative overflow-hidden border border-purple-400/40">
        {/* Background Gambar Sains Neon Kosmik */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <img
            src={headerScienceImg}
            alt="Header Misi 5 Refleksi Pembelajaran"
            className="w-full h-full object-cover object-center opacity-45 mix-blend-screen scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-purple-950/90 via-slate-950/80 to-blue-950/75" />
        </div>
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-start justify-between gap-3 sm:gap-4">
          <div className="min-w-0 flex-1">
            {/* Badge Misi 5 */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
              <Brain className="w-3.5 h-3.5 shrink-0" />
              <span>Misi 5 • Refleksi Pembelajaran</span>
            </div>

            {/* Tulisan Judul */}
            <h1 className="text-xl sm:text-2xl md:text-3xl font-display font-extrabold tracking-tight">
              Refleksi Pembelajaran dan Penilaian Diri
            </h1>

            {/* Menu Online dan Offline terletak di header di bawah tulisan Refleksi Pembelajaran dan Penilaian Diri seperti pada Misi 1 */}
            <div className="flex items-center p-1 bg-black/30 backdrop-blur-md rounded-xl border border-white/25 shadow-xs my-2.5 w-fit">
              <button
                type="button"
                onClick={() => setActiveMenu('online')}
                className={`px-3.5 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer text-center ${
                  activeMenu === 'online'
                    ? 'bg-white text-purple-900 shadow-md font-extrabold'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                Online
              </button>
              <button
                type="button"
                onClick={() => setActiveMenu('offline')}
                className={`px-3.5 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-bold transition-all cursor-pointer text-center ${
                  activeMenu === 'offline'
                    ? 'bg-white text-purple-900 shadow-md font-extrabold'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                Offline
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 shrink-0">
            <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white shrink-0">
              +{mission?.xpReward || 110} XP
            </span>
            {isOnlineSubmitted && (
              <ExportDropdown
                onExportPdf={handleDownloadOnlinePdf}
                onExportExcel={handleDownloadOnlineExcel}
                label="Unduh Refleksi"
                theme="light"
              />
            )}
          </div>
        </div>
      </div>

      {/* NOTIFIKASI SUCCESS OFFLINE */}
      {offlineSavedMessage && (
        <div className="p-4 bg-emerald-600 rounded-2xl text-white shadow-md flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
            <p className="text-xs sm:text-sm font-semibold">{offlineSavedMessage}</p>
          </div>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-white text-emerald-800 text-xs font-bold hover:bg-emerald-50 shrink-0"
            >
              Tutup
            </button>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TAMPILAN MENU ONLINE: PERTANYAAN & 7 RUBRIK DIKIRIM GURU -> TOMBOL KIRIM */}
      {/* ========================================================================= */}
      {activeMenu === 'online' && (
        <div className="space-y-5 animate-in fade-in">
          {/* Banner Terkirim Jika Murid Sudah Mengirim Online */}
          {isOnlineSubmitted && (
            <div className="p-4 sm:p-5 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 rounded-3xl text-white shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-purple-200" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold">Refleksi Berhasil Dikirim ke Guru!</h3>
                  <p className="text-xs text-purple-100 mt-0.5">
                    Skor Penilaian Diri: <strong>{onlineScoreAverage}%</strong>. Nilai dan refleksi sudah masuk ke dashboard guru, dan Misi 6 (Asesmen) telah terbuka!
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <ExportDropdown
                  onExportPdf={handleDownloadOnlinePdf}
                  onExportExcel={handleDownloadOnlineExcel}
                  label="Unduh Berkas"
                  theme="dark"
                />
                {onNextMission ? (
                  <button
                    type="button"
                    onClick={() => onNextMission(6)}
                    className="px-4 py-2 rounded-xl bg-white text-purple-900 hover:bg-purple-50 text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
                  >
                    <span>Lanjut ke Misi 6</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : onClose ? (
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl bg-white text-purple-900 hover:bg-purple-50 text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer transition-colors"
                  >
                    <span>Tutup</span>
                  </button>
                ) : null}
              </div>
            </div>
          )}

          <form onSubmit={handleKirimRefleksiOnline} className="space-y-5">
            {/* Bagian 1 Online: Pertanyaan Refleksi dari Guru */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
                <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                  <Brain className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-slate-800 text-sm sm:text-base">
                    1. Pertanyaan Refleksi Pembelajaran (Dari Guru)
                  </h2>
                  <p className="text-xs text-slate-500">
                    Jawab pertanyaan reflektif berikut sesuai instruksi yang dikirim oleh guru Anda.
                  </p>
                </div>
              </div>

              {/* Pertanyaan 1 dari Guru */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <span>1. {teacherQuestions.q1}</span>
                  <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  disabled={isOnlineSubmitted}
                  value={onlineAns1}
                  onChange={(e) => setOnlineAns1(e.target.value)}
                  placeholder="Tuliskan jawaban refleksi Anda secara mendalam dan jelas..."
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
                />
              </div>

              {/* Pertanyaan 2 dari Guru */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <span>2. {teacherQuestions.q2}</span>
                  <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  disabled={isOnlineSubmitted}
                  value={onlineAns2}
                  onChange={(e) => setOnlineAns2(e.target.value)}
                  placeholder="Tuliskan kendala yang dihadapi serta strategi pemecahan masalahnya..."
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
                />
              </div>

              {/* Pertanyaan 3 dari Guru */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800">
                  3. {teacherQuestions.q3}
                </label>
                <textarea
                  rows={2}
                  disabled={isOnlineSubmitted}
                  value={onlineAns3}
                  onChange={(e) => setOnlineAns3(e.target.value)}
                  placeholder="Tuliskan penerapan nyata konsep sains ini dalam kehidupan sehari-hari..."
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
                />
              </div>

              {/* Pertanyaan 4 dari Guru */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-800">
                  4. {teacherQuestions.q4}
                </label>
                <textarea
                  rows={2}
                  disabled={isOnlineSubmitted}
                  value={onlineAns4}
                  onChange={(e) => setOnlineAns4(e.target.value)}
                  placeholder="Tuliskan rencana aksi dan target perbaikan diri ke depan..."
                  className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 disabled:bg-slate-50"
                />
              </div>
            </div>

            {/* Bagian 2 Online: Rubrik Penilaian Diri 7 Pertanyaan (Bisa dikirim dari guru) */}
            <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Star className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="font-display font-bold text-slate-800 text-sm sm:text-base">
                      2. Rubrik Penilaian Diri Sendiri (Dari Guru)
                    </h2>
                    <p className="text-xs text-slate-500">
                      Beri nilai mandiri pada 7 indikator penilaian diri yang ditetapkan oleh guru (Skala 1 - 4 Bintang).
                    </p>
                  </div>
                </div>

                <span className="px-3 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 text-xs font-bold font-mono self-start sm:self-auto">
                  Skor Mandiri: {onlineScoreAverage}%
                </span>
              </div>

              {/* 7 Pertanyaan / Aspek Penilaian Diri Online (Bisa dikirim dari guru) */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {teacherRubrics.map((rubricItem, idx) => (
                  <div key={rubricItem.id || idx}>
                    {renderRatingStars(
                      onlineScores[idx] || 4,
                      (val) => {
                        const next = [...onlineScores];
                        next[idx] = val;
                        setOnlineScores(next);
                      },
                      rubricItem.label,
                      rubricItem.desc,
                      isOnlineSubmitted,
                    )}
                  </div>
                ))}
              </div>

              {/* Komitmen Pribadi */}
              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <label className="text-xs font-bold text-slate-800">
                  Komitmen Pribadi Peningkatan Belajar:
                </label>
                <input
                  type="text"
                  disabled={isOnlineSubmitted}
                  value={onlineKomitmen}
                  onChange={(e) => setOnlineKomitmen(e.target.value)}
                  placeholder="Contoh: Saya berkomitmen untuk senantiasa disiplin waktu dan aktif bertanya saat ada materi yang belum dipahami..."
                  className="w-full h-10 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-400 disabled:bg-slate-50"
                />
              </div>
            </div>

            {/* Footer Menu Online: Tombol Kirim Refleksi */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              <div className="text-xs text-slate-600 space-y-0.5">
                <p className="font-bold text-slate-800 text-xs sm:text-sm">Siap Mengirim Refleksi ke Guru?</p>
                <p className="text-slate-500 text-[11px] sm:text-xs">
                  Jawaban refleksi akan dikirim langsung ke menu penilaian guru dan membuka Misi 6 secara otomatis.
                </p>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                {isOnlineSubmitted ? (
                  <button
                    type="button"
                    onClick={() => {
                      if (onNextMission) {
                        onNextMission(6);
                      } else if (onClose) {
                        onClose();
                      }
                    }}
                    className="w-full sm:w-auto px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white"
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-purple-200" />
                    <span>Terkirim ke Guru (Lanjut Misi 6)</span>
                    <ArrowRight className="w-4 h-4 shrink-0" />
                  </button>
                ) : (
                  <button
                    id="btn-kirim-refleksi"
                    type="submit"
                    disabled={isSubmittingOnline}
                    className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                  >
                    <Send className="w-4 h-4 shrink-0" />
                    <span>kirim refleksi</span>
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. TAMPILAN MENU OFFLINE: PERTANYAAN & 7 RUBRIK KHUSUS -> TOMBOL SIMPAN PDF */}
      {/* ========================================================================= */}
      {activeMenu === 'offline' && (
        <div className="space-y-5 animate-in fade-in">
          {/* BAGIAN 1 OFFLINE: REFLEKSI PEMBELAJARAN (4 Pertanyaan Eksak Sesuai Permintaan) */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <Brain className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-display font-bold text-slate-800 text-sm sm:text-base">
                  Refleksi Pembelajaran
                </h2>
                <p className="text-xs text-slate-500">
                  Jawab 4 butir pertanyaan refleksi pembelajaran di bawah ini secara jujur dan komprehensif.
                </p>
              </div>
            </div>

            {/* Pertanyaan 1 Offline */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <span>1. Konsep apa yang paling Anda pahami dengan jelas pada pembelajaran ini?</span>
                <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={3}
                value={offlineAns1}
                onChange={(e) => setOfflineAns1(e.target.value)}
                placeholder="Tuliskan pemahaman konsep yang paling Anda kuasai dengan jelas..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-400 bg-white"
              />
            </div>

            {/* Pertanyaan 2 Offline */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <span>2. Apa kendala terbesar yang Anda hadapi saat pembelajaran dan bagaimana Anda mengatasinya?</span>
                <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={3}
                value={offlineAns2}
                onChange={(e) => setOfflineAns2(e.target.value)}
                placeholder="Tuliskan tantangan atau hambatan terbesar yang dihadapi dan cara Anda menuntaskannya..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-400 bg-white"
              />
            </div>

            {/* Pertanyaan 3 Offline */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800">
                3. Bagaimana perasaan saya selama mengikuti pembelajaran hari ini?
              </label>
              <textarea
                rows={2}
                value={offlineAns3}
                onChange={(e) => setOfflineAns3(e.target.value)}
                placeholder="Ungkapkan perasaan, minat, atau antusiasme Anda selama proses belajar..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-400 bg-white"
              />
            </div>

            {/* Pertanyaan 4 Offline */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-800">
                4. Apa rencana aksi/perbaikan diri Anda untuk materi pembelajaran berikutnya?
              </label>
              <textarea
                rows={2}
                value={offlineAns4}
                onChange={(e) => setOfflineAns4(e.target.value)}
                placeholder="Tuliskan langkah konkret atau strategi belajar yang akan diterapkan pada materi berikutnya..."
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-400 bg-white"
              />
            </div>
          </div>

          {/* BAGIAN 2 OFFLINE: RUBRIK PENILAIAN DIRI SENDIRI (7 Aspek Eksak Sesuai Permintaan) */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
                  <Star className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-slate-800 text-sm sm:text-base">
                    Rubrik Penilaian Diri Sendiri
                  </h2>
                  <p className="text-xs text-slate-500">
                    Nilai diri Anda pada 7 kriteria penilaian di bawah ini menggunakan skala 1 - 4 bintang.
                  </p>
                </div>
              </div>

              <span className="px-3 py-1 rounded-xl bg-amber-50 text-amber-900 border border-amber-200 text-xs font-bold font-mono self-start sm:self-auto">
                Skor Mandiri: {offlineScoreAverage}%
              </span>
            </div>

            {/* 7 Aspek Rubrik Penilaian Diri Offline */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {DEFAULT_7_RUBRIC_ASPECTS.map((aspect, idx) => (
                <div key={aspect.id}>
                  {renderRatingStars(
                    offlineScores[idx] || 4,
                    (val) => {
                      const next = [...offlineScores];
                      next[idx] = val;
                      setOfflineScores(next);
                    },
                    aspect.label,
                    aspect.desc,
                  )}
                </div>
              ))}
            </div>

            {/* Komitmen Pribadi Peningkatan Belajar Offline */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-800">
                Komitmen Pribadi Peningkatan Belajar:
              </label>
              <textarea
                rows={2}
                value={offlineKomitmen}
                onChange={(e) => setOfflineKomitmen(e.target.value)}
                placeholder="Tuliskan komitmen pribadi Anda untuk meningkatkan kualitas dan konsistensi belajar..."
                className="w-full p-3 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-400 bg-white"
              />
            </div>
          </div>

          {/* Footer Menu Offline: Tombol Simpan PDF */}
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            <div className="text-xs text-slate-600 space-y-0.5">
              <p className="font-bold text-slate-800 text-xs sm:text-sm">Simpan Lembar Refleksi ke Dokumen PDF</p>
              <p className="text-slate-500 text-[11px] sm:text-xs">
                Dokumen resmi berisi seluruh jawaban refleksi dan capaian rubrik penilaian diri 7 aspek akan diunduh secara instan ke HP/komputer Anda.
              </p>
            </div>

            <div className="shrink-0 flex items-center gap-2">
              <button
                id="btn-simpan-pdf-offline"
                type="button"
                onClick={handleSimpanPdfOffline}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-gradient-to-r from-amber-600 via-orange-600 to-indigo-600 hover:from-amber-700 hover:to-indigo-700 text-white"
              >
                <FileDown className="w-4 h-4 shrink-0" />
                <span>simpan pdf</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
