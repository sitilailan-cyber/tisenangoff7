import React, { useState, useMemo } from 'react';
import {
  X,
  Sparkles,
  BookOpen,
  FlaskConical,
  Target,
  Gamepad2,
  Brain,
  Trophy,
  ExternalLink,
  Upload,
  CheckCircle2,
  AlertCircle,
  Clock,
  Zap,
  HelpCircle,
  Share2,
  FileText,
  Play,
  RotateCcw,
  Check,
  ChevronRight,
  FolderDown,
} from 'lucide-react';
import { Mission, QuestionItem, StudentTaskSubmission, PortfolioItem } from '../../types';
import { storage } from '../../services/storage';

const STUDENT_DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?hl=ID';

interface MisiInteractiveRunnerProps {
  mission: Mission;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose: () => void;
  onOpenLab?: () => void;
}

export const MisiInteractiveRunner: React.FC<MisiInteractiveRunnerProps> = ({
  mission,
  studentId,
  studentName,
  classId,
  className,
  onCompleted,
  onNextMission,
  onClose,
  onOpenLab,
}) => {
  const coreNum = mission.coreMissionNumber;

  // Form submission states
  const [studentContent, setStudentContent] = useState('');
  const [driveLink, setDriveLink] = useState('');
  const [publishToPortfolio, setPublishToPortfolio] = useState(true);
  const [portfolioTitle, setPortfolioTitle] = useState(mission.title);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Question answering states (for Misi 5 & 6)
  const [userAnswers, setUserAnswers] = useState<Record<string, any>>({});
  const [reflectionAnswer, setReflectionAnswer] = useState('');
  const [isExamFinished, setIsExamFinished] = useState(false);
  const [examScore, setExamScore] = useState<number>(0);

  // Default fallback questions if teacher has not added questions yet
  const activeQuestions: QuestionItem[] = useMemo(() => {
    if (mission.questions && mission.questions.length > 0) {
      return mission.questions;
    }

    // Default rich questions for Latihan (Misi 5)
    if (coreNum === 5) {
      return [
        {
          id: 'q-def-1',
          category: 'pilihan_ganda',
          prompt:
            'Berdasarkan hukum kekekalan energi kalor (Azas Black), jika kalorimeter ideal dengan kapasitas kalor diabaikan mencampurkan 100g air suhu 80°C dan 100g air suhu 20°C, maka suhu akhir campuran adalah...',
          options: ['40°C', '50°C', '60°C', '70°C'],
          correctAnswer: '50°C',
          explanation:
            'Karena massa dan kalor jenis kedua zat cair sama, maka T_campuran = (80 + 20) / 2 = 50°C.',
          points: 50,
        },
        {
          id: 'q-def-2',
          category: 'isian',
          prompt:
            'Sebutkan nama instrumen atau sensor digital yang digunakan untuk mengukur laju perubahan temperatur cairan secara real-time pada praktikum kalorimeter!',
          correctAnswer: 'sensor suhu probe',
          explanation:
            'Sensor suhu probe digital (seperti DS18B20 atau probe termokopel) digunakan untuk merekam data suhu real-time.',
          points: 50,
        },
      ];
    }

    // Default rich questions for Asesmen Akhir (Misi 6)
    if (coreNum === 6) {
      return [
        {
          id: 'q-asm-1',
          category: 'pilihan_ganda',
          prompt:
            'Dalam analisis data regresi bivariat antara konsentrasi larutan garam (X) terhadap waktu kristalisasi (Y), koefisien determinasi R² bernilai 0.92. Interpretasi saintifik yang tepat adalah...',
          options: [
            '92% variasi waktu kristalisasi dapat dijelaskan oleh variasi konsentrasi larutan garam.',
            'Korelasi antara konsentrasi dan waktu kristalisasi adalah negatif kuat.',
            'Terdapat 8% kemungkinan hasil eksperimen mengalami galat sistematis.',
            'Hubungan kedua variabel adalah non-linear kuadratik sempurna.',
          ],
          correctAnswer:
            '92% variasi waktu kristalisasi dapat dijelaskan oleh variasi konsentrasi larutan garam.',
          explanation:
            'R² = 0.92 menyatakan proporsi variabilitas variabel dependen yang dijelaskan oleh model regresi independen sebesar 92%.',
          points: 25,
        },
        {
          id: 'q-asm-2',
          category: 'benar_salah',
          prompt:
            'Pernyataan: Pada kalorimeter bom adiabatik sempurna, pertukaran kalor antara sistem reaksi dengan lingkungan luar bernilai nol (Q_lingkungan = 0).',
          correctAnswer: true,
          explanation:
            'Benar. Sistem adiabatik ideal mencegah aliran kalor keluar maupun masuk ke dalam wadah kalorimeter.',
          points: 25,
        },
        {
          id: 'q-asm-3',
          category: 'mcma',
          prompt:
            'Pilihlah DUA faktor lingkungan yang secara langsung mempercepat laju evaporasi air pada pembuatan garam kristal:',
          options: [
            'Peningkatan intensitas radiasi termal matahari',
            'Tingginya kelembaban relatif udara sekitar',
            'Peningkatan kecepatan angin di atas permukaan wadah',
            'Peningkatan volume kedalaman air laut yang diendapkan',
          ],
          correctAnswer: [
            'Peningkatan intensitas radiasi termal matahari',
            'Peningkatan kecepatan angin di atas permukaan wadah',
          ],
          explanation:
            'Radiasi termal menaikkan energi kinetik molekul dan aliran angin mempercepat pemindahan uap air dari atas permukaan cairan.',
          points: 25,
        },
        {
          id: 'q-asm-4',
          category: 'isian',
          prompt:
            'Tuliskan istilah hukum fisika yang menyatakan bahwa kalor yang dilepaskan oleh benda bersuhu tinggi sama dengan kalor yang diserap oleh benda bersuhu rendah!',
          correctAnswer: 'azas black',
          explanation: 'Azas Black: Q_lepas = Q_terima.',
          points: 25,
        },
      ];
    }

    return [];
  }, [mission.questions, coreNum]);

  // Evaluate exam answers
  const handleCalculateScore = () => {
    let totalScore = 0;
    let earned = 0;

    activeQuestions.forEach((q) => {
      totalScore += q.points;
      const ans = userAnswers[q.id];

      if (q.category === 'pilihan_ganda' && ans === q.correctAnswer) {
        earned += q.points;
      } else if (q.category === 'benar_salah' && ans === q.correctAnswer) {
        earned += q.points;
      } else if (q.category === 'mcma') {
        const correctList = Array.isArray(q.correctAnswer) ? q.correctAnswer : [];
        const userList = Array.isArray(ans) ? ans : [];
        if (
          correctList.length === userList.length &&
          correctList.every((item) => userList.includes(item))
        ) {
          earned += q.points;
        }
      } else if (q.category === 'isian') {
        const expected = String(q.correctAnswer || '').trim().toLowerCase();
        const actual = String(ans || '').trim().toLowerCase();
        if (actual === expected || (expected.length > 3 && actual.includes(expected))) {
          earned += q.points;
        }
      } else {
        // Jodohkan & Mengurutkan: award points if attempted
        if (ans) {
          earned += q.points;
        }
      }
    });

    const finalPct = totalScore > 0 ? Math.round((earned / totalScore) * 100) : 100;
    setExamScore(finalPct);
    setIsExamFinished(true);
    return finalPct;
  };

  // Submit task directly to Firebase Realtime Database
  const handleSubmitTask = () => {
    setIsSubmitting(true);

    let scoreToRecord = 90;
    if (coreNum === 5 || coreNum === 6) {
      scoreToRecord = isExamFinished ? examScore : handleCalculateScore();
    }

    const taskId = `task-${studentId}-${mission.id}-${Date.now()}`;
    const fullContent = [
      studentContent.trim() ? `Catatan/Jawaban:\n${studentContent.trim()}` : '',
      reflectionAnswer.trim() ? `Refleksi Mandiri:\n${reflectionAnswer.trim()}` : '',
      isExamFinished ? `Skor Asesmen: ${scoreToRecord}/100` : '',
    ]
      .filter(Boolean)
      .join('\n\n');

    const submission: StudentTaskSubmission = {
      id: taskId,
      missionId: mission.id,
      studentId: studentId,
      studentName: studentName,
      classId: classId,
      className: className,
      submittedAt: new Date().toISOString(),
      content: fullContent || `Penyelesaian Misi: ${mission.title}`,
      driveLink: driveLink.trim() || STUDENT_DRIVE_FOLDER_URL,
      status: 'SUBMITTED',
      score: scoreToRecord,
      tpId: mission.tpId,
    };

    // 1. Submit to /tugas_siswa in Firebase RTDB
    storage.submitStudentTask(submission);

    // 2. If student chose to publish to class portfolio feed (/portofolio)
    if (publishToPortfolio) {
      const portfolioItem: PortfolioItem = {
        id: `pf-${Date.now()}`,
        studentId: studentId,
        studentName: studentName,
        classId: classId,
        className: className,
        missionId: mission.id,
        title: portfolioTitle.trim() || mission.title,
        subjectName: mission.subjectName || 'MIPA Eksperimental',
        date: new Date().toISOString().split('T')[0],
        category: 'Eksperimen',
        xpEarned: mission.xpReward || 100,
        reflectionSummary: reflectionAnswer.trim() || 'Refleksi pembelajaran tuntas.',
        description:
          studentContent.trim() ||
          `Laporan pengerjaan ${mission.title} oleh ${studentName}. Hasil tersimpan dan terhubung ke direktori tugas Google Drive.`,
        documentation:
          mission.mediaResources?.[0]?.url ||
          'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800&q=80',
        driveLink: driveLink.trim() || STUDENT_DRIVE_FOLDER_URL,
        likesCount: 0,
        likedBy: {},
        comments: [],
        createdAt: new Date().toISOString(),
        visibility: 'CLASS',
      };
      storage.savePortfolio(portfolioItem);
    }

    // 3. Mark mission as completed in student progress
    storage.completeMission(studentId, mission.id, scoreToRecord, mission.xpReward);

    setSubmitSuccess(true);
    setIsSubmitting(false);

    setTimeout(() => {
      if (onCompleted) onCompleted();
      onClose();
    }, 1800);
  };

  return (
    <div className="space-y-5 max-h-[82vh] overflow-y-auto pr-1">
      {/* Header Banner */}
      <div className="p-5 sm:p-6 bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 rounded-3xl text-white shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between gap-3 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full bg-white/20 text-white text-[10px] font-mono font-bold tracking-wider uppercase border border-white/30">
                LEVEL 0{coreNum} • {mission.coreTitle || `Misi ${coreNum}`}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-900 text-[10px] font-bold flex items-center gap-1">
                <Zap className="w-3 h-3 fill-slate-900" />
                +{mission.xpReward} XP
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-display font-black tracking-tight mt-1">
              {mission.title}
            </h2>
            <p className="text-xs text-blue-100 font-medium">
              {mission.subjectName} • Kelas {className}
            </p>
          </div>
        </div>

        {/* Decorative background shapes */}
        <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Submission Success Notice */}
      {submitSuccess && (
        <div className="p-4 rounded-2xl bg-blue-50 border border-blue-300 text-blue-900 flex items-center gap-3 animate-in fade-in zoom-in-95">
          <CheckCircle2 className="w-6 h-6 text-blue-600 shrink-0" />
          <div className="text-xs">
            <p className="font-bold text-sm">Misi Berhasil Dituntaskan!</p>
            <p>
              Tugas telah dikirim ke node Firebase <code>/tugas_siswa</code> dan dipublikasikan ke{' '}
              <code>/portofolio</code> beranda kelas (+{mission.xpReward} XP).
            </p>
          </div>
        </div>
      )}

      {/* =========================================================================
          KATEGORI 1: MISI PAHAMI KONSEP
          ========================================================================= */}
      {coreNum === 1 && (
        <div className="space-y-4">
          <div className="p-4 bg-blue-50/70 rounded-2xl border border-blue-200 space-y-2">
            <h3 className="font-bold text-xs text-blue-900 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-600" />
              Tujuan & Deskripsi Konseptual
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {mission.description}
            </p>
          </div>

          {/* Reading Module Text if available */}
          {mission.readingModuleText && (
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
              <h4 className="font-bold text-xs text-slate-800 flex items-center gap-1.5 uppercase tracking-wider">
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                Modul Bacaan & Teori Pembelajaran
              </h4>
              <div className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line bg-slate-50 p-3 rounded-xl border border-slate-100 font-sans">
                {mission.readingModuleText}
              </div>
            </div>
          )}

          {/* Media resources (PDF / Video / Link) */}
          {mission.mediaResources && mission.mediaResources.length > 0 && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
                Materi Pendukung dari Guru:
              </h4>
              <div className="space-y-2">
                {mission.mediaResources.map((res, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3 shadow-2xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                        {res.type === 'pdf' ? 'PDF' : res.type === 'video' ? 'VID' : 'LINK'}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-800">{res.title}</div>
                        {res.description && (
                          <div className="text-[11px] text-slate-500">{res.description}</div>
                        )}
                      </div>
                    </div>
                    <a
                      href={res.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 shrink-0"
                    >
                      <span>Buka Materi</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          KATEGORI 2: MISI SIMULASI & EKSPERIMEN
          ========================================================================= */}
      {coreNum === 2 && (
        <div className="space-y-4">
          <div className="p-4 bg-cyan-50/70 rounded-2xl border border-cyan-200 space-y-2">
            <h3 className="font-bold text-xs text-cyan-900 flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-cyan-600" />
              Panduan Praktikum & Eksperimen Sensor
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {mission.simulationSteps ||
                mission.problemPrompt ||
                mission.description ||
                'Gunakan Virtual Lab Kalorimeter atau hubungkan sensor pada Device Center untuk melakukan pengujian dan mencatat data kurva termal.'}
            </p>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-slate-200 flex items-center justify-between gap-3 shadow-xs">
            <div className="space-y-0.5">
              <div className="text-xs font-bold text-slate-800">
                Akses Langsung Simulator Virtual Lab & Device Center
              </div>
              <div className="text-[11px] text-slate-500">
                Lakukan eksperimen interaktif dengan pembacaan sensor probe suhu & IoT.
              </div>
            </div>
            {onOpenLab && (
              <button
                type="button"
                onClick={onOpenLab}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 shadow-sm active:scale-95"
              >
                <FlaskConical className="w-3.5 h-3.5" />
                <span>Buka Virtual Lab</span>
              </button>
            )}
          </div>

          {/* External simulator link if provided */}
          {mission.simulationUrl && (
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-2">
              <span className="text-xs text-slate-700 font-medium truncate">
                Simulator Eksternal Guru: {mission.simulationUrl}
              </span>
              <a
                href={mission.simulationUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold flex items-center gap-1 shrink-0"
              >
                <span>Buka Simulator</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          KATEGORI 3: MISI SELESAIKAN MASALAH NYATA
          ========================================================================= */}
      {coreNum === 3 && (
        <div className="space-y-4">
          <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-2">
            <h3 className="font-bold text-xs text-emerald-900 flex items-center gap-2">
              <Target className="w-4 h-4 text-emerald-600" />
              Studi Kasus Kontekstual & Rumusan Masalah
            </h3>
            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-sans">
              {mission.problemPrompt || mission.description}
            </p>
          </div>

          {mission.triggerQuestions && (
            <div className="p-3.5 bg-blue-50/80 rounded-xl border border-blue-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 flex items-center gap-1">
                <HelpCircle className="w-3 h-3" /> Pertanyaan Pemantik:
              </span>
              <p className="text-xs font-semibold text-blue-950">{mission.triggerQuestions}</p>
            </div>
          )}

          {mission.supportingData && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <span className="text-[10px] font-mono font-bold uppercase text-slate-500">
                Data Lapangan & Parameter Pendukung:
              </span>
              <div className="text-xs font-mono font-bold text-slate-800 bg-white p-2 rounded-lg border border-slate-200">
                {mission.supportingData}
              </div>
            </div>
          )}

          {mission.analysisGuide && (
            <div className="p-3.5 bg-amber-50/70 rounded-xl border border-amber-200 space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                Panduan Analisis Saintifik:
              </span>
              <p className="text-xs text-amber-950 leading-relaxed">{mission.analysisGuide}</p>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          KATEGORI 4: MISI GAME EDUKASI
          ========================================================================= */}
      {coreNum === 4 && (
        <div className="space-y-4">
          <div className="p-4 bg-purple-50/70 rounded-2xl border border-purple-200 space-y-2">
            <h3 className="font-bold text-xs text-purple-900 flex items-center gap-2">
              <Gamepad2 className="w-4 h-4 text-purple-600" />
              Tantangan Game Edukasi
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {mission.gameInstructions ||
                mission.description ||
                'Mainkan game interaktif berikut untuk melatih ketangkasan dan pemahaman konsep sains.'}
            </p>
          </div>

          {mission.gameTargetScore && (
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-center gap-2 text-xs font-bold text-amber-900">
              <Trophy className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Target Capaian: {mission.gameTargetScore}</span>
            </div>
          )}

          {mission.gameUrl ? (
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-slate-800">Arena Game Interaktif</div>
                <div className="text-[11px] text-slate-500 truncate max-w-md font-mono">
                  {mission.gameUrl}
                </div>
              </div>
              <a
                href={mission.gameUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 shadow-sm active:scale-95"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Mulai Bermain</span>
              </a>
            </div>
          ) : (
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 text-center">
              Tautan game edukatif terintegrasi dengan materi kelas. Silakan unggah tangkapan layar
              atau refleksi permainan Anda pada form di bawah.
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          KATEGORI 5 & 6: LATIHAN, REFLEKSI & ASESMEN AKHIR
          ========================================================================= */}
      {(coreNum === 5 || coreNum === 6) && (
        <div className="space-y-4">
          <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200 space-y-1">
            <h3 className="font-bold text-xs text-indigo-900 flex items-center gap-2">
              <Brain className="w-4 h-4 text-indigo-600" />
              {coreNum === 5 ? 'Latihan Mandiri & Evaluasi Pemahaman' : 'Asesmen Sumatif Akhir'}
            </h3>
            <p className="text-xs text-indigo-950">
              Jawablah pertanyaan di bawah ini dengan teliti. Nilai akan dihitung secara otomatis dan
              tersimpan pada portofolio Anda.
            </p>
          </div>

          {/* Interactive questions */}
          <div className="space-y-4">
            {activeQuestions.map((q, idx) => (
              <div
                key={q.id}
                className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                    Soal {idx + 1} • {q.category.toUpperCase().replace('_', ' ')}
                  </span>
                  <span className="text-[10px] font-mono font-bold text-amber-600">
                    {q.points} Poin
                  </span>
                </div>

                <p className="text-xs sm:text-sm font-semibold text-slate-800 leading-relaxed">
                  {q.prompt}
                </p>

                {/* Question Type: Pilihan Ganda */}
                {q.category === 'pilihan_ganda' && q.options && (
                  <div className="space-y-1.5">
                    {q.options.map((opt, oIdx) => {
                      const isSelected = userAnswers[q.id] === opt;
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          disabled={isExamFinished}
                          onClick={() => setUserAnswers((prev) => ({ ...prev, [q.id]: opt }))}
                          className={`w-full text-left p-2.5 rounded-xl border text-xs flex items-center justify-between transition-colors ${
                            isSelected
                              ? 'bg-blue-50 border-blue-500 text-blue-900 font-bold'
                              : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span>{opt}</span>
                          {isSelected && <Check className="w-4 h-4 text-blue-600 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Question Type: Benar / Salah */}
                {q.category === 'benar_salah' && (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={isExamFinished}
                      onClick={() => setUserAnswers((prev) => ({ ...prev, [q.id]: true }))}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-colors ${
                        userAnswers[q.id] === true
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      ✓ Benar
                    </button>
                    <button
                      type="button"
                      disabled={isExamFinished}
                      onClick={() => setUserAnswers((prev) => ({ ...prev, [q.id]: false }))}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-colors ${
                        userAnswers[q.id] === false
                          ? 'bg-rose-600 text-white border-rose-600'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      ✗ Salah
                    </button>
                  </div>
                )}

                {/* Question Type: MCMA (Pilihan Ganda Kompleks) */}
                {q.category === 'mcma' && q.options && (
                  <div className="space-y-1.5">
                    {q.options.map((opt, oIdx) => {
                      const currentSelected: string[] = userAnswers[q.id] || [];
                      const isChecked = currentSelected.includes(opt);
                      return (
                        <button
                          key={oIdx}
                          type="button"
                          disabled={isExamFinished}
                          onClick={() => {
                            const next = isChecked
                              ? currentSelected.filter((x) => x !== opt)
                              : [...currentSelected, opt];
                            setUserAnswers((prev) => ({ ...prev, [q.id]: next }));
                          }}
                          className={`w-full text-left p-2.5 rounded-xl border text-xs flex items-center justify-between transition-colors ${
                            isChecked
                              ? 'bg-indigo-50 border-indigo-500 text-indigo-950 font-bold'
                              : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                          }`}
                        >
                          <span>{opt}</span>
                          <span
                            className={`w-4 h-4 rounded border flex items-center justify-center text-[10px] ${
                              isChecked
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'border-slate-300'
                            }`}
                          >
                            {isChecked && '✓'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* Question Type: Isian Singkat */}
                {q.category === 'isian' && (
                  <div>
                    <input
                      type="text"
                      disabled={isExamFinished}
                      value={userAnswers[q.id] || ''}
                      onChange={(e) =>
                        setUserAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                      }
                      placeholder="Ketikkan jawaban singkat Anda di sini..."
                      className="w-full h-9 px-3 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                )}

                {/* Show explanation after exam is finished */}
                {isExamFinished && q.explanation && (
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-xs space-y-1">
                    <span className="font-bold text-slate-900 block">Pembahasan:</span>
                    <span>{q.explanation}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Teacher's Metacognitive Reflection Prompt (for Misi 5) */}
          {coreNum === 5 && (
            <div className="p-4 bg-amber-50/80 rounded-2xl border border-amber-200 space-y-2">
              <label className="font-bold text-xs text-amber-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                Refleksi Mandiri Murid
              </label>
              <p className="text-[11px] text-amber-800">
                {mission.reflectionPrompt ||
                  'Bagian materi mana yang paling mudah atau menantang bagi Anda? Bagaimana Anda merencanakan eksplorasi selanjutnya?'}
              </p>
              <textarea
                rows={2}
                value={reflectionAnswer}
                onChange={(e) => setReflectionAnswer(e.target.value)}
                placeholder="Tuliskan refleksi belajar Anda di sini..."
                className="w-full p-2.5 rounded-xl border border-amber-300 text-xs bg-white focus:ring-2 focus:ring-amber-500/20"
              />
            </div>
          )}

          {/* Exam score banner if finished */}
          {isExamFinished && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-between shadow-md">
              <div>
                <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-200">
                  Hasil Evaluasi Pengerjaan
                </div>
                <div className="text-xl font-display font-black mt-0.5">
                  Skor Anda: {examScore} / 100
                </div>
              </div>
              <div className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold border border-white/30">
                {examScore >= 75 ? 'Tuntas Kompeten 🌟' : 'Perlu Penguatan 🌱'}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          UNIVERSAL TASK SUBMISSION FORM (Links to Google Drive + Realtime Sync)
          ========================================================================= */}
      <div className="p-4 sm:p-5 bg-slate-50 rounded-3xl border border-slate-200/90 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <div className="space-y-0.5">
            <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-blue-600" />
              Unggah Hasil Pengerjaan / Portofolio Murid
            </h4>
            <p className="text-[10px] text-slate-500">
              Tugas akan tersimpan ke node <code>/tugas_siswa</code> dan otomatis dipublikasikan ke{' '}
              <code>/portofolio</code> beranda kelas.
            </p>
          </div>

          <a
            href={STUDENT_DRIVE_FOLDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 text-[11px] font-bold flex items-center gap-1 shrink-0"
            title="Buka Folder Google Drive Direktori Tugas Murid"
          >
            <FolderDown className="w-3.5 h-3.5 text-blue-600" />
            <span className="hidden sm:inline">Buka Folder Drive</span>
          </a>
        </div>

        {/* Content / Catatan Siswa */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-700 block">
            Catatan / Ringkasan Analisis Pengerjaan:
          </label>
          <textarea
            rows={3}
            value={studentContent}
            onChange={(e) => setStudentContent(e.target.value)}
            placeholder="Tuliskan kesimpulan eksperimen, temuan analisis data, atau penjelasan solusi masalah nyata Anda..."
            className="w-full p-2.5 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-blue-500/20"
          />
        </div>

        {/* Google Drive Link input */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
              <span>Tautan File / Laporan di Google Drive:</span>
            </label>
            <a
              href={STUDENT_DRIVE_FOLDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] text-blue-600 font-bold hover:underline"
            >
              Simpan di Folder Tugas Kelas ↗
            </a>
          </div>
          <input
            type="url"
            value={driveLink}
            onChange={(e) => setDriveLink(e.target.value)}
            placeholder={STUDENT_DRIVE_FOLDER_URL}
            className="w-full h-9 px-3 rounded-xl border border-slate-300 text-xs font-mono bg-white focus:ring-2 focus:ring-blue-500/20"
          />
          <p className="text-[10px] text-slate-500">
            Direktori resmi tugas murid terpusat di folder Google Drive kelas. Anda dapat menempelkan
            link dokumen PDF/foto tugas di sini.
          </p>
        </div>

        {/* Publish to portfolio toggle */}
        <div className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-200">
          <div className="space-y-0.5">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Share2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>Publikasikan ke Beranda Portofolio Kelas (/portofolio)</span>
            </div>
            <div className="text-[10px] text-slate-500">
              Karya Anda akan langsung tampil di feed Beranda untuk diapresiasi teman & guru.
            </div>
          </div>
          <input
            type="checkbox"
            checked={publishToPortfolio}
            onChange={(e) => setPublishToPortfolio(e.target.checked)}
            className="w-4 h-4 text-blue-600 rounded cursor-pointer"
          />
        </div>

        {publishToPortfolio && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-600 block">
              Judul Karya Portofolio:
            </label>
            <input
              type="text"
              value={portfolioTitle}
              onChange={(e) => setPortfolioTitle(e.target.value)}
              placeholder={mission.title}
              className="w-full h-8 px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
            />
          </div>
        )}
      </div>

      {/* Footer Action Buttons */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-200">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 rounded-xl text-slate-500 hover:text-slate-700 text-xs font-bold"
        >
          Kembali
        </button>

        <div className="flex items-center gap-2">
          {(coreNum === 5 || coreNum === 6) && !isExamFinished && (
            <button
              type="button"
              onClick={handleCalculateScore}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs shadow-xs"
            >
              Periksa Jawaban
            </button>
          )}

          {submitSuccess && onNextMission ? (
            <button
              id="btn-lanjut-misi-berikut"
              type="button"
              onClick={() => {
                const nextNum = (mission.coreMissionNumber || 3) + 1;
                onNextMission(nextNum);
              }}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <span>Selesai Belajar dan Buka Misi {(mission.coreMissionNumber || 3) + 1}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              disabled={isSubmitting || submitSuccess}
              onClick={handleSubmitTask}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Mengirim ke Firebase...</span>
              ) : submitSuccess ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Tersimpan! (Buka Misi {(mission.coreMissionNumber || 3) + 1})</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Kirim Tugas & Tuntaskan (+{mission.xpReward} XP)</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
