import React, { useState, useEffect, useRef } from 'react';
import {
  Thermometer,
  LineChart as LineChartIcon,
  Play,
  RotateCcw,
  Square,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
  BookOpen,
  FlaskConical,
  Plus,
  Trash2,
  Save,
  Info,
  Flame,
  Droplets,
  ChevronDown,
  Calculator,
  FileSpreadsheet,
} from 'lucide-react';
import { storage } from '../../services/storage';
import { firebaseRealtime, STUDENT_DRIVE_FOLDER_URL } from '../../services/firebaseRealtime';
import * as XLSX from 'xlsx';
import { LaboratoriumRegresiLinear } from './LaboratoriumRegresiLinear';

interface VirtualLabProps {
  studentId: string;
  missionId?: string;
  onNavigateToMisi2?: (step?: 'COLLECT' | 'OBSERVE' | 'EXPERIMENT') => void;
  onFinishExperiment?: () => void;
}

type SubjectId = 'sbj-matematika' | 'sbj-fisika' | 'sbj-kimia' | 'sbj-biologi';

interface SimulasiDataRow {
  id: string;
  no: number;
  param1: string; // misal Waktu / Variabel X
  param2: string; // misal Suhu / Variabel Y
  param3?: string; // misal Penguapan & Kalor / Residu R²
  catatan: string;
}

const SUBJECT_OPTIONS = [
  {
    id: 'sbj-matematika' as SubjectId,
    name: 'Matematika',
    title: 'Simulasi Regresi Linear',
    icon: LineChartIcon,
    color: 'text-blue-500 bg-blue-500/10 border-blue-500/30',
  },
  {
    id: 'sbj-fisika' as SubjectId,
    name: 'Fisika',
    title: 'Simulasi Suhu dan Kalor yang Menyebabkan Penguapan',
    icon: Thermometer,
    color: 'text-rose-500 bg-rose-500/10 border-rose-500/30',
  },
  {
    id: 'sbj-kimia' as SubjectId,
    name: 'Kimia',
    title: 'Sedang dalam pengembangan',
    icon: Flame,
    color: 'text-amber-500 bg-amber-500/10 border-amber-500/30',
  },
  {
    id: 'sbj-biologi' as SubjectId,
    name: 'Biologi',
    title: 'Sedang dalam pengembangan',
    icon: Droplets,
    color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30',
  },
];

export const VirtualLab: React.FC<VirtualLabProps> = ({
  studentId,
  missionId = 'msn-cls-xii-1-3',
  onNavigateToMisi2,
  onFinishExperiment,
}) => {
  const profile = storage.getStudentProfile(studentId);
  const className = profile?.className || 'XII-1';

  // State Pilihan Mata Pelajaran
  const [selectedSubjectId, setSelectedSubjectId] = useState<SubjectId>('sbj-matematika');
  const [isSubjectDropdownOpen, setIsSubjectDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Tutup dropdown saat klik di luar
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsSubjectDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // ----------------- FISIKA: SIMULASI SUHU & KALOR YANG MENYEBABKAN PENGUAPAN -----------------
  const [heaterOn, setHeaterOn] = useState<boolean>(false);
  const [heaterPower, setHeaterPower] = useState<number>(100); // Watt
  const initialWaterVolume = 200; // mL awal
  const [waterVolume, setWaterVolume] = useState<number>(200); // mL / gram sisa
  const [waterTemp, setWaterTemp] = useState<number>(25.0); // °C
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [calorimeterDataPoints, setCalorimeterDataPoints] = useState<{ t: number; temp: number }[]>([
    { t: 0, temp: 25.0 },
  ]);

  // Volume air yang telah menguap (mL)
  const evaporatedVolume = Math.max(0, Number((initialWaterVolume - waterVolume).toFixed(1)));

  // Loop Fisika Suhu, Kalor & Penguapan:
  // Q = P * t = m * c * DeltaT, dan saat mendidih/suhu tinggi terjadi penguapan (Q = m_uap * U)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (heaterOn) {
      interval = setInterval(() => {
        setTimerSeconds((t) => {
          const nextT = t + 1;

          // Hitung kenaikan suhu
          const deltaTPerSecond = (heaterPower * 1.5) / (Math.max(20, waterVolume) * 4.184);

          setWaterTemp((prevTemp) => {
            const nextTemp = Math.min(100.0, Number((prevTemp + deltaTPerSecond).toFixed(2)));
            setCalorimeterDataPoints((prev) => [...prev.slice(-30), { t: nextT, temp: nextTemp }]);

            // Jika suhu >= 65°C, penguapan mulai terjadi; jika mendekati 100°C (mendidih), penguapan intensif
            if (nextTemp >= 65) {
              setWaterVolume((currVol) => {
                const evaporationRate = nextTemp >= 95 ? (heaterPower / 100) * 0.45 : 0.15;
                return Math.max(10, Number((currVol - evaporationRate).toFixed(1)));
              });
            }

            return nextTemp;
          });

          return nextT;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [heaterOn, heaterPower, waterVolume]);

  // ----------------- TABEL DATA HASIL SIMULASI -----------------
  const [recordedRows, setRecordedRows] = useState<SimulasiDataRow[]>([]);
  const [saveStatus, setSaveStatus] = useState<{ type: 'idle' | 'saving' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  });

  // Pencatatan Fisika: Suhu, Kalor & Penguapan
  const handleRecordDataSuhu = () => {
    const statusPenguapan =
      waterTemp >= 95
        ? 'Mendidih & Penguapan Intensif'
        : waterTemp >= 65
        ? 'Evaporasi di Permukaan'
        : 'Pemanasan Awal';

    const newRow: SimulasiDataRow = {
      id: `sim-suhu-${Date.now()}`,
      no: recordedRows.length + 1,
      param1: `${timerSeconds} detik`,
      param2: `${waterTemp.toFixed(1)} °C`,
      param3: `${evaporatedVolume > 0 ? `Menguap ${evaporatedVolume} mL` : '0 mL'} (Sisa ${waterVolume} mL)`,
      catatan: `Daya ${heaterPower}W | ${statusPenguapan}`,
    };
    setRecordedRows((prev) => [...prev, newRow]);
  };

  // Simpan tabel simulasi ke Database Misi Siswa
  const handleSaveToStudentMission = async () => {
    if (recordedRows.length === 0) {
      setSaveStatus({
        type: 'error',
        message: 'Tabel simulasi masih kosong. Rekam beberapa data pengamatan terlebih dahulu.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 3500);
      return;
    }

    setSaveStatus({ type: 'saving', message: 'Menyimpan tabel ke Database Misi Murid & Firebase...' });
    try {
      await firebaseRealtime.saveStudentExperimentData(studentId, missionId, {
        studentName: profile?.student?.name || 'Murid TI SENANG',
        className,
        rows: recordedRows,
        notes: `Simulasi Virtual ${
          selectedSubjectId === 'sbj-matematika'
            ? 'Regresi Linear (Matematika)'
            : 'Suhu dan Kalor yang Menyebabkan Penguapan (Fisika)'
        }`,
        parameters: {
          materi: selectedSubjectId === 'sbj-matematika' ? 'regresi_linear' : 'suhu_kalor',
          subjectId: selectedSubjectId,
        },
      });

      // Format baris presisi untuk disinkronkan ke Misi 2 Tahap 3 (Kumpul Data)
      let rowsForStorage: any[] = [];

      if (selectedSubjectId === 'sbj-matematika') {
        const initialY = (() => {
          if (recordedRows.length > 0) {
            const val = parseFloat(recordedRows[0].param2);
            if (!isNaN(val)) return val;
          }
          return 0;
        })();

        rowsForStorage = recordedRows.map((r, idx) => {
          const xNum = parseFloat(r.param1);
          const yNum = parseFloat(r.param2);
          const waktuVal = !isNaN(xNum) ? xNum : idx + 1;
          const suhuAkhirVal = !isNaN(yNum) ? yNum : 0;
          const suhuAwalVal = initialY;

          return {
            waktu: waktuVal,
            suhuAwal: suhuAwalVal,
            suhuAkhir: suhuAkhirVal,
            deltaT: Number((suhuAkhirVal - suhuAwalVal).toFixed(2)),
            intensitasCahaya: !isNaN(xNum) ? Math.round(xNum * 10) : 500,
            kalorTerukur: 0,
            kalorTeoritis: 0,
            efisiensi: 100,
            param1: r.param1,
            param2: r.param2,
            param3: r.param3 || '-',
            catatan: r.catatan || '',
            materi: 'regresi_linear',
            sourceSubject: 'Matematika (Regresi Linear)',
          };
        });
      } else {
        // Fisika: Suhu dan Kalor yang Menyebabkan Penguapan
        const firstRowTemp = (() => {
          if (recordedRows.length > 0) {
            const cleaned = recordedRows[0].param2.replace(/[^0-9.-]/g, '');
            const val = parseFloat(cleaned);
            if (!isNaN(val)) return val;
          }
          return 25.0;
        })();

        rowsForStorage = recordedRows.map((r, idx) => {
          const cleanedTime = r.param1.replace(/[^0-9.-]/g, '');
          const timeNum = parseFloat(cleanedTime);
          const waktuVal = !isNaN(timeNum) ? timeNum : idx * 5;

          const cleanedTemp = r.param2.replace(/[^0-9.-]/g, '');
          const tempNum = parseFloat(cleanedTemp);
          const suhuAkhirVal = !isNaN(tempNum) ? tempNum : 28.0;

          const deltaTVal = Number((suhuAkhirVal - firstRowTemp).toFixed(1));
          const heatJ = Number((0.2 * 4186 * Math.max(0, deltaTVal)).toFixed(0));

          return {
            waktu: waktuVal,
            suhuAwal: firstRowTemp,
            suhuAkhir: suhuAkhirVal,
            deltaT: deltaTVal,
            intensitasCahaya: 500,
            kalorTerukur: heatJ,
            kalorTeoritis: Number((heatJ * 1.05).toFixed(0)),
            efisiensi: 98.2,
            param1: r.param1,
            param2: r.param2,
            param3: r.param3 || '-',
            catatan: r.catatan || '',
            materi: 'suhu_kalor',
            sourceSubject: 'Fisika (Suhu dan Kalor)',
          };
        });
      }

      const baseSession = {
        experimentId: `exp-${Date.now()}`,
        studentId,
        missionId,
        startedAt: new Date(Date.now() - 60000).toISOString(),
        completedAt: new Date().toISOString(),
        status: 'COMPLETED' as const,
        source: 'SIMULATION' as const,
        readings: [],
        rows: rowsForStorage as any,
      };

      storage.saveExperimentSession(baseSession);
      storage.saveExperimentSession({
        ...baseSession,
        missionId: 'msn-cls-xii-1-2',
      });

      try {
        localStorage.setItem('tisenang_latest_experiment_rows', JSON.stringify(rowsForStorage));
        localStorage.setItem('tisenang_misi2_active_step', 'COLLECT');
      } catch {
        // ignore
      }

      storage.completeMission(studentId, missionId, 95, 120);

      window.dispatchEvent(
        new CustomEvent('tisenang_experiment_saved', {
          detail: { rows: rowsForStorage, step: 'COLLECT' },
        })
      );
      window.dispatchEvent(new CustomEvent('tisenang_missions_updated'));

      setSaveStatus({
        type: 'success',
        message: 'Hasil Simulasi Virtual berhasil disimpan! Mengalihkan ke Misi 2 Tahap 3 (Kumpul Data)...',
      });

      setTimeout(() => {
        setSaveStatus({ type: 'idle', message: '' });
        if (onNavigateToMisi2) {
          onNavigateToMisi2('COLLECT');
        }
      }, 700);
    } catch {
      setSaveStatus({
        type: 'error',
        message: 'Gagal menyimpan ke Firebase. Cek koneksi internet Anda.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 3500);
    }
  };

  // Download Excel (.xlsx) untuk simulasi virtual
  const handleExportExcel = () => {
    if (recordedRows.length === 0) return;
    const formattedData = recordedRows.map((r) => {
      if (selectedSubjectId === 'sbj-matematika') {
        return {
          No: r.no,
          'Variabel Bebas (X)': r.param1,
          'Variabel Terikat (Y)': r.param2,
          'Prediksi Garis (ŷ)': r.param3 || '-',
          'Residual & Keterangan': r.catatan,
        };
      }
      return {
        No: r.no,
        'Waktu (detik)': r.param1,
        'Suhu Air (°C)': r.param2,
        'Penguapan & Kalor': r.param3 || '-',
        'Keterangan / Kondisi': r.catatan,
      };
    });
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Simulasi Virtual');
    const namaFile =
      selectedSubjectId === 'sbj-matematika'
        ? 'Simulasi_Virtual_Regresi_Linear.xlsx'
        : 'Simulasi_Virtual_Suhu_Kalor_Penguapan.xlsx';
    XLSX.writeFile(workbook, namaFile);
  };

  const currentSubject = SUBJECT_OPTIONS.find((s) => s.id === selectedSubjectId);

  return (
    <div className="space-y-6">
      {/* Header Utama: Simulasi Virtual & Kotak Pilih Mata Pelajaran Diperkecil */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-3xl border border-indigo-500/30 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/40 text-[10px] font-black tracking-wider uppercase">
                Laboratorium Saintifik Maya
              </span>
              <span className="text-[11px] font-bold text-slate-300">
                Kelas {className}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <FlaskConical className="w-6 h-6 text-indigo-400" />
              <span>Simulasi Virtual</span>
            </h1>
          </div>

          {/* Kotak Pilih Mata Pelajaran Diperkecil */}
          <div className="relative" ref={dropdownRef}>
            <button
              type="button"
              id="btn-pilih-mata-pelajaran"
              onClick={() => setIsSubjectDropdownOpen(!isSubjectDropdownOpen)}
              className="px-4 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-white border border-slate-700 hover:border-indigo-400/80 shadow-md flex items-center justify-between gap-3 text-left transition-all cursor-pointer min-w-[220px] sm:min-w-[260px]"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${
                    currentSubject
                      ? currentSubject.color
                      : 'text-indigo-400 bg-indigo-500/20 border-indigo-400/40'
                  }`}
                >
                  {currentSubject ? (
                    <currentSubject.icon className="w-4 h-4" />
                  ) : (
                    <BookOpen className="w-4 h-4" />
                  )}
                </div>
                <div className="min-w-0">
                  <span className="block text-[9px] font-black uppercase tracking-wider text-slate-400">
                    Pilih Mata Pelajaran
                  </span>
                  <span className="block text-xs font-black text-white truncate">
                    {currentSubject ? currentSubject.name : 'Pilih Mata Pelajaran'}
                  </span>
                </div>
              </div>
              <ChevronDown
                className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                  isSubjectDropdownOpen ? 'rotate-180 text-indigo-400' : ''
                }`}
              />
            </button>

            {/* Menu Dropdown: Matematika, Fisika, Kimia, Biologi */}
            {isSubjectDropdownOpen && (
              <div className="absolute right-0 top-full mt-2 w-72 sm:w-80 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden divide-y divide-slate-800 animate-in fade-in duration-150">
                {SUBJECT_OPTIONS.map((subj) => {
                  const IconComponent = subj.icon;
                  const isSelected = selectedSubjectId === subj.id;
                  const isUnderDev = subj.id === 'sbj-kimia' || subj.id === 'sbj-biologi';
                  return (
                    <button
                      key={subj.id}
                      type="button"
                      onClick={() => {
                        setSelectedSubjectId(subj.id);
                        setIsSubjectDropdownOpen(false);
                      }}
                      className={`w-full p-3 flex items-center justify-between text-left transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-950/70 text-indigo-200'
                          : 'hover:bg-slate-800/80 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${subj.color}`}
                        >
                          <IconComponent className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <span className="font-black text-xs block text-white">
                            {subj.name}
                          </span>
                          <span
                            className={`text-[10px] block truncate ${
                              isUnderDev ? 'text-amber-400 font-bold' : 'text-slate-400'
                            }`}
                          >
                            {subj.title}
                          </span>
                        </div>
                      </div>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 ml-2" />
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* =========================================================================
          KONDISI 2: KIMIA & BIOLOGI ("Sedang dalam pengembangan")
          ========================================================================= */}
      {(selectedSubjectId === 'sbj-kimia' || selectedSubjectId === 'sbj-biologi') && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-12 text-center space-y-4">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border border-amber-500/20 text-amber-500 flex items-center justify-center mx-auto">
            {selectedSubjectId === 'sbj-kimia' ? (
              <Flame className="w-8 h-8" />
            ) : (
              <Droplets className="w-8 h-8" />
            )}
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Simulasi {selectedSubjectId === 'sbj-kimia' ? 'Kimia' : 'Biologi'}
            </h3>
            <p className="text-sm font-bold text-amber-500 dark:text-amber-400">
              Sedang dalam pengembangan
            </p>
          </div>
        </div>
      )}

      {/* =========================================================================
          KONDISI 3: FISIKA ("simulasi suhu dan kalor yang menyebabkan penguapan")
          ========================================================================= */}
      {selectedSubjectId === 'sbj-fisika' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 text-[10px] font-black uppercase">
                  Fisika: Termal & Fase Zat
                </span>
                <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
                  <Thermometer className="w-5 h-5 text-rose-600" />
                  <span>Simulasi Suhu dan Kalor yang Menyebabkan Penguapan</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Amati bagaimana energi kalor (<code className="font-mono text-rose-600 font-bold">Q = m · c · ΔT</code>) menaikkan suhu air hingga mencapai titik didih dan menyebabkan perubahan wujud menjadi uap air (<code className="font-mono text-cyan-600 font-bold">Q = m_uap · U</code>).
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRecordDataSuhu}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>Catat ke Tabel</span>
                </button>
              </div>
            </div>

            {/* Stage Simulasi Visual: Bejana Pemanasan & Penguapan */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              {/* Visual Bejana Gelas Ukur, Pemanas, Termometer & Uap Air */}
              <div className="lg:col-span-6 bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl p-6 border border-slate-800 flex flex-col items-center justify-center relative min-h-[400px] overflow-hidden">
                {/* Animasi Uap Air Menguap (Steam Vapor) saat suhu tinggi / mendidih */}
                {heaterOn && waterTemp >= 60 && (
                  <div className="absolute top-8 left-16 right-16 flex justify-around pointer-events-none z-30">
                    <div
                      className={`w-6 h-14 bg-white/30 rounded-full blur-xs transition-all duration-300 animate-pulse ${
                        waterTemp >= 90 ? 'opacity-90 scale-125' : 'opacity-40'
                      }`}
                    />
                    <div
                      className={`w-8 h-16 bg-white/35 rounded-full blur-xs transition-all duration-300 animate-bounce delay-150 ${
                        waterTemp >= 90 ? 'opacity-95 scale-125' : 'opacity-50'
                      }`}
                    />
                    <div
                      className={`w-5 h-12 bg-white/30 rounded-full blur-xs transition-all duration-300 animate-pulse delay-300 ${
                        waterTemp >= 90 ? 'opacity-90 scale-125' : 'opacity-40'
                      }`}
                    />
                  </div>
                )}

                {/* Layar Digital Suhu (LCD Termometer Digital) */}
                <div className="absolute top-4 right-4 bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center shadow-md z-20">
                  <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-sans">
                    Probe Suhu Air
                  </span>
                  <span className="text-xl font-black text-rose-400">
                    {waterTemp.toFixed(1)}°C
                  </span>
                </div>

                {/* Indikator Status Penguapan */}
                <div className="absolute top-4 left-4 bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl text-left shadow-md z-20">
                  <span className="block text-[9px] uppercase tracking-wider text-slate-400">
                    Air Menguap
                  </span>
                  <span className="text-xs font-mono font-black text-cyan-300">
                    {evaporatedVolume} mL
                  </span>
                </div>

                {/* Visual Termometer Batang Kaca Analog (Kiri) */}
                <div className="absolute left-6 top-16 bottom-16 w-5 bg-slate-800 rounded-full p-0.5 border border-slate-700 flex flex-col justify-end items-center z-10">
                  <div
                    className="w-3 bg-gradient-to-t from-rose-600 to-red-400 rounded-full transition-all duration-300"
                    style={{
                      height: `${Math.min(100, Math.max(10, ((waterTemp - 20) / 80) * 100))}%`,
                    }}
                  />
                  <div className="w-5 h-5 rounded-full bg-rose-600 -mb-1 shadow-xs" />
                  <span className="text-[8px] font-mono text-slate-400 mt-2">°C</span>
                </div>

                {/* Gelas Ukur / Bejana Kalorimeter */}
                <div className="relative w-48 h-64 border-4 border-t-0 border-slate-400/60 rounded-b-3xl bg-slate-800/30 flex flex-col justify-end p-2 overflow-hidden shadow-2xl backdrop-blur-xs mt-6">
                  {/* Skala Ukur Garis-Garis Gelas Ukur */}
                  <div className="absolute right-2 top-4 bottom-4 flex flex-col justify-between text-[8px] font-mono text-slate-500 pointer-events-none select-none">
                    <span>— 250 mL</span>
                    <span>— 200 mL</span>
                    <span>— 150 mL</span>
                    <span>— 100 mL</span>
                    <span>— 50 mL</span>
                  </div>

                  {/* Probe Sensor yang Tercelup ke Air */}
                  <div className="absolute top-0 left-12 w-2 h-44 bg-slate-400 rounded-b-md z-20 shadow-md border border-slate-500 flex flex-col justify-end items-center">
                    <div className="w-2.5 h-6 bg-rose-500 rounded-b-sm" />
                  </div>

                  {/* Batang Pengaduk */}
                  <div className="absolute top-0 left-24 w-1.5 h-48 bg-cyan-200/60 rounded-b-full z-20 shadow-xs transform rotate-2" />

                  {/* Cairan Air di dalam Gelas Ukur */}
                  <div
                    className={`w-full rounded-b-2xl transition-all duration-500 relative overflow-hidden flex items-center justify-center ${
                      waterTemp > 75
                        ? 'bg-gradient-to-t from-orange-500/80 via-amber-500/70 to-yellow-400/60'
                        : waterTemp > 45
                        ? 'bg-gradient-to-t from-amber-500/80 via-cyan-500/70 to-blue-400/60'
                        : 'bg-gradient-to-t from-blue-600/80 via-cyan-500/70 to-sky-400/60'
                    }`}
                    style={{
                      height: `${(waterVolume / 250) * 85}%`,
                    }}
                  >
                    {/* Gelembung Udara saat mendidih atau dipanaskan */}
                    {heaterOn && (
                      <div className="absolute inset-0 pointer-events-none flex justify-around">
                        <span className="w-2 h-2 rounded-full bg-white/60 animate-bounce delay-100 mt-12" />
                        <span className="w-1.5 h-1.5 rounded-full bg-white/70 animate-ping delay-300 mt-20" />
                        <span className="w-2.5 h-2.5 rounded-full bg-white/50 animate-bounce delay-200 mt-6" />
                      </div>
                    )}
                    <span className="text-[11px] font-bold text-white/90 z-10 font-mono drop-shadow-md">
                      Air {waterVolume} mL
                    </span>
                  </div>
                </div>

                {/* Elemen Pemanas Kompor / Heater di Bawah Gelas */}
                <div
                  className={`w-56 h-7 rounded-t-xl border-t-2 transition-all duration-300 flex items-center justify-center gap-1 mt-1 ${
                    heaterOn
                      ? 'bg-gradient-to-r from-red-600 via-orange-500 to-red-600 border-red-400 shadow-lg shadow-orange-500/50'
                      : 'bg-slate-800 border-slate-700'
                  }`}
                >
                  <span className="text-[9px] font-black uppercase tracking-wider text-white">
                    {heaterOn ? `🔥 HEATER AKTIF (${heaterPower} WATT)` : 'HEATER STANDBY'}
                  </span>
                </div>

                {/* Status Penguapan Real-Time */}
                <div className="mt-3 text-center">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-[10px] font-black tracking-wide ${
                      waterTemp >= 95
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                        : waterTemp >= 65
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {waterTemp >= 95
                      ? '💨 Mendidih & Terjadi Penguapan Intensif'
                      : waterTemp >= 65
                      ? '♨️ Terjadi Penguapan (Evaporasi Permukaan)'
                      : '❄️ Pemanasan Awal (Belum Terjadi Penguapan)'}
                  </span>
                </div>
              </div>

              {/* Kontrol & Panel Instrumen Simulasi Penguapan */}
              <div className="lg:col-span-6 space-y-4">
                <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase text-slate-500">
                      Kontrol Pemanas & Durasi
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                      Waktu: {timerSeconds} detik
                    </span>
                  </div>

                  {/* Tombol ON / OFF Heater */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setHeaterOn(!heaterOn)}
                      className={`flex-1 py-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        heaterOn
                          ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/25'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/25'
                      }`}
                    >
                      {heaterOn ? <Square className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                      <span>{heaterOn ? 'Matikan Pemanas (OFF)' : 'Nyalakan Pemanas (ON)'}</span>
                    </button>

                    <button
                      onClick={() => {
                        setHeaterOn(false);
                        setWaterTemp(25.0);
                        setWaterVolume(initialWaterVolume);
                        setTimerSeconds(0);
                        setCalorimeterDataPoints([{ t: 0, temp: 25.0 }]);
                      }}
                      className="px-3.5 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 text-xs font-bold"
                      title="Reset simulasi ke kondisi awal"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Slider Daya Pemanas */}
                  <div>
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-slate-600 dark:text-slate-400">Daya Pemanas Kalor (Watt):</span>
                      <span className="text-rose-600 font-mono font-black">{heaterPower} Watt</span>
                    </div>
                    <input
                      type="range"
                      min="50"
                      max="500"
                      step="25"
                      value={heaterPower}
                      onChange={(e) => setHeaterPower(Number(e.target.value))}
                      className="w-full accent-rose-600 cursor-pointer"
                    />
                  </div>

                  {/* Indikator Volume Air Sisa & Volume Menguap */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        Volume Air Sisa (m)
                      </span>
                      <span className="text-sm font-black text-cyan-600 font-mono">
                        {waterVolume} mL
                      </span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        Air yang Menguap
                      </span>
                      <span className="text-sm font-black text-rose-500 font-mono">
                        {evaporatedVolume} mL
                      </span>
                    </div>
                  </div>
                </div>

                {/* Kurva Kenaikan Suhu Real-time */}
                <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between text-xs font-black uppercase text-slate-500">
                    <span>Grafik Suhu (°C) vs Waktu (s)</span>
                    <span className="text-rose-600 font-mono font-bold">ΔT = +{(waterTemp - 25.0).toFixed(1)}°C</span>
                  </div>
                  <div className="h-24 w-full bg-slate-900 rounded-xl p-2 flex items-end gap-1 overflow-hidden">
                    {calorimeterDataPoints.map((pt, i) => (
                      <div
                        key={i}
                        className="flex-1 bg-rose-500 rounded-t-xs hover:bg-rose-400 transition-all min-w-[4px]"
                        style={{
                          height: `${Math.min(100, Math.max(10, ((pt.temp - 20) / 80) * 100))}%`,
                        }}
                        title={`t=${pt.t}s : ${pt.temp}°C`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          KONDISI 4: MATEMATIKA ("Laboratorium Regresi Linear Interaktif")
          ========================================================================= */}
      {selectedSubjectId === 'sbj-matematika' && (
        <LaboratoriumRegresiLinear
          onCopyTable={(rows) => {
            const formattedRows: SimulasiDataRow[] = rows.map((r, idx) => ({
              id: `sim-reg-${Date.now()}-${idx}`,
              no: idx + 1,
              param1: r.param1,
              param2: r.param2,
              param3: r.param3,
              catatan: r.catatan,
            }));
            setRecordedRows(formattedRows);
          }}
          onRecordData={(data) => {
            const newRow: SimulasiDataRow = {
              id: `sim-reg-${Date.now()}`,
              no: recordedRows.length + 1,
              param1: data.param1,
              param2: data.param2,
              param3: data.param3,
              catatan: data.catatan,
            };
            setRecordedRows((prev) => [...prev, newRow]);
          }}
        />
      )}

      {/* =========================================================================
          TABEL DATA PENGAMATAN SIMULASI VIRTUAL
          (Hanya tampil saat Fisika atau Matematika aktif)
          ========================================================================= */}
      {(selectedSubjectId === 'sbj-fisika' || selectedSubjectId === 'sbj-matematika') && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                <span>Tabel Data Pengamatan Simulasi Virtual</span>
              </h3>
              <p className="text-xs text-slate-500">
                Data yang tercatat dari percobaan simulasi dapat disimpan langsung ke database misi murid.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {recordedRows.length > 0 && (
                <button
                  id="btn-download-excel-simulasi"
                  onClick={handleExportExcel}
                  className="px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  title="Download tabel dalam format Excel (.xlsx)"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Download Excel (.xlsx)</span>
                </button>
              )}

              <button
                id="btn-simpan-misi-simulasi"
                onClick={handleSaveToStudentMission}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Simpan ke Database Misi Murid</span>
              </button>

              {recordedRows.length > 0 && (
                <button
                  onClick={() => setRecordedRows([])}
                  className="p-2 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-bold"
                  title="Hapus semua baris"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Notifikasi Status Simpan */}
          {saveStatus.message && (
            <div
              className={`p-3 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 ${
                saveStatus.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : saveStatus.type === 'error'
                  ? 'bg-rose-50 text-rose-800 border border-rose-300'
                  : 'bg-blue-50 text-blue-800 border border-blue-300'
              }`}
            >
              <div className="flex items-center gap-2">
                {saveStatus.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Info className="w-4 h-4" />
                )}
                <span>{saveStatus.message}</span>
              </div>
              {saveStatus.type === 'success' && (
                <a
                  href={STUDENT_DRIVE_FOLDER_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold hover:bg-emerald-700 flex items-center gap-1"
                >
                  <span>Folder Google Drive</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          )}

          {/* Tabel Isi */}
          {recordedRows.length === 0 ? (
            <div className="py-10 text-center space-y-2 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 p-4">
              <FileSpreadsheet className="w-8 h-8 text-slate-400 mx-auto" />
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Belum ada data pengamatan tercatat
              </h4>
              <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                {selectedSubjectId === 'sbj-matematika'
                  ? 'Isi data pada tabel 10 baris di atas, lalu klik tombol "Salin tabel input data ke tabel data pengamatan".'
                  : 'Jalankan simulasi di atas dan klik tombol "Catat ke Tabel" untuk mengumpulkan data hasil eksperimen.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 font-black uppercase text-slate-600 dark:text-slate-300 text-[10px]">
                  <tr>
                    <th className="p-3 w-12 text-center">No</th>
                    <th className="p-3">
                      {selectedSubjectId === 'sbj-matematika' ? 'Variabel Bebas (X)' : 'Parameter 1'}
                    </th>
                    <th className="p-3">
                      {selectedSubjectId === 'sbj-matematika' ? 'Variabel Terikat (Y)' : 'Parameter 2'}
                    </th>
                    <th className="p-3">
                      {selectedSubjectId === 'sbj-matematika' ? 'Prediksi Garis (ŷ)' : 'Parameter 3'}
                    </th>
                    <th className="p-3">
                      {selectedSubjectId === 'sbj-matematika' ? 'Residual & Keterangan' : 'Keterangan / Kondisi'}
                    </th>
                    <th className="p-3 w-12 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                  {recordedRows.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                      <td className="p-3 text-center font-bold text-slate-400">{row.no}</td>
                      <td className="p-3 font-mono font-bold text-indigo-600">{row.param1}</td>
                      <td className="p-3 font-mono font-bold text-rose-600">{row.param2}</td>
                      <td className="p-3 font-mono text-slate-700 dark:text-slate-300">{row.param3 || '-'}</td>
                      <td className="p-3">{row.catatan}</td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() =>
                            setRecordedRows((prev) =>
                              prev.filter((r) => r.id !== row.id).map((r, idx) => ({ ...r, no: idx + 1 }))
                            )
                          }
                          className="text-slate-300 hover:text-rose-600"
                          title="Hapus baris"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tombol Selesai Eksperimen -> Membuka Misi 4 */}
      {onFinishExperiment && (
        <div className="flex justify-end pt-3">
          <button
            id="btn-selesai-eksperimen-virtual-lab"
            type="button"
            onClick={onFinishExperiment}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 text-white font-black text-xs sm:text-sm shadow-md flex items-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>Selesai Eksperimen & Buka Misi 4</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
