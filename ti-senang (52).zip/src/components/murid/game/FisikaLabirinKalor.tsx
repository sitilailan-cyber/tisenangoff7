import React, { useState } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Compass,
  AlertTriangle,
  X,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface FisikaLabirinKalorProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface MazeQuestion {
  id: number;
  question: string;
  topic: string;
  options: string[];
  correct: number;
  explanation: string;
}

const LABIRIN_QUESTIONS: MazeQuestion[] = [
  {
    id: 1,
    topic: 'Kalor Jenis',
    question: 'Banyaknya kalor yang diperlukan oleh 1 kg zat untuk menaikkan suhunya sebesar 1°C disebut...',
    options: ['Kapasitas kalor', 'Kalor jenis (c)', 'Kalor laten lebur', 'Konduktivitas termal'],
    correct: 1,
    explanation: 'Kalor jenis (c) adalah banyaknya kalor yang dibutuhkan 1 kg zat untuk naik suhu 1°C.',
  },
  {
    id: 2,
    topic: 'Persamaan Kalor',
    question: 'Rumus untuk menghitung kalor yang diserap atau dilepaskan pada perubahan suhu zat adalah...',
    options: ['Q = m · c · ΔT', 'Q = m · L', 'Q = P · t', 'Q = k · A · ΔT / L'],
    correct: 0,
    explanation: 'Persamaan kalor perubahan suhu: Q = m · c · ΔT (massa × kalor jenis × perubahan suhu).',
  },
  {
    id: 3,
    topic: 'Asas Black',
    question: 'Menurut Asas Black, pada pencampuran dua zat yang suhunya berbeda dalam wadah terisolasi...',
    options: [
      'Kalor yang dilepas sama dengan kalor yang diterima (Qlepas = Qterima)',
      'Suhu akhir campuran selalu sama dengan suhu zat terpanas',
      'Kalor yang diserap selalu lebih besar daripada yang dilepas',
      'Massa kedua zat akan bertambah akibat perpindahan energi',
    ],
    correct: 0,
    explanation: 'Asas Black: Kalor yang dilepaskan zat bersuhu tinggi sama dengan kalor yang diserap zat bersuhu rendah.',
  },
  {
    id: 4,
    topic: 'Konduksi',
    question: 'Perpindahan kalor melalui zat padat tanpa disertai perpindahan partikel zatnya dinamakan...',
    options: ['Konveksi', 'Radiasi', 'Konduksi', 'Sublimasi'],
    correct: 2,
    explanation: 'Konduksi terjadi melalui rambatan getaran partikel tanpa zat perantaranya berpindah tempat.',
  },
  {
    id: 5,
    topic: 'Konveksi',
    question: 'Peristiwa angin darat dan angin laut di kawasan pesisir pantai terjadi akibat perpindahan kalor secara...',
    options: ['Konduksi', 'Konveksi alami', 'Radiasi inframerah', 'Pemuaian gas'],
    correct: 1,
    explanation: 'Konveksi adalah perpindahan kalor yang disertai aliran massa fluida (udara panas naik, dingin mengalir).',
  },
  {
    id: 6,
    topic: 'Radiasi',
    question: 'Pancaran energi panas matahari yang sampai ke bumi melalui ruang hampa terjadi melalui...',
    options: ['Radiasi gelombang elektromagnetik', 'Konduksi atmosfer', 'Konveksi partikel kosmik', 'Adveksi termal'],
    correct: 0,
    explanation: 'Radiasi tidak membutuhkan zat perantara, kalor merambat dalam bentuk gelombang elektromagnetik.',
  },
  {
    id: 7,
    topic: 'Kalor Laten',
    question: 'Kalor yang diserap atau dilepaskan zat untuk mengubah wujudnya pada suhu tetap dinamakan...',
    options: ['Kalor laten (Q = m · L)', 'Kalor jenis uap', 'Kapasitas termal', 'Entalpi spesifik'],
    correct: 0,
    explanation: 'Kalor laten adalah kalor untuk mengubah wujud zat (mencair/menguap) tanpa kenaikan suhu.',
  },
  {
    id: 8,
    topic: 'Skala Celcius',
    question: 'Titik tetap bawah (0°C) dan titik tetap atas (100°C) pada skala Celcius ditentukan berdasarkan...',
    options: [
      'Titik lebur es murni dan titik didih air murni pada 1 atm',
      'Suhu tubuh manusia dan suhu ruangan standar',
      'Titik beku alkohol dan titik leleh raksa murni',
      'Suhu nol mutlak dan radiasi benda hitam',
    ],
    correct: 0,
    explanation: 'Skala Celcius dikalibrasi pada es melebur (0°C) dan air mendidih (100°C) pada tekanan normal.',
  },
  {
    id: 9,
    topic: 'Kalorimeter',
    question: 'Alat laboratorium berdinding insulasi ganda yang digunakan untuk menentukan kalor jenis benda adalah...',
    options: ['Kalorimeter', 'Termokopel', 'Barometer', 'Piknometer'],
    correct: 0,
    explanation: 'Kalorimeter dirancang kedap pertukaran kalor lingkungan untuk membuktikan Asas Black.',
  },
  {
    id: 10,
    topic: 'Pemuaian',
    question: 'Mengapa pada sambungan rel kereta api sengaja diberikan celah ruang yang renggang?',
    options: [
      'Untuk memberi ruang pemuaian panjang logam rel saat cuaca panas terik',
      'Agar laju gesekan roda kereta api menjadi lebih pelan',
      'Untuk mengalirkan air hujan agar rel tidak mudah berkarat',
      'Mengurangi getaran suara saat kereta melintas di malam hari',
    ],
    correct: 0,
    explanation: 'Celah pemuaian mencegah rel melengkung atau bengkok akibat pertambahan panjang di siang hari.',
  },
];

export const FisikaLabirinKalor: React.FC<FisikaLabirinKalorProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  const [currentPos, setCurrentPos] = useState<number>(0);
  const [fireDistance, setFireDistance] = useState<number>(3);
  const [score, setScore] = useState<number>(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isCorrectAnswer, setIsCorrectAnswer] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);

  const currentQ = LABIRIN_QUESTIONS[currentPos];

  const handleSelectOption = (idx: number) => {
    if (isAnswered || isFinished || isGameOver) return;
    setSelectedOpt(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correct;
    setIsCorrectAnswer(isCorrect);

    if (isCorrect) {
      joyfulGameMusic.playCorrect();
      setScore((prev) => prev + 10);
      setFireDistance((prev) => Math.min(4, prev + 1));
    } else {
      joyfulGameMusic.playWrong();
      const nextDistance = fireDistance - 1;
      setFireDistance(nextDistance);
      if (nextDistance <= 0) {
        setIsGameOver(true);
      }
    }
  };

  const handleNextCheckpoint = () => {
    if (currentPos + 1 < LABIRIN_QUESTIONS.length) {
      setCurrentPos((prev) => prev + 1);
      setSelectedOpt(null);
      setIsAnswered(false);
      setIsCorrectAnswer(false);
    } else {
      setIsFinished(true);
      joyfulGameMusic.playVictory();
    }
  };

  const handleRetryCheckpoint = () => {
    setSelectedOpt(null);
    setIsAnswered(false);
    setIsCorrectAnswer(false);
  };

  const handleRestart = () => {
    setCurrentPos(0);
    setFireDistance(3);
    setScore(0);
    setSelectedOpt(null);
    setIsAnswered(false);
    setIsCorrectAnswer(false);
    setIsFinished(false);
    setIsGameOver(false);
  };

  return (
    <div className="w-full max-w-xl mx-auto rounded-2xl overflow-hidden shadow-xl border border-orange-500/40 bg-slate-950 text-white font-sans text-xs">
      {/* Top Header Ringkas */}
      <div className="px-2.5 py-1.5 bg-slate-900/90 border-b border-orange-950/60 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 border border-slate-700 cursor-pointer shrink-0"
            >
              ← <span>Game</span>
            </button>
          )}

          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg bg-orange-500/20 border border-orange-400/40 text-orange-300 font-extrabold text-[10px] sm:text-[11px] truncate">
            <span>🔥</span>
            <span className="truncate">Labirin Dikejar Api</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0 text-[10px] sm:text-[11px]">
          <div
            className={`px-1.5 py-0.5 rounded-lg border font-bold flex items-center gap-1 ${
              fireDistance <= 1
                ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                : 'bg-slate-900 border-orange-800/60 text-amber-300'
            }`}
          >
            <span>🔥</span>
            <span>Jarak: <strong className={fireDistance <= 1 ? 'text-rose-400' : 'text-emerald-300'}>{fireDistance}</strong></span>
          </div>

          <div className="px-1.5 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-amber-300 font-bold">
            Skor: <span className="font-mono text-white">{score}</span>
          </div>

          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center justify-center cursor-pointer shrink-0"
              title="Tutup Game & Kembali ke Halaman Misi 4 Game Sains"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Rute Labirin 10 Pos Kompak */}
      <div className="px-2 py-1 bg-gradient-to-b from-slate-900 to-slate-950 border-b border-orange-950/50">
        <div className="flex items-center justify-between text-[9px] text-slate-400 mb-0.5">
          <span className="flex items-center gap-1 font-bold text-orange-300">
            <Compass className="w-2.5 h-2.5 text-orange-400" />
            <span>Rute Labirin:</span>
          </span>
          <span className="font-mono text-cyan-300 font-bold">
            Pos {currentPos + 1}/10
          </span>
        </div>

        <div className="grid grid-cols-10 gap-0.5 sm:gap-1 relative py-0.5">
          {LABIRIN_QUESTIONS.map((q, idx) => {
            const isPassed = idx < currentPos;
            const isCurrent = idx === currentPos;
            const isFireHere = idx === Math.max(0, currentPos - fireDistance);

            return (
              <div key={q.id} className="relative flex flex-col items-center">
                <div
                  className={`w-full aspect-square rounded-md sm:rounded-lg flex items-center justify-center font-black text-[8px] sm:text-[9.5px] transition-all relative ${
                    isCurrent
                      ? 'bg-cyan-500 text-slate-950 ring-1 sm:ring-2 ring-cyan-400 shadow-sm scale-105 z-10'
                      : isPassed
                      ? 'bg-emerald-900/60 border border-emerald-500/50 text-emerald-300'
                      : 'bg-slate-900 border border-slate-800 text-slate-600'
                  }`}
                >
                  {isCurrent ? '🧊' : isPassed ? '✓' : idx + 1}
                </div>

                {isFireHere && !isFinished && !isPassed && (
                  <div className="absolute -bottom-3.5 flex flex-col items-center animate-bounce z-20">
                    <span className="text-[10px]">🔥</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {fireDistance <= 1 && !isGameOver && !isFinished && (
          <div className="mt-1 p-0.5 px-1.5 rounded-md bg-rose-500/20 border border-rose-500/50 text-rose-300 text-[9px] font-bold flex items-center justify-center gap-1 animate-pulse">
            <AlertTriangle className="w-2.5 h-2.5 text-rose-400 shrink-0" />
            <span>Awas! Emot Api 🔥 tepat di belakangmu!</span>
          </div>
        )}
      </div>

      {/* Screen Game Over / Finish / Pertanyaan */}
      {isGameOver ? (
        <div className="p-3 sm:p-4 text-center space-y-2 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-11 h-11 mx-auto rounded-xl bg-rose-600/30 border border-rose-500 flex items-center justify-center">
            <span className="text-xl">🔥💥</span>
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-rose-400">Tertangkap Api!</h2>
            <p className="text-slate-300 text-[10px] sm:text-[11px]">Coba lagi untuk menaklukkan labirin.</p>
          </div>
          <button
            type="button"
            onClick={handleRestart}
            className="px-3.5 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-[11px] shadow-sm flex items-center gap-1.5 mx-auto cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Ulangi Labirin</span>
          </button>
        </div>
      ) : isFinished ? (
        <div className="p-3 sm:p-4 text-center space-y-2 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-11 h-11 mx-auto rounded-xl bg-gradient-to-tr from-cyan-400 via-blue-500 to-emerald-400 p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <span className="text-xl">🧊🏆</span>
            </div>
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white">Lolos dari Labirin! 🎉</h2>
            <p className="text-slate-300 text-[10px] sm:text-[11px]">Kamu menuntaskan 10 pos Suhu dan Kalor!</p>
          </div>
          <div className="flex items-center justify-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={handleRestart}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] transition-all border border-slate-700 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Main Lagi</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(100)}
              className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-orange-500 to-yellow-500 text-slate-950 font-black text-[11px] shadow-md flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <Trophy className="w-3 h-3" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-2 sm:p-2.5 space-y-1.5 sm:space-y-2">
          {/* Header Soal */}
          <div className="flex items-center justify-between text-[9px] sm:text-[10px] text-slate-400">
            <span className="font-extrabold text-orange-400 uppercase tracking-wider truncate">
              {currentQ.topic}
            </span>
            <span className="px-1.5 py-0.5 rounded-md bg-slate-900 border border-slate-800 font-mono font-bold text-slate-300 shrink-0">
              Pos {currentPos + 1}/10
            </span>
          </div>

          {/* Kotak Pertanyaan */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-slate-900/90 border border-orange-900/60 shadow-xs">
            <h3 className="text-[11px] sm:text-xs font-bold text-white leading-snug">
              {currentQ.question}
            </h3>
          </div>

          {/* 4 Opsi */}
          <div className="grid grid-cols-1 gap-1">
            {currentQ.options.map((opt, i) => {
              const isSelected = selectedOpt === i;
              const isCorrectOpt = i === currentQ.correct;

              let btnStyle = 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200';
              if (isAnswered) {
                if (isCorrectOpt) {
                  btnStyle = 'bg-emerald-600/90 border-emerald-400 text-white font-bold ring-1 ring-emerald-400/50';
                } else if (isSelected) {
                  btnStyle = 'bg-rose-600/90 border-rose-400 text-white font-bold ring-1 ring-rose-400/50';
                } else {
                  btnStyle = 'bg-slate-900/30 border-slate-800/60 text-slate-500';
                }
              }

              return (
                <button
                  key={i}
                  type="button"
                  disabled={isAnswered}
                  onClick={() => handleSelectOption(i)}
                  className={`w-full py-1 sm:py-1.5 px-2 sm:px-2.5 rounded-lg sm:rounded-xl border transition-all flex items-center gap-1.5 sm:gap-2 text-left cursor-pointer active:scale-98 ${btnStyle}`}
                >
                  <span className="w-4 h-4 rounded bg-black/40 border border-white/10 flex items-center justify-center text-[9px] font-black shrink-0">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="text-[10px] sm:text-[11px] font-medium flex-1 leading-tight">
                    {opt}
                  </span>
                  {isAnswered && isCorrectOpt && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
                  )}
                  {isAnswered && isSelected && !isCorrectOpt && (
                    <XCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Feedback & Tombol */}
          {isAnswered && (
            <div className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-slate-900/90 border border-orange-900/80 flex items-center justify-between gap-1.5 animate-in fade-in duration-150">
              <p className="text-[9.5px] sm:text-[10.5px] text-slate-300 leading-tight flex-1 line-clamp-2">
                <span className="font-bold text-amber-400">
                  {isCorrectAnswer ? '❄️ Tepat! ' : '⚠️ Salah! '}
                </span>
                {currentQ.explanation}
              </p>
              <div className="flex items-center gap-1 shrink-0">
                {!isCorrectAnswer && (
                  <button
                    type="button"
                    onClick={handleRetryCheckpoint}
                    className="px-2 py-1 rounded-md bg-slate-800 text-slate-200 font-bold text-[9.5px] border border-slate-700 cursor-pointer"
                  >
                    Ulang
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleNextCheckpoint}
                  className="px-2.5 py-1 rounded-md bg-orange-600 hover:bg-orange-500 text-white font-bold text-[10px] sm:text-[11px] shadow-xs transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                >
                  <span>{currentPos + 1 === LABIRIN_QUESTIONS.length ? 'Finish' : 'Lanjut'}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
