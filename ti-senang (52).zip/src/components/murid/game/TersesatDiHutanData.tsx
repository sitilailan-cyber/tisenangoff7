import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Trophy,
  CheckCircle2,
  XCircle,
  Trees,
  Compass,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface TersesatDiHutanDataProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
}

interface StageChallenge {
  id: number;
  stageName: string;
  icon: string;
  question: string;
  hintVisual: {
    type: 'coordinate' | 'scatter' | 'variables' | 'positive_trend' | 'negative_trend';
    detail: string;
  };
  options: {
    id: string;
    label: string;
    sublabel?: string;
    icon: string;
    isCorrect: boolean;
  }[];
}

const STAGES: StageChallenge[] = [
  {
    id: 1,
    stageName: 'Koordinat Titik',
    icon: '📍',
    question: 'Tiko melihat batu penunjuk di koordinat (X = 3, Y = 4). Ke mana arah langkah Tiko?',
    hintVisual: {
      type: 'coordinate',
      detail: 'X mendatar = 3 • Y vertikal = 4',
    },
    options: [
      {
        id: '1a',
        label: '3 langkah mendatar (X), lalu 4 langkah naik (Y)',
        sublabel: 'Sumbu X horizontal & sumbu Y vertikal',
        icon: '🧭',
        isCorrect: true,
      },
      {
        id: '1b',
        label: '4 langkah mendatar (X), lalu 3 langkah naik (Y)',
        sublabel: 'Terbalik antara X dan Y',
        icon: '🧗',
        isCorrect: false,
      },
      {
        id: '1c',
        label: 'Langsung melompat ke titik (0, 0)',
        sublabel: 'Titik asal origin',
        icon: '⭕',
        isCorrect: false,
      },
    ],
  },
  {
    id: 2,
    stageName: 'Diagram Pencar',
    icon: '📊',
    question: 'Tiko mencatat posisi buah jatuh sebagai titik-titik data terpisah. Disebut apakah grafik ini?',
    hintVisual: {
      type: 'scatter',
      detail: 'Sebaran titik data (Scatter Plot)',
    },
    options: [
      {
        id: '2a',
        label: 'Diagram Pencar (Scatter Plot)',
        sublabel: 'Grafik sebaran titik-titik data berpasangan (X, Y)',
        icon: '✨',
        isCorrect: true,
      },
      {
        id: '2b',
        label: 'Diagram Lingkaran (Pie Chart)',
        sublabel: 'Bagan pembagian persentase juring',
        icon: '🥧',
        isCorrect: false,
      },
      {
        id: '2c',
        label: 'Diagram Batang Tegak',
        sublabel: 'Grafik balok kategori tunggal',
        icon: '📶',
        isCorrect: false,
      },
    ],
  },
  {
    id: 3,
    stageName: 'Variabel X dan Y',
    icon: '⏱️',
    question: 'Semakin lama Tiko berjalan (X), semakin jauh jarak ditempuh (Y). Manakah Variabel Bebas (Independen)?',
    hintVisual: {
      type: 'variables',
      detail: 'Variabel X memengaruhi Variabel Y',
    },
    options: [
      {
        id: '3a',
        label: 'Variabel X: Waktu Berjalan',
        sublabel: 'Variabel bebas yang memengaruhi jarak tempuh',
        icon: '⏱️',
        isCorrect: true,
      },
      {
        id: '3b',
        label: 'Variabel Y: Jarak Tempuh',
        sublabel: 'Variabel terikat (dependen)',
        icon: '🗺️',
        isCorrect: false,
      },
      {
        id: '3c',
        label: 'Warna Topi Petualang Tiko',
        sublabel: 'Bukan variabel eksperimen',
        icon: '🧢',
        isCorrect: false,
      },
    ],
  },
  {
    id: 4,
    stageName: 'Hubungan Positif',
    icon: '📈',
    question: 'Saat nilai X bertambah besar, nilai Y juga ikut membesar membentuk tren garis naik ↗️. Hubungan apakah ini?',
    hintVisual: {
      type: 'positive_trend',
      detail: 'Korelasi Positif (Garis Naik Searah)',
    },
    options: [
      {
        id: '4a',
        label: 'Korelasi Positif (Hubungan Positif)',
        sublabel: 'Kedua variabel bergerak searah bertambah naik',
        icon: '📈',
        isCorrect: true,
      },
      {
        id: '4b',
        label: 'Korelasi Negatif (Hubungan Terbalik)',
        sublabel: 'Satu naik, variabel lainnya justru turun',
        icon: '📉',
        isCorrect: false,
      },
      {
        id: '4c',
        label: 'Tidak Ada Hubungan (Acak Total)',
        sublabel: 'Titik tersebar merata tanpa pola tren',
        icon: '〰️',
        isCorrect: false,
      },
    ],
  },
  {
    id: 5,
    stageName: 'Hubungan Negatif',
    icon: '📉',
    question: 'Semakin rimbun kanopi pohon (X), semakin sedikit sinar matahari menembus tanah (Y). Hubungan apakah ini?',
    hintVisual: {
      type: 'negative_trend',
      detail: 'Korelasi Negatif (Garis Turun Berlawanan)',
    },
    options: [
      {
        id: '5a',
        label: 'Korelasi Negatif (Hubungan Negatif)',
        sublabel: 'Nilai X membesar, namun nilai Y menurun berkurang',
        icon: '📉',
        isCorrect: true,
      },
      {
        id: '5b',
        label: 'Korelasi Positif Sempurna',
        sublabel: 'Kedua variabel harus naik bersamaan',
        icon: '📈',
        isCorrect: false,
      },
      {
        id: '5c',
        label: 'Regresi Tanpa Arah',
        sublabel: 'Bukan istilah ilmiah regresi',
        icon: '🔄',
        isCorrect: false,
      },
    ],
  },
];

export const TersesatDiHutanData: React.FC<TersesatDiHutanDataProps> = ({
  onFinishGame,
  onBackToGameList,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(joyfulGameMusic.getIsMuted());
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [feedbackState, setFeedbackState] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Sync mute state with joyfulGameMusic
  useEffect(() => {
    const unsub = joyfulGameMusic.subscribe((_, muted) => {
      setIsMuted(muted);
    });
    return () => unsub();
  }, []);

  const handleToggleMute = () => {
    const nextMuted = joyfulGameMusic.toggleMute();
    setIsMuted(nextMuted);
  };

  const currentStage = STAGES[currentStageIdx];

  const handleSelectOption = (opt: { id: string; isCorrect: boolean }) => {
    if (feedbackState !== 'idle' || isCompleted) return;

    setSelectedOptionId(opt.id);

    if (opt.isCorrect) {
      setFeedbackState('correct');
      joyfulGameMusic.playCorrect();
      setScore((prev) => prev + 20);

      setTimeout(() => {
        if (currentStageIdx + 1 < STAGES.length) {
          setCurrentStageIdx((prev) => prev + 1);
          setSelectedOptionId(null);
          setFeedbackState('idle');
        } else {
          // Finish 5 stages!
          setIsCompleted(true);
          joyfulGameMusic.playVictory();
        }
      }, 1100);
    } else {
      setFeedbackState('wrong');
      joyfulGameMusic.playWrong();
      setTimeout(() => {
        setFeedbackState('idle');
        setSelectedOptionId(null);
      }, 1000);
    }
  };

  const handleRestart = () => {
    setCurrentStageIdx(0);
    setScore(0);
    setSelectedOptionId(null);
    setFeedbackState('idle');
    setIsCompleted(false);
  };

  return (
    <div className="w-full max-w-2xl mx-auto rounded-3xl overflow-hidden shadow-2xl border-2 border-emerald-600/50 relative bg-emerald-950 text-white font-sans">
      {/* LATAR BELAKANG GAMBAR HUTAN DATA DENGAN KANOPI HIJAU DAN CAHAYA */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        {/* Deep emerald forest backdrop */}
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-900 via-teal-950 to-slate-950 opacity-95" />

        {/* Tree silhouettes & mystical fireflies/data points */}
        <svg
          className="absolute inset-0 w-full h-full opacity-20"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          viewBox="0 0 100 100"
        >
          {/* Subtle grid lines like coordinate mesh */}
          <line x1="10" y1="0" x2="10" y2="100" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="30" y1="0" x2="30" y2="100" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="50" y1="0" x2="50" y2="100" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="70" y1="0" x2="70" y2="100" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="90" y1="0" x2="90" y2="100" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="0" y1="20" x2="100" y2="20" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="0" y1="40" x2="100" y2="40" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="0" y1="60" x2="100" y2="60" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          <line x1="0" y1="80" x2="100" y2="80" stroke="#34d399" strokeWidth="0.3" strokeDasharray="1,1" />
          {/* Linear regression path */}
          <path d="M 5,90 Q 30,70 50,50 T 95,15" fill="none" stroke="#facc15" strokeWidth="1.2" strokeDasharray="2,1" />
          {/* Glow scatter dots in forest */}
          <circle cx="20" cy="78" r="1.8" fill="#fbbf24" />
          <circle cx="35" cy="62" r="1.5" fill="#34d399" />
          <circle cx="52" cy="48" r="1.8" fill="#fbbf24" />
          <circle cx="68" cy="36" r="1.5" fill="#34d399" />
          <circle cx="82" cy="24" r="1.8" fill="#fbbf24" />
        </svg>

        {/* Ambient forest sunbeam glow */}
        <div className="absolute top-0 right-10 w-72 h-72 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* HEADER ATAS: NAVIGASI BALIK, PROGRESS 1/5, SKOR, & TOMBOL MUSIK */}
      <div className="relative z-10 p-3 sm:p-4 bg-emerald-950/80 backdrop-blur-md border-b border-emerald-800/60 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 text-xs font-bold transition-all flex items-center gap-1 border border-emerald-700/60 cursor-pointer"
            >
              ← <span className="hidden xs:inline">Pilihan Game</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 font-extrabold text-xs">
            <span>🌲</span>
            <span className="tracking-wide">Hutan Data</span>
          </div>
        </div>

        {/* Status Tengah & Kanan: Progress, Skor Kecil, Tombol Musik */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Progress sederhana 1/5 */}
          <div className="px-3 py-1 rounded-xl bg-emerald-900/90 border border-emerald-600/50 text-white font-extrabold text-xs flex items-center gap-1 shadow-xs">
            <span className="text-emerald-400">Titik:</span>
            <span className="text-amber-300 font-black">{currentStageIdx + 1}/5</span>
          </div>

          {/* Skor kecil */}
          <div className="px-2.5 py-1 rounded-xl bg-slate-900/80 border border-emerald-700/40 text-amber-300 font-bold text-xs">
            Skor: <span className="font-mono font-extrabold text-white">{score}</span>
          </div>

          {/* Tombol 🔊 Musik */}
          <button
            type="button"
            onClick={handleToggleMute}
            className={`p-2 rounded-xl transition-all border cursor-pointer ${
              isMuted
                ? 'bg-emerald-900/60 text-slate-400 border-slate-700'
                : 'bg-amber-500 text-slate-950 border-amber-300 font-bold shadow-md shadow-amber-500/20 active:scale-95'
            }`}
            title={isMuted ? 'Nyalakan Musik' : 'Senyapkan Musik'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 animate-pulse" />}
          </button>
        </div>
      </div>

      {/* PETA 5 TITIK PERSINGGAHAN DENGAN TIKO SEBAGAI KARAKTER KECIL */}
      <div className="relative z-10 px-3 py-2.5 bg-emerald-900/40 border-b border-emerald-800/40">
        <div className="flex items-center justify-between relative px-2 sm:px-6">
          {/* Jalur Peta Garis Penghubung */}
          <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-1 bg-emerald-800 rounded-full z-0" />
          <div
            className="absolute left-6 top-1/2 -translate-y-1/2 h-1 bg-gradient-to-r from-amber-400 to-emerald-400 rounded-full z-0 transition-all duration-500"
            style={{ width: `${(currentStageIdx / (STAGES.length - 1)) * 88}%` }}
          />

          {STAGES.map((s, idx) => {
            const isPassed = idx < currentStageIdx;
            const isCurrent = idx === currentStageIdx;
            return (
              <div key={s.id} className="relative z-10 flex flex-col items-center">
                {/* Karakter Tiko Kecil di atas titik persinggahan aktif */}
                {isCurrent && !isCompleted && (
                  <div className="absolute -top-7 sm:-top-8 flex flex-col items-center animate-bounce">
                    <div className="px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[9px] shadow-xs">
                      Tiko
                    </div>
                    <span className="text-base sm:text-lg">🤖</span>
                  </div>
                )}

                {/* Lingkaran Titik Persinggahan */}
                <div
                  className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-black text-xs transition-all ${
                    isPassed
                      ? 'bg-emerald-500 text-white shadow-md ring-2 ring-emerald-400'
                      : isCurrent
                      ? 'bg-amber-400 text-slate-950 shadow-lg ring-4 ring-amber-300/40 scale-110'
                      : 'bg-emerald-950 border border-emerald-700/60 text-emerald-400/70'
                  }`}
                >
                  {isPassed ? '✓' : idx + 1}
                </div>
                <span className="text-[9px] sm:text-[10px] font-semibold text-emerald-300/80 mt-1 max-w-[50px] text-center truncate hidden xs:block">
                  {s.stageName}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* KONDISI SETELAH 5 TANTANGAN SELESAI: ANIMASI TIKO KELUAR & PESAN SINGKAT "BERHASIL KELUAR! 🎉" */}
      {isCompleted ? (
        <div className="relative z-10 p-6 sm:p-8 text-center space-y-5 animate-in fade-in zoom-in-95 duration-300">
          {/* Animasi Tiko Berhasil Keluar */}
          <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 via-yellow-300 to-emerald-400 p-1 shadow-2xl animate-pulse">
            <div className="w-full h-full bg-emerald-950 rounded-[22px] flex flex-col items-center justify-center">
              <span className="text-4xl animate-bounce">🎉</span>
              <span className="text-2xl mt-0.5">🤖✨</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <span className="px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-black uppercase tracking-wider">
              Regresi Linear Tuntas
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-amber-300 tracking-tight">
              BERHASIL KELUAR! 🎉
            </h2>
            <p className="text-emerald-200 text-xs sm:text-sm max-w-md mx-auto">
              Hebat! Tiko berhasil melewati 5 titik persinggahan Hutan Data dengan memahami koordinat, diagram pencar, serta korelasi regresi linear.
            </p>
          </div>

          {/* Kartu Skor Kemenangan */}
          <div className="max-w-xs mx-auto p-4 rounded-2xl bg-emerald-900/60 border border-emerald-700/60 flex items-center justify-around">
            <div>
              <p className="text-[10px] font-bold text-emerald-300 uppercase">Skor Petualangan</p>
              <p className="text-2xl font-black text-amber-300 font-mono">100</p>
            </div>
            <div className="h-8 w-px bg-emerald-700/60" />
            <div>
              <p className="text-[10px] font-bold text-emerald-300 uppercase">Persinggahan</p>
              <p className="text-2xl font-black text-emerald-300 font-mono">5/5</p>
            </div>
          </div>

          {/* Tombol Aksi Kemenangan */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleRestart}
              className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 font-bold text-xs sm:text-sm transition-all border border-emerald-700/60 flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Main Lagi</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(100)}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-600 text-slate-950 font-black text-xs sm:text-sm shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
            >
              <Trophy className="w-4 h-4 text-slate-950" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* KONTEN TANTANGAN AKTIF (MOBILE-FIRST, 1 PERTANYAAN + PILIHAN CARD BESAR) */
        <div className="relative z-10 p-4 sm:p-6 space-y-4">
          {/* Card Visual / Ilustrasi Mini Persinggahan */}
          <div className="p-3 sm:p-4 rounded-2xl bg-emerald-900/50 border border-emerald-700/60 backdrop-blur-sm flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl sm:text-3xl p-2 rounded-xl bg-emerald-800/60 border border-emerald-600/40">
                {currentStage.icon}
              </span>
              <div>
                <span className="text-[10px] uppercase font-black text-amber-300 tracking-wider">
                  Persinggahan {currentStage.id}
                </span>
                <h3 className="text-sm sm:text-base font-extrabold text-white">
                  {currentStage.stageName}
                </h3>
              </div>
            </div>

            {/* Visualisasi Ringkas Berdasarkan Tipe */}
            <div className="px-3 py-1.5 rounded-xl bg-slate-950/70 border border-emerald-700/40 text-[11px] font-mono font-bold text-amber-300 shrink-0">
              {currentStage.hintVisual.detail}
            </div>
          </div>

          {/* 1 Pertanyaan Utama */}
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-900/80 border-2 border-emerald-600/60 shadow-lg">
            <p className="text-xs sm:text-sm font-semibold text-emerald-200 mb-1 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>Tantangan Tiko:</span>
            </p>
            <h2 className="text-base sm:text-lg font-black text-white leading-snug">
              {currentStage.question}
            </h2>
          </div>

          {/* Pilihan Jawaban: Card / Tombol Besar dan Mudah Disentuh di HP */}
          <div className="space-y-2.5">
            {currentStage.options.map((opt) => {
              const isSelected = selectedOptionId === opt.id;
              let btnStyle = 'bg-emerald-900/60 hover:bg-emerald-800/80 border-emerald-700/70 text-white';

              if (isSelected) {
                if (feedbackState === 'correct') {
                  btnStyle = 'bg-emerald-600 border-emerald-300 text-white ring-4 ring-emerald-400/50 scale-[1.01]';
                } else if (feedbackState === 'wrong') {
                  btnStyle = 'bg-rose-700 border-rose-400 text-white ring-4 ring-rose-400/50 animate-shake';
                }
              }

              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={feedbackState !== 'idle'}
                  onClick={() => handleSelectOption(opt)}
                  className={`w-full p-3.5 sm:p-4 rounded-2xl border-2 transition-all flex items-center gap-3.5 text-left cursor-pointer active:scale-98 shadow-md ${btnStyle}`}
                >
                  <span className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-700/50 flex items-center justify-center text-xl shrink-0 shadow-xs">
                    {opt.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-extrabold text-xs sm:text-sm text-white leading-tight">
                      {opt.label}
                    </p>
                    {opt.sublabel && (
                      <p className="text-[11px] text-emerald-300/80 mt-0.5 leading-snug truncate">
                        {opt.sublabel}
                      </p>
                    )}
                  </div>
                  {isSelected && feedbackState === 'correct' && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0 animate-bounce" />
                  )}
                  {isSelected && feedbackState === 'wrong' && (
                    <XCircle className="w-5 h-5 text-rose-200 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Feedback Singkat Jawaban */}
          {feedbackState === 'correct' && (
            <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/50 text-center text-xs font-black text-emerald-300 animate-in fade-in duration-150">
              ✓ Jawaban Tepat! Tiko melangkah ke titik berikutnya...
            </div>
          )}
          {feedbackState === 'wrong' && (
            <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-400/50 text-center text-xs font-bold text-rose-300 animate-in fade-in duration-150">
              ✕ Kurang tepat! Coba perhatikan lagi arah dan jenis hubungan variabel.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
