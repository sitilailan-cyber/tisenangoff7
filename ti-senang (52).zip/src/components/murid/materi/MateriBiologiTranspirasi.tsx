import React, { useState } from 'react';
import {
  Sprout,
  Droplets,
  Wind,
  Sun,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  ChevronRight,
  Gauge,
} from 'lucide-react';

export const MateriBiologiTranspirasi: React.FC = () => {
  const [hasStartedReading, setHasStartedReading] = useState(false);
  const [activeSection, setActiveSection] = useState<'A' | 'B' | 'C' | 'D'>('A');

  // Interaktif Section D: Simulasi Faktor Terhadap Laju Transpirasi
  const [suhuUdara, setSuhuUdara] = useState<number>(30); // °C
  const [kelembaban, setKelembaban] = useState<number>(50); // %
  const [intensitasCahaya, setIntensitasCahaya] = useState<'rendah' | 'sedang' | 'tinggi'>('sedang');

  // Perhitungan simulasi laju transpirasi relatif
  const cahayaFactor = intensitasCahaya === 'tinggi' ? 1.5 : intensitasCahaya === 'sedang' ? 1.0 : 0.6;
  const relativeRate = Math.max(10, Math.min(100, Math.round(((suhuUdara * 1.8) + (100 - kelembaban) * 0.8) * cahayaFactor * 0.5)));

  const sections: { id: 'A' | 'B' | 'C' | 'D'; label: string; title: string }[] = [
    { id: 'A', label: 'Bagian A', title: 'Transpirasi & Stomata' },
    { id: 'B', label: 'Bagian B', title: 'Xilem & Floem' },
    { id: 'C', label: 'Bagian C', title: 'Faktor Transpirasi' },
    { id: 'D', label: 'Bagian D', title: 'Simulasi Potometer' },
  ];

  const handleNextSection = () => {
    if (activeSection === 'A') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('D');
  };

  const handlePrevSection = () => {
    if (activeSection === 'D') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('A');
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-green-950 via-emerald-950 to-slate-950 p-6 sm:p-10 text-white shadow-xl border border-emerald-500/30">
          <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-green-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold uppercase tracking-wider">
              <Sprout className="w-3.5 h-3.5" />
              <span>Modul Biologi Interaktif Fase F</span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              FISIOLOGI TUMBUHAN & TRANSPIRASI
            </h1>

            <p className="text-sm sm:text-base text-emerald-100 font-medium leading-relaxed">
              Memahami Mekanisme Regulasi Stomata, Daya Hisap Daun, dan Sirkulasi Cairan Vaskular Tumbuhan
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🌿 Stomata & Sel Penjaga
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                💧 Daya Kapilaritas Xilem
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                ☀️ Pengaruh Iklim Mikro
              </span>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => setHasStartedReading(true)}
                className="px-6 py-3 rounded-xl sm:rounded-2xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-sm sm:text-base transition-all shadow-lg shadow-emerald-400/25 active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <span>🚀 MULAI BELAJAR BIOLOGI</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4 sm:space-y-6 animate-in fade-in">
          {/* Header Navigasi Bagian Materi */}
          <div className="bg-slate-900/90 rounded-2xl p-3 sm:p-4 border border-slate-700/80 shadow-md flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {sections.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => setActiveSection(sec.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-emerald-400 text-slate-950 shadow-md font-extrabold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {sec.title}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setHasStartedReading(false)}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Cover</span>
            </button>
          </div>

          {/* BAGIAN A: TRANSPIRASI & STOMATA */}
          {activeSection === 'A' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian A</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Mekanisme Transpirasi & Regulasi Stomata</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Droplets className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-emerald-300 flex items-center gap-2 text-sm">
                    <span>💧 Definisi Transpirasi</span>
                  </h3>
                  <p>
                    <strong>Transpirasi</strong> adalah proses hilangnya air dalam bentuk uap air dari jaringan internal
                    tumbuhan hidup ke atmosfer luar melalui permukaan organ vegetatif, terutama pori-pori stomata daun.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-teal-300 flex items-center gap-2 text-sm">
                    <span>🌿 Peran Sel Penjaga (Guard Cells)</span>
                  </h3>
                  <p>
                    Stomata dibatasi oleh dua <strong>sel penjaga</strong>. Saat sel penjaga menyerap ion K⁺ dan air,
                    tekanan turgornya naik sehingga stomata membuka. Sebaliknya, saat kekurangan air, stomata menutup untuk mencegah dehidrasi.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950 to-teal-950 border border-emerald-500/30 text-xs sm:text-sm text-slate-300 space-y-2">
                <h4 className="font-bold text-white">Fungsi Fisiologis Utama Transpirasi:</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li>Menciptakan tarikan transpirasi (daya hisap daun) untuk mengalirkan air dan hara dari akar ke daun.</li>
                  <li>Mendinginkan suhu permukaan daun (efek pendinginan evaporatif) saat terik sinar matahari.</li>
                  <li>Mempertahankan turgiditas sel dan menjaga kestabilan osmotik tumbuhan.</li>
                </ul>
              </div>
            </div>
          )}

          {/* BAGIAN B: XILEM & FLOEM */}
          {activeSection === 'B' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian B</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Sistem Transportasi Vaskular: Xilem & Floem</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Sprout className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-300">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-cyan-300 text-sm">1. Jaringan Xilem (Pembuluh Kayu)</h3>
                  <p className="text-xs leading-relaxed">
                    Berfungsi mengangkut <strong>air dan zat hara mineral terlarut</strong> dari tanah melalui akar menuju
                    ke batang hingga ke seluruh daun.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Arah aliran: <strong>Satu arah (ke atas)</strong>, digerakkan oleh kohesi-adhesi molekul air dan daya hisap transpirasi.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-amber-300 text-sm">2. Jaringan Floem (Pembuluh Tapis)</h3>
                  <p className="text-xs leading-relaxed">
                    Berfungsi mengedarkan <strong>hasil fotosintesis (sukrosa/asimilat)</strong> dari organ daun (source) ke
                    seluruh bagian tumbuhan yang membutuhkan (sink), seperti akar, tunas, dan buah.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Arah aliran: <strong>Dua arah (multidireksional)</strong> berdasarkan mekanisme aliran tekanan massa.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN C: FAKTOR TRANSPIRASI */}
          {activeSection === 'C' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian C</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Faktor yang Mempengaruhi Laju Transpirasi</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Sun className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs sm:text-sm">
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1">
                  <h4 className="font-bold text-emerald-300">☀️ Intensitas Cahaya</h4>
                  <p className="text-slate-300 text-xs">Cahaya merangsang pembukaan stomata untuk fotosintesis sehingga laju transpirasi meningkat.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1">
                  <h4 className="font-bold text-emerald-300">🌡️ Suhu Udara</h4>
                  <p className="text-slate-300 text-xs">Peningkatan suhu mempercepat penguapan air di dalam ruang antar sel daun.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1">
                  <h4 className="font-bold text-emerald-300">💧 Kelembaban Udara</h4>
                  <p className="text-slate-300 text-xs">Udara yang kering (kelembaban rendah) memperlebar gradien difusi uap air, meningkatkan transpirasi.</p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1">
                  <h4 className="font-bold text-emerald-300">💨 Kecepatan Angin</h4>
                  <p className="text-slate-300 text-xs">Hembusan angin menyingkirkan lapisan batas uap air di permukaan daun sehingga penguapan berlangsung lebih cepat.</p>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN D: SIMULASI POTOMETER */}
          {activeSection === 'D' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian D</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Simulasi Interaktif Potometer Transpirasi</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Gauge className="w-5 h-5" />
                </div>
              </div>

              <div className="p-4 sm:p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Suhu Udara: {suhuUdara} °C</label>
                    <input
                      type="range"
                      min={15}
                      max={45}
                      step={1}
                      value={suhuUdara}
                      onChange={(e) => setSuhuUdara(parseInt(e.target.value))}
                      className="w-full accent-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Kelembaban Relatif (RH): {kelembaban} %</label>
                    <input
                      type="range"
                      min={20}
                      max={95}
                      step={5}
                      value={kelembaban}
                      onChange={(e) => setKelembaban(parseInt(e.target.value))}
                      className="w-full accent-emerald-400"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Intensitas Cahaya:</label>
                    <select
                      value={intensitasCahaya}
                      onChange={(e) => setIntensitasCahaya(e.target.value as any)}
                      className="w-full p-1.5 rounded-lg bg-slate-900 text-white border border-slate-600 text-xs"
                    >
                      <option value="rendah">Rendah (Mendung/Malam)</option>
                      <option value="sedang">Sedang (Pagi Hari)</option>
                      <option value="tinggi">Tinggi (Terik Siang)</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-400/40 text-center space-y-2">
                  <span className="text-xs text-slate-300 block">Indeks Estimasi Laju Transpirasi:</span>
                  <div className="text-3xl font-mono font-black text-emerald-300">
                    {relativeRate} <span className="text-sm font-normal text-slate-300">mL / jam / dm²</span>
                  </div>
                  <div className="w-full bg-slate-700 h-2.5 rounded-full overflow-hidden max-w-md mx-auto">
                    <div
                      className="bg-emerald-400 h-full rounded-full transition-all duration-300"
                      style={{ width: `${relativeRate}%` }}
                    ></div>
                  </div>
                  <p className="text-[11px] text-emerald-200/80">
                    {relativeRate > 70
                      ? 'Laju transpirasi sangat tinggi! Tumbuhan memerlukan pasokan air tanah yang cukup.'
                      : relativeRate > 40
                      ? 'Laju transpirasi moderat, keseimbangan hidrologis fisiologis terjaga optimal.'
                      : 'Laju transpirasi rendah karena suhu sejuk atau kelembaban udara yang tinggi.'}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Tombol Navigasi Bawah */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrevSection}
              disabled={activeSection === 'A'}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Bagian Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={handleNextSection}
              disabled={activeSection === 'D'}
              className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <span>Bagian Berikutnya</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
