import React, { useState } from 'react';
import {
  TrendingUp,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Sliders,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Layers,
  Activity,
  Compass,
  Maximize2,
  Move,
  Shuffle,
  Zap,
} from 'lucide-react';

export const MateriMatematikaTransformasiFungsi: React.FC = () => {
  // State: Apakah murid sudah mengklik "📈 MULAI BELAJAR"
  const [hasStartedReading, setHasStartedReading] = useState(false);

  // Navigasi Section: 1 sampai 9
  type SectionId = '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9';
  const [activeSection, setActiveSection] = useState<SectionId>('1');

  // State interaktif Bagian 2 (Linear)
  const [linearH, setLinearH] = useState<number>(0);
  const [linearK, setLinearK] = useState<number>(2);
  const [linearReflectX, setLinearReflectX] = useState<boolean>(false);
  const [linearReflectY, setLinearReflectY] = useState<boolean>(false);

  // State interaktif Bagian 3 (Kuadrat)
  const [quadA, setQuadA] = useState<number>(1);
  const [quadH, setQuadH] = useState<number>(2);
  const [quadK, setQuadK] = useState<number>(1);

  // State interaktif Bagian 4 (Eksponen)
  const [expA, setExpA] = useState<number>(1);
  const [expB, setExpB] = useState<number>(1);
  const [expH, setExpH] = useState<number>(0);
  const [expK, setExpK] = useState<number>(1);

  // State interaktif Bagian 5 (Membandingkan 3 Fungsi)
  const [compareType, setCompareType] = useState<'linear' | 'kuadrat' | 'eksponen'>('kuadrat');
  const [compareTransform, setCompareTransform] = useState<'geser_atas' | 'geser_kanan' | 'refleksi_x' | 'skala'>('geser_atas');

  // State interaktif Bagian 6 (Bentuk Umum y = a f(b(x-h)) + k)
  const [generalType, setGeneralType] = useState<'linear' | 'kuadrat' | 'eksponen'>('kuadrat');
  const [paramA, setParamA] = useState<number>(1);
  const [paramB, setParamB] = useState<number>(1);
  const [paramH, setParamH] = useState<number>(2);
  const [paramK, setParamK] = useState<number>(3);

  // State interaktif Bagian 7 (Tantangan Kuis)
  const [quizAnswers, setQuizAnswers] = useState<{ [key: number]: number | null }>({
    1: null,
    2: null,
    3: null,
  });

  // State interaktif Bagian 8 (Rantai Konsep)
  const [selectedChainStep, setSelectedChainStep] = useState<number>(0);
  const [chainFunctionFocus, setChainFunctionFocus] = useState<'linear' | 'kuadrat' | 'eksponen'>('kuadrat');

  const navItems: { id: SectionId; number: string; title: string; short: string }[] = [
    { id: '1', number: '1', title: 'Konsep Transformasi', short: '1. Konsep' },
    { id: '2', number: '2', title: 'Fungsi Linear', short: '2. Linear' },
    { id: '3', number: '3', title: 'Fungsi Kuadrat', short: '3. Kuadrat' },
    { id: '4', number: '4', title: 'Fungsi Eksponen', short: '4. Eksponen' },
    { id: '5', number: '5', title: 'Membandingkan 3 Fungsi', short: '5. Bandingkan' },
    { id: '6', number: '6', title: 'Bentuk Umum y = a f(b(x-h)) + k', short: '6. Bentuk Umum' },
    { id: '7', number: '7', title: 'Tantangan Interaktif', short: '7. Tantangan' },
    { id: '8', number: '8', title: 'Rantai Konsep', short: '8. Rantai Konsep' },
    { id: '9', number: '9', title: 'Hal Penting yang Harus Dipahami', short: '9. Hal Penting' },
  ];

  const handleNext = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex < navItems.length - 1) {
      setActiveSection(navItems[currentIndex + 1].id);
    }
  };

  const handlePrev = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex > 0) {
      setActiveSection(navItems[currentIndex - 1].id);
    }
  };

  // Helper untuk memetakan koordinat matematika Cartesian (x, y) ke SVG (cx, cy)
  // Domain x: [-6, 6], Range y: [-6, 6]
  // SVG Width: 320, Height: 240
  const toSvgX = (x: number) => 160 + x * 22;
  const toSvgY = (y: number) => 120 - y * 18;

  // Render path fungsi untuk SVG
  const generateLinearPath = (m: number, c: number) => {
    const x1 = -6;
    const y1 = m * x1 + c;
    const x2 = 6;
    const y2 = m * x2 + c;
    return `M ${toSvgX(x1)} ${toSvgY(y1)} L ${toSvgX(x2)} ${toSvgY(y2)}`;
  };

  const generateQuadPath = (a: number, h: number, k: number) => {
    const points: string[] = [];
    for (let x = -6; x <= 6; x += 0.2) {
      const y = a * Math.pow(x - h, 2) + k;
      if (y >= -8 && y <= 8) {
        points.push(`${points.length === 0 ? 'M' : 'L'} ${toSvgX(x)} ${toSvgY(y)}`);
      }
    }
    return points.join(' ');
  };

  const generateExpPath = (a: number, b: number, h: number, k: number) => {
    const points: string[] = [];
    for (let x = -6; x <= 6; x += 0.2) {
      const y = a * Math.pow(2, b * (x - h)) + k;
      if (y >= -8 && y <= 8) {
        points.push(`${points.length === 0 ? 'M' : 'L'} ${toSvgX(x)} ${toSvgY(y)}`);
      }
    }
    return points.join(' ');
  };

  // Penjelasan otomatis transformasi untuk Bagian 6
  const getTransformationDescription = () => {
    const parts: string[] = [];

    // Horizontal shift (h)
    if (paramH > 0) parts.push(`digeser ${paramH} satuan ke kanan`);
    else if (paramH < 0) parts.push(`digeser ${Math.abs(paramH)} satuan ke kiri`);

    // Vertical shift (k)
    if (paramK > 0) parts.push(`digeser ${paramK} satuan ke atas`);
    else if (paramK < 0) parts.push(`digeser ${Math.abs(paramK)} satuan ke bawah`);

    // Vertical stretch / reflection (a)
    if (paramA < 0) {
      parts.push(`direfleksikan terhadap sumbu-X (dibalik ke bawah)`);
      if (Math.abs(paramA) !== 1) parts.push(`ditekan/diregang vertikal dengan faktor ${Math.abs(paramA)}`);
    } else if (paramA !== 1) {
      parts.push(`peregangan vertikal faktor ${paramA}`);
    }

    // Horizontal stretch / reflection (b)
    if (paramB < 0) {
      parts.push(`direfleksikan terhadap sumbu-Y`);
    } else if (paramB !== 1) {
      parts.push(`penyusutan horizontal faktor 1/${paramB}`);
    }

    if (parts.length === 0) return 'Grafik identik dengan fungsi awal f(x) tanpa pergeseran.';
    return `Grafik ${parts.join(', ')}.`;
  };

  // Data Rantai Konsep
  const chainSteps = [
    {
      title: 'Fungsi Awal f(x)',
      subtitle: 'Grafik Acuan (Induk)',
      desc: 'Grafik acuan standar yang menjadi patokan sebelum diberikan manipulasi aljabar, seperti f(x) = x (linear garis lurus), f(x) = x² (parabola puncak di asal (0,0)), atau f(x) = 2ˣ (eksponen melengkung dengan asimtot y = 0).',
    },
    {
      title: 'Transformasi Aljabar',
      subtitle: 'Operasi Parameter a, b, h, k',
      desc: 'Pemberian operasi tambah, kali, atau tanda negatif pada variabel input (x - h) dan output (a·f + k). Operasi di luar kurung memengaruhi sumbu vertikal Y, sedangkan operasi di dalam kurung memengaruhi sumbu horizontal X secara terbalik.',
    },
    {
      title: 'Perubahan Grafik',
      subtitle: 'Translasi, Refleksi, Dilatasi',
      desc: 'Perubahan posisi titik-titik koordinat pada bidang Kartesius: pergeseran titik puncak parabola ke (h,k), pergeseran asimtot eksponen ke garis y = k, pembalikan arah kurva karena tanda negatif, dan penyempitan kurva.',
    },
    {
      title: 'Interpretasi Matematis',
      subtitle: 'Aplikasi & Analisis Nilai',
      desc: 'Membaca makna fisis grafik baru: titik potong sumbu baru, nilai minimum atau maksimum baru, daerah asal (domain) dan daerah hasil (range), serta laju pertumbuhan fungsi dalam fenomena nyata.',
    },
  ];

  return (
    <div className="space-y-4 sm:space-y-6 w-full min-w-0 font-sans">
      {/* 1. HALAMAN COVER KHUSUS */}
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-amber-500 via-yellow-400 to-amber-600 p-6 sm:p-12 text-slate-950 shadow-2xl border-4 border-yellow-300 animate-in fade-in zoom-in-95">
          {/* Elemen Visual Abstrak Koordinat & Grid Modern */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/20 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-600/30 rounded-full blur-2xl pointer-events-none"></div>

          <div className="relative z-10 max-w-3xl space-y-6">
            {/* Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-950 text-yellow-300 font-extrabold text-xs uppercase tracking-wider shadow-lg">
              <TrendingUp className="w-4 h-4 text-yellow-400" />
              <span>Matematika SMA • Aljabar &amp; Analisis Fungsi</span>
            </div>

            {/* Judul Besar & Subjudul */}
            <div className="space-y-2">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-950 leading-tight uppercase drop-shadow-xs">
                TRANSFORMASI FUNGSI
              </h1>
              <p className="text-base sm:text-xl lg:text-2xl font-black text-slate-900 bg-white/60 inline-block px-3 py-1 rounded-xl shadow-xs">
                Fungsi Linear, Kuadrat, dan Eksponen
              </p>
            </div>

            {/* Visualisasi Mini 3 Grafik pada Bidang Koordinat */}
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white shadow-2xl border-2 border-yellow-400/80 space-y-3">
              <div className="flex items-center justify-between text-xs text-yellow-300 font-bold border-b border-slate-800 pb-2">
                <span>Visual Tiga Kurva Induk &amp; Transformasinya:</span>
                <span className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-sky-400">
                    <span className="w-2.5 h-0.5 bg-sky-400 inline-block"></span> Linear
                  </span>
                  <span className="flex items-center gap-1 text-yellow-400">
                    <span className="w-2.5 h-0.5 bg-yellow-400 inline-block"></span> Kuadrat
                  </span>
                  <span className="flex items-center gap-1 text-rose-400">
                    <span className="w-2.5 h-0.5 bg-rose-400 inline-block"></span> Eksponen
                  </span>
                </span>
              </div>

              <div className="w-full flex items-center justify-center py-2">
                <svg viewBox="0 0 320 150" className="w-full max-w-sm h-36">
                  {/* Grid Lines */}
                  {[-4, -2, 0, 2, 4].map((v) => (
                    <g key={v}>
                      <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={130} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                      <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                    </g>
                  ))}
                  {/* Sumbu X dan Y */}
                  <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                  <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="135" stroke="#94a3b8" strokeWidth="2" />
                  <text x="290" y={toSvgY(0) - 5} fill="#cbd5e1" fontSize="10" fontWeight="bold">X</text>
                  <text x={toSvgX(0) + 5} y="15" fill="#cbd5e1" fontSize="10" fontWeight="bold">Y</text>

                  {/* 1. Linear y = x + 1 */}
                  <line x1={toSvgX(-4)} y1={toSvgY(-3)} x2={toSvgX(4)} y2={toSvgY(5)} stroke="#38bdf8" strokeWidth="2.5" />

                  {/* 2. Kuadrat y = 0.5(x-1)^2 - 1 */}
                  <path d={generateQuadPath(0.4, 0, -2)} fill="none" stroke="#facc15" strokeWidth="3" />

                  {/* 3. Eksponen y = 2^x - 1 */}
                  <path d={generateExpPath(0.8, 1, 0, -1)} fill="none" stroke="#f43f5e" strokeWidth="2.5" />
                </svg>
              </div>

              <p className="text-[11px] text-slate-400 text-center">
                Mengeksplorasi translasi horizontal/vertikal, refleksi sumbu, dan dilatasi skala kurva secara interaktif.
              </p>
            </div>

            {/* Tombol Utama: MULAI BELAJAR */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                type="button"
                id="btn-mulai-belajar-transformasi-fungsi"
                onClick={() => setHasStartedReading(true)}
                className="px-8 py-4 rounded-2xl bg-slate-950 hover:bg-slate-900 text-yellow-300 font-black text-base sm:text-lg shadow-xl shadow-amber-950/40 flex items-center justify-center gap-3 cursor-pointer transition-all transform hover:-translate-y-0.5 active:translate-y-0 border-2 border-yellow-400"
              >
                <span>📈 MULAI BELAJAR</span>
                <ArrowRight className="w-5 h-5 text-yellow-400 animate-pulse" />
              </button>

              <span className="text-xs text-slate-950 font-bold italic text-center sm:text-left">
                Klik tombol di atas untuk membuka materi interaktif dan simulator grafik fungsi.
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* 2. HALAMAN MATERI LENGKAP */
        <div className="space-y-4 sm:space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-300">
          {/* Header Bar Kontrol & Reset ke Cover */}
          <div className="bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 p-4 sm:p-5 rounded-2xl border-2 border-yellow-300 text-slate-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-950 text-yellow-400 flex items-center justify-center font-black shadow-md shrink-0">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-950 text-yellow-300">
                    Matematika SMA
                  </span>
                  <span className="text-xs font-bold text-slate-900">Tema Kuning-Putih</span>
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-950">
                  Transformasi Fungsi: Linear, Kuadrat, &amp; Eksponen
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={() => setHasStartedReading(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-900 text-yellow-300 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Lihat Cover</span>
              </button>
            </div>
          </div>

          {/* Navigasi Section: 1 sampai 9 */}
          <div className="bg-white rounded-2xl p-2 sm:p-3 border-2 border-yellow-400 shadow-md">
            <div className="text-[11px] font-black text-slate-700 px-2 py-1 mb-1.5 flex items-center justify-between">
              <span>Navigasi Materi (Pilih Bagian):</span>
              <span className="text-amber-800 font-extrabold">
                Bagian {activeSection} dari 9
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-1.5">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveSection(item.id)}
                    className={`px-2 py-2 rounded-xl text-xs font-black transition-all text-center flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      isActive
                        ? 'bg-amber-400 text-slate-950 shadow-md border-2 border-amber-600 scale-[1.02]'
                        : 'bg-slate-100 hover:bg-yellow-100 text-slate-800 border border-slate-200'
                    }`}
                  >
                    <span className="text-[10px] opacity-75">{item.number}</span>
                    <span className="truncate w-full text-center text-[11px]">
                      {item.short}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 1: KONSEP TRANSFORMASI FUNGSI */}
          {/* ======================================================== */}
          {activeSection === '1' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 1</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Konsep Transformasi Fungsi
                  </h2>
                </div>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-800 leading-relaxed">
                <p>
                  <strong className="text-slate-950">Transformasi fungsi</strong> adalah aturan pemetaan yang mengubah grafik fungsi asal (fungsi induk) menjadi grafik baru melalui perubahan <span className="font-bold text-amber-700 underline">posisi</span>, <span className="font-bold text-amber-700 underline">bentuk</span>, atau <span className="font-bold text-amber-700 underline">ukuran</span>.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                  <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300">
                    <h3 className="font-black text-slate-950 text-xs mb-1">1. Translasi (Pergeseran)</h3>
                    <p className="text-[11px] text-slate-700">Menggeser grafik ke atas, bawah, kiri, atau kanan tanpa mengubah bentuk maupun ukuran aslinya.</p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300">
                    <h3 className="font-black text-slate-950 text-xs mb-1">2. Refleksi (Pencerminan)</h3>
                    <p className="text-[11px] text-slate-700">Membalik grafik terhadap sumbu-X atau sumbu-Y seperti melihat bayangan di cermin.</p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300">
                    <h3 className="font-black text-slate-950 text-xs mb-1">3. Dilatasi (Peregangan)</h3>
                    <p className="text-[11px] text-slate-700">Memperlebar, mempersempit, memadatkan, atau meregangkan kurva secara proporsional.</p>
                  </div>
                </div>
              </div>

              {/* Perbandingan Visual Grafik Awal vs Grafik Hasil Transformasi */}
              <div className="p-4 rounded-2xl bg-slate-950 text-white space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-yellow-300">
                  <span>Visualisasi: Grafik Awal f(x) vs Grafik Hasil g(x) = f(x - 2) + 1</span>
                  <span className="flex items-center gap-3">
                    <span className="text-slate-400">--- f(x) Awal</span>
                    <span className="text-yellow-400 font-extrabold">― g(x) Transformasi</span>
                  </span>
                </div>

                <div className="w-full flex items-center justify-center py-2">
                  <svg viewBox="0 0 320 180" className="w-full max-w-md h-40">
                    {/* Grid */}
                    {[-4, -2, 0, 2, 4].map((v) => (
                      <g key={v}>
                        <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={160} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                      </g>
                    ))}
                    <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                    <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="165" stroke="#94a3b8" strokeWidth="2" />
                    <text x="290" y={toSvgY(0) - 5} fill="#cbd5e1" fontSize="10">X</text>
                    <text x={toSvgX(0) + 5} y="15" fill="#cbd5e1" fontSize="10">Y</text>

                    {/* Grafik Awal f(x) = x^2 (titik puncak 0,0) */}
                    <path d={generateQuadPath(0.5, 0, 0)} fill="none" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />
                    <circle cx={toSvgX(0)} cy={toSvgY(0)} r="4" fill="#64748b" />
                    <text x={toSvgX(0) - 18} y={toSvgY(0) + 14} fill="#94a3b8" fontSize="9">(0,0)</text>

                    {/* Grafik Hasil g(x) = (x-2)^2 + 1 (titik puncak 2, 1) */}
                    <path d={generateQuadPath(0.5, 2, 1)} fill="none" stroke="#facc15" strokeWidth="3.5" />
                    <circle cx={toSvgX(2)} cy={toSvgY(1)} r="5" fill="#facc15" />
                    <text x={toSvgX(2) + 8} y={toSvgY(1) - 6} fill="#facc15" fontSize="10" fontWeight="bold">(2, 1)</text>

                    {/* Vektor Panah Pergeseran */}
                    <line x1={toSvgX(0)} y1={toSvgY(0)} x2={toSvgX(2)} y2={toSvgY(0)} stroke="#38bdf8" strokeWidth="2" strokeDasharray="2 2" />
                    <line x1={toSvgX(2)} y1={toSvgY(0)} x2={toSvgX(2)} y2={toSvgY(1)} stroke="#38bdf8" strokeWidth="2" strokeDasharray="2 2" />
                  </svg>
                </div>
                <p className="text-center text-xs text-yellow-300 font-bold">
                  Titik puncak parabola bergeser 2 satuan ke kanan dan 1 satuan ke atas: (0,0) → (2, 1)
                </p>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 2: TRANSFORMASI FUNGSI LINEAR */}
          {/* ======================================================== */}
          {activeSection === '2' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 2</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Transformasi Fungsi Linear: f(x) = x
                  </h2>
                </div>
              </div>

              <div className="space-y-2 text-xs sm:text-sm text-slate-800">
                <p>
                  Fungsi linear induk adalah <strong className="text-slate-950">f(x) = x</strong> (garis lurus miring 45° melalui pusat (0,0)). Aturan transformasi meliputi:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-xs">
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <span className="font-black text-slate-950 block">f(x) + k</span>
                    <span className="text-[11px] text-slate-700">Geser Vertikal</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <span className="font-black text-slate-950 block">f(x - h)</span>
                    <span className="text-[11px] text-slate-700">Geser Horizontal</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <span className="font-black text-slate-950 block">-f(x)</span>
                    <span className="text-[11px] text-slate-700">Refleksi Sumbu-X</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <span className="font-black text-slate-950 block">f(-x)</span>
                    <span className="text-[11px] text-slate-700">Refleksi Sumbu-Y</span>
                  </div>
                </div>
              </div>

              {/* Kontrol & Visual Interaktif Linear */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                  {/* Slider & Toggle */}
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Geser Vertikal (k): {linearK}</span>
                        <span>{linearK > 0 ? 'Ke Atas' : linearK < 0 ? 'Ke Bawah' : 'Pusat'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={linearK}
                        onChange={(e) => setLinearK(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Geser Horizontal (h): {linearH}</span>
                        <span>{linearH > 0 ? 'Ke Kanan' : linearH < 0 ? 'Ke Kiri' : 'Pusat'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={linearH}
                        onChange={(e) => setLinearH(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setLinearReflectX(!linearReflectX)}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                          linearReflectX
                            ? 'bg-yellow-400 text-slate-950 border-yellow-300'
                            : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}
                      >
                        -f(x) (Refleksi Sumbu-X)
                      </button>
                      <button
                        type="button"
                        onClick={() => setLinearReflectY(!linearReflectY)}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                          linearReflectY
                            ? 'bg-yellow-400 text-slate-950 border-yellow-300'
                            : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}
                      >
                        f(-x) (Refleksi Sumbu-Y)
                      </button>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-yellow-300">
                      Persamaan: y = {linearReflectX ? '-(' : ''}
                      {linearReflectY ? '(-x' : '(x'} {linearH !== 0 ? (linearH > 0 ? `- ${linearH}` : `+ ${Math.abs(linearH)}`) : ''})
                      {linearReflectX ? ')' : ''} {linearK !== 0 ? (linearK > 0 ? `+ ${linearK}` : `- ${Math.abs(linearK)}`) : ''}
                    </div>
                  </div>

                  {/* Visual SVG Grafik Linear */}
                  <div className="flex flex-col items-center justify-center">
                    <svg viewBox="0 0 320 200" className="w-full max-w-xs h-44">
                      {[-4, -2, 0, 2, 4].map((v) => (
                        <g key={v}>
                          <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={180} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                          <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        </g>
                      ))}
                      <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                      <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="185" stroke="#94a3b8" strokeWidth="2" />

                      {/* Garis Awal f(x) = x */}
                      <line x1={toSvgX(-5)} y1={toSvgY(-5)} x2={toSvgX(5)} y2={toSvgY(5)} stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />

                      {/* Garis Hasil Transformasi */}
                      {(() => {
                        let sign = 1;
                        if (linearReflectX) sign *= -1;
                        if (linearReflectY) sign *= -1;
                        const c = (linearReflectX ? -1 : 1) * (-sign * linearH) + linearK;
                        return (
                          <path
                            d={generateLinearPath(sign, c)}
                            stroke="#facc15"
                            strokeWidth="3.5"
                          />
                        );
                      })()}
                    </svg>
                    <span className="text-[11px] text-slate-400 mt-1">Garis Putus = Induk f(x) | Garis Kuning = Hasil Transformasi</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 3: TRANSFORMASI FUNGSI KUADRAT */}
          {/* ======================================================== */}
          {activeSection === '3' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Move className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 3</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Transformasi Fungsi Kuadrat: f(x) = x²
                  </h2>
                </div>
              </div>

              <div className="space-y-2 text-xs sm:text-sm text-slate-800">
                <p>
                  Bentuk umum pergeseran parabola kuadrat adalah <strong className="text-slate-950">y = a(x - h)² + k</strong> dengan titik puncak <strong className="text-amber-800">(h, k)</strong>.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <strong className="text-slate-950 block">Titik Puncak (h, k)</strong>
                    <span className="text-[11px] text-slate-700">h menentukan geser horizontal, k menentukan geser vertikal.</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <strong className="text-slate-950 block">Arah Terbuka Parabola</strong>
                    <span className="text-[11px] text-slate-700">Jika a &gt; 0 terbuka ke atas. Jika a &lt; 0 terbuka ke bawah (refleksi sumbu-X).</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-300">
                    <strong className="text-slate-950 block">Bentuk / Kelengkungan</strong>
                    <span className="text-[11px] text-slate-700">|a| &gt; 1 kurva semakin ramping/sempit. |a| &lt; 1 kurva semakin lebar.</span>
                  </div>
                </div>
              </div>

              {/* Simulator Parabola Interaktif */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Faktor Skala / Arah Buka (a): {quadA}</span>
                        <span>{quadA < 0 ? 'Buka ke Bawah' : 'Buka ke Atas'}</span>
                      </div>
                      <input
                        type="range"
                        min="-2"
                        max="2"
                        step="0.5"
                        value={quadA}
                        onChange={(e) => setQuadA(Number(e.target.value) === 0 ? 0.5 : Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Titik Puncak X (h): {quadH}</span>
                        <span>{quadH > 0 ? 'Kanan' : quadH < 0 ? 'Kiri' : '0'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={quadH}
                        onChange={(e) => setQuadH(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Titik Puncak Y (k): {quadK}</span>
                        <span>{quadK > 0 ? 'Atas' : quadK < 0 ? 'Bawah' : '0'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={quadK}
                        onChange={(e) => setQuadK(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-yellow-300">
                      y = {quadA !== 1 ? (quadA === -1 ? '-' : `${quadA}`) : ''}(x {quadH >= 0 ? `- ${quadH}` : `+ ${Math.abs(quadH)}`})² {quadK >= 0 ? `+ ${quadK}` : `- ${Math.abs(quadK)}`}
                      <br />
                      Titik Puncak Parabola: ({quadH}, {quadK})
                    </div>
                  </div>

                  {/* Visual SVG Parabola */}
                  <div className="flex flex-col items-center justify-center">
                    <svg viewBox="0 0 320 200" className="w-full max-w-xs h-44">
                      {[-4, -2, 0, 2, 4].map((v) => (
                        <g key={v}>
                          <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={180} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                          <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        </g>
                      ))}
                      <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                      <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="185" stroke="#94a3b8" strokeWidth="2" />

                      {/* Parabola Induk f(x) = x^2 */}
                      <path d={generateQuadPath(0.8, 0, 0)} fill="none" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />

                      {/* Parabola Hasil Transformasi */}
                      <path d={generateQuadPath(quadA, quadH, quadK)} fill="none" stroke="#facc15" strokeWidth="3.5" />
                      <circle cx={toSvgX(quadH)} cy={toSvgY(quadK)} r="5" fill="#facc15" />
                      <text x={toSvgX(quadH) + 8} y={toSvgY(quadK) - 6} fill="#facc15" fontSize="10" fontWeight="bold">
                        ({quadH}, {quadK})
                      </text>
                    </svg>
                    <span className="text-[11px] text-slate-400 mt-1">Kuning = Hasil Transformasi y = a(x - h)² + k</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 4: TRANSFORMASI FUNGSI EKSPONEN */}
          {/* ======================================================== */}
          {activeSection === '4' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 4</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Transformasi Fungsi Eksponen: f(x) = 2ˣ
                  </h2>
                </div>
              </div>

              <div className="space-y-2 text-xs sm:text-sm text-slate-800">
                <p>
                  Fungsi eksponen induk <strong className="text-slate-950">f(x) = 2ˣ</strong> memiliki ciri khas: selalu positif, melewati titik (0, 1), dan memiliki <span className="font-bold text-amber-800 underline">asimtot horizontal</span> di sumbu-X (garis y = 0).
                </p>
                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 text-xs space-y-1">
                  <p><strong className="text-slate-950">Pergeseran Asimtot Horizontal:</strong> Ketika fungsi ditambah konstanta k vertikal menjadi <em>y = 2ˣ + k</em>, garis asimtot horizontal langsung berpindah ke garis <strong className="text-amber-900 font-mono">y = k</strong>!</p>
                </div>
              </div>

              {/* Simulator Eksponen Interaktif */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Asimtot Vertikal / Nilai k: {expK}</span>
                        <span>Asimtot: y = {expK}</span>
                      </div>
                      <input
                        type="range"
                        min="-3"
                        max="3"
                        step="1"
                        value={expK}
                        onChange={(e) => setExpK(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Pergeseran Horizontal (h): {expH}</span>
                        <span>{expH > 0 ? 'Kanan' : expH < 0 ? 'Kiri' : '0'}</span>
                      </div>
                      <input
                        type="range"
                        min="-3"
                        max="3"
                        step="1"
                        value={expH}
                        onChange={(e) => setExpH(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setExpA(expA === 1 ? -1 : 1)}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                          expA === -1 ? 'bg-yellow-400 text-slate-950 border-yellow-300' : 'bg-slate-800 text-slate-300 border-slate-700'
                        }`}
                      >
                        {expA === -1 ? 'Refleksi Sumbu-X: Aktif' : 'Refleksi Sumbu-X: Nonaktif'}
                      </button>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-yellow-300">
                      y = {expA === -1 ? '-' : ''}2^(x {expH >= 0 ? `- ${expH}` : `+ ${Math.abs(expH)}`}) {expK >= 0 ? `+ ${expK}` : `- ${Math.abs(expK)}`}
                      <br />
                      Garis Asimtot Horizontal: y = {expK}
                    </div>
                  </div>

                  {/* Visual SVG Eksponen */}
                  <div className="flex flex-col items-center justify-center">
                    <svg viewBox="0 0 320 200" className="w-full max-w-xs h-44">
                      {[-4, -2, 0, 2, 4].map((v) => (
                        <g key={v}>
                          <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={180} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                          <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        </g>
                      ))}
                      <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                      <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="185" stroke="#94a3b8" strokeWidth="2" />

                      {/* Garis Asimtot Horizontal Berwarna Cyan */}
                      <line x1="35" y1={toSvgY(expK)} x2="285" y2={toSvgY(expK)} stroke="#38bdf8" strokeWidth="1.5" strokeDasharray="3 3" />
                      <text x="40" y={toSvgY(expK) - 4} fill="#38bdf8" fontSize="9" fontWeight="bold">Asimtot y = {expK}</text>

                      {/* Eksponen Induk f(x) = 2^x */}
                      <path d={generateExpPath(1, 1, 0, 0)} fill="none" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />

                      {/* Eksponen Hasil Transformasi */}
                      <path d={generateExpPath(expA, expB, expH, expK)} fill="none" stroke="#facc15" strokeWidth="3.5" />
                    </svg>
                    <span className="text-[11px] text-slate-400 mt-1">Garis Putus Biru = Asimtot Horizontal y = {expK}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 5: MEMBANDINGKAN KETIGA FUNGSI */}
          {/* ======================================================== */}
          {activeSection === '5' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Shuffle className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 5</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Membandingkan Ketiga Fungsi: Linear, Kuadrat, &amp; Eksponen
                  </h2>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-800">
                Pilih jenis fungsi dan tipe transformasi untuk melihat bagaimana aturan transformasi berlaku secara universal pada ketiga keluarga kurva:
              </p>

              {/* Selector Jenis Fungsi */}
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setCompareType('linear')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    compareType === 'linear'
                      ? 'bg-amber-400 text-slate-950 border-2 border-amber-600 shadow-sm'
                      : 'bg-slate-100 text-slate-700 border hover:bg-yellow-50'
                  }`}
                >
                  1. Fungsi Linear f(x) = x
                </button>
                <button
                  type="button"
                  onClick={() => setCompareType('kuadrat')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    compareType === 'kuadrat'
                      ? 'bg-amber-400 text-slate-950 border-2 border-amber-600 shadow-sm'
                      : 'bg-slate-100 text-slate-700 border hover:bg-yellow-50'
                  }`}
                >
                  2. Fungsi Kuadrat f(x) = x²
                </button>
                <button
                  type="button"
                  onClick={() => setCompareType('eksponen')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    compareType === 'eksponen'
                      ? 'bg-amber-400 text-slate-950 border-2 border-amber-600 shadow-sm'
                      : 'bg-slate-100 text-slate-700 border hover:bg-yellow-50'
                  }`}
                >
                  3. Fungsi Eksponen f(x) = 2ˣ
                </button>
              </div>

              {/* Selector Transformasi & Tombol Reset */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCompareTransform('geser_atas')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      compareTransform === 'geser_atas'
                        ? 'bg-slate-950 text-yellow-300 border-slate-950'
                        : 'bg-yellow-50 text-slate-800 border-yellow-300'
                    }`}
                  >
                    Geser Atas (+2)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompareTransform('geser_kanan')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      compareTransform === 'geser_kanan'
                        ? 'bg-slate-950 text-yellow-300 border-slate-950'
                        : 'bg-yellow-50 text-slate-800 border-yellow-300'
                    }`}
                  >
                    Geser Kanan (+2)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompareTransform('refleksi_x')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      compareTransform === 'refleksi_x'
                        ? 'bg-slate-950 text-yellow-300 border-slate-950'
                        : 'bg-yellow-50 text-slate-800 border-yellow-300'
                    }`}
                  >
                    Refleksi Sumbu-X
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompareTransform('skala')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      compareTransform === 'skala'
                        ? 'bg-slate-950 text-yellow-300 border-slate-950'
                        : 'bg-yellow-50 text-slate-800 border-yellow-300'
                    }`}
                  >
                    Skala Dilatasi (2×)
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setCompareTransform('geser_atas')}
                  className="px-3 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Transformasi</span>
                </button>
              </div>

              {/* Area Grafik Komparasi */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-3">
                <div className="flex items-center justify-between text-xs text-yellow-300 font-bold">
                  <span>
                    {compareType === 'linear' && 'Linear: f(x) = x'}
                    {compareType === 'kuadrat' && 'Kuadrat: f(x) = x²'}
                    {compareType === 'eksponen' && 'Eksponen: f(x) = 2ˣ'}
                  </span>
                  <span className="flex items-center gap-3">
                    <span className="text-slate-400">--- Kurva Awal</span>
                    <span className="text-yellow-400 font-black">― Kurva Transformasi</span>
                  </span>
                </div>

                <div className="w-full flex items-center justify-center py-2">
                  <svg viewBox="0 0 320 200" className="w-full max-w-sm h-48">
                    {[-4, -2, 0, 2, 4].map((v) => (
                      <g key={v}>
                        <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={180} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                      </g>
                    ))}
                    <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                    <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="185" stroke="#94a3b8" strokeWidth="2" />

                    {/* Kurva Awal (Putus-putus) */}
                    {compareType === 'linear' && <line x1={toSvgX(-5)} y1={toSvgY(-5)} x2={toSvgX(5)} y2={toSvgY(5)} stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />}
                    {compareType === 'kuadrat' && <path d={generateQuadPath(0.8, 0, 0)} fill="none" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />}
                    {compareType === 'eksponen' && <path d={generateExpPath(1, 1, 0, 0)} fill="none" stroke="#64748b" strokeWidth="2" strokeDasharray="3 3" />}

                    {/* Kurva Transformasi (Kuning) */}
                    {compareType === 'linear' && (
                      <path
                        d={
                          compareTransform === 'geser_atas'
                            ? generateLinearPath(1, 2)
                            : compareTransform === 'geser_kanan'
                            ? generateLinearPath(1, -2)
                            : compareTransform === 'refleksi_x'
                            ? generateLinearPath(-1, 0)
                            : generateLinearPath(2, 0)
                        }
                        stroke="#facc15"
                        strokeWidth="3.5"
                      />
                    )}

                    {compareType === 'kuadrat' && (
                      <path
                        d={
                          compareTransform === 'geser_atas'
                            ? generateQuadPath(0.8, 0, 2)
                            : compareTransform === 'geser_kanan'
                            ? generateQuadPath(0.8, 2, 0)
                            : compareTransform === 'refleksi_x'
                            ? generateQuadPath(-0.8, 0, 0)
                            : generateQuadPath(1.8, 0, 0)
                        }
                        fill="none"
                        stroke="#facc15"
                        strokeWidth="3.5"
                      />
                    )}

                    {compareType === 'eksponen' && (
                      <path
                        d={
                          compareTransform === 'geser_atas'
                            ? generateExpPath(1, 1, 0, 2)
                            : compareTransform === 'geser_kanan'
                            ? generateExpPath(1, 1, 2, 0)
                            : compareTransform === 'refleksi_x'
                            ? generateExpPath(-1, 1, 0, 0)
                            : generateExpPath(2, 1, 0, 0)
                        }
                        fill="none"
                        stroke="#facc15"
                        strokeWidth="3.5"
                      />
                    )}
                  </svg>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 6: BENTUK UMUM TRANSFORMASI y = a f(b(x-h)) + k */}
          {/* ======================================================== */}
          {activeSection === '6' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 6</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Bentuk Umum Transformasi: y = a · f(b(x - h)) + k
                  </h2>
                </div>
              </div>

              {/* Formula Master */}
              <div className="p-4 rounded-2xl bg-amber-400 text-slate-950 font-mono text-center font-black text-base sm:text-xl border-2 border-yellow-500 shadow-sm">
                y = a · f(b(x - h)) + k
              </div>

              {/* Keterangan Otomatis Real-Time Transformasi */}
              <div className="p-4 rounded-xl bg-yellow-50 border-2 border-yellow-300">
                <span className="text-xs font-black text-slate-950 block mb-1">Keterangan Transformasi Real-Time:</span>
                <p className="text-xs sm:text-sm font-extrabold text-amber-900 leading-relaxed">
                  📢 “{getTransformationDescription()}”
                </p>
              </div>

              {/* Slider Interaktif Parameter a, b, h, k */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Slider Kiri */}
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Parameter a (Skala Vertikal / Refleksi X): {paramA}</span>
                        <span>{paramA < 0 ? 'Refleksi' : 'Normal'}</span>
                      </div>
                      <input
                        type="range"
                        min="-2"
                        max="2"
                        step="0.5"
                        value={paramA}
                        onChange={(e) => setParamA(Number(e.target.value) === 0 ? 0.5 : Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Parameter b (Skala Horizontal / Refleksi Y): {paramB}</span>
                        <span>{paramB < 0 ? 'Refleksi Y' : 'Normal'}</span>
                      </div>
                      <input
                        type="range"
                        min="-2"
                        max="2"
                        step="0.5"
                        value={paramB}
                        onChange={(e) => setParamB(Number(e.target.value) === 0 ? 1 : Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Parameter h (Geser Horizontal): {paramH}</span>
                        <span>{paramH > 0 ? `${paramH} Kanan` : paramH < 0 ? `${Math.abs(paramH)} Kiri` : '0'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={paramH}
                        onChange={(e) => setParamH(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs text-yellow-300 font-bold mb-1">
                        <span>Parameter k (Geser Vertikal): {paramK}</span>
                        <span>{paramK > 0 ? `${paramK} Atas` : paramK < 0 ? `${Math.abs(paramK)} Bawah` : '0'}</span>
                      </div>
                      <input
                        type="range"
                        min="-4"
                        max="4"
                        step="1"
                        value={paramK}
                        onChange={(e) => setParamK(Number(e.target.value))}
                        className="w-full accent-yellow-400 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Visual SVG Real-Time */}
                  <div className="flex flex-col items-center justify-center">
                    <div className="flex gap-1.5 mb-2">
                      {(['linear', 'kuadrat', 'eksponen'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setGeneralType(t)}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-bold capitalize transition-all ${
                            generalType === t ? 'bg-yellow-400 text-slate-950 font-black' : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>

                    <svg viewBox="0 0 320 200" className="w-full max-w-xs h-44">
                      {[-4, -2, 0, 2, 4].map((v) => (
                        <g key={v}>
                          <line x1={toSvgX(v)} y1={20} x2={toSvgX(v)} y2={180} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                          <line x1={40} y1={toSvgY(v)} x2={280} y2={toSvgY(v)} stroke="#334155" strokeWidth="0.8" strokeDasharray="2 2" />
                        </g>
                      ))}
                      <line x1="30" y1={toSvgY(0)} x2="290" y2={toSvgY(0)} stroke="#94a3b8" strokeWidth="2" />
                      <line x1={toSvgX(0)} y1="15" x2={toSvgX(0)} y2="185" stroke="#94a3b8" strokeWidth="2" />

                      {generalType === 'linear' && (
                        <path d={generateLinearPath(paramA * paramB, -paramA * paramB * paramH + paramK)} stroke="#facc15" strokeWidth="3.5" />
                      )}
                      {generalType === 'kuadrat' && (
                        <path d={generateQuadPath(paramA * Math.pow(paramB, 2), paramH, paramK)} fill="none" stroke="#facc15" strokeWidth="3.5" />
                      )}
                      {generalType === 'eksponen' && (
                        <path d={generateExpPath(paramA, paramB, paramH, paramK)} fill="none" stroke="#facc15" strokeWidth="3.5" />
                      )}
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 7: TANTANGAN INTERAKTIF */}
          {/* ======================================================== */}
          {activeSection === '7' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 7</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Tantangan Interaktif Transformasi Fungsi
                  </h2>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-800">
                Uji pemahaman Anda pada fungsi linear, kuadrat, dan eksponen dengan umpan balik langsung:
              </p>

              {/* Soal 1: Kuadrat */}
              <div className="p-4 rounded-2xl bg-yellow-50 border-2 border-yellow-300 space-y-3">
                <span className="text-[11px] font-black uppercase text-amber-800">Soal 1 • Fungsi Kuadrat</span>
                <p className="text-xs sm:text-sm font-bold text-slate-950">
                  “Grafik f(x) = x² digeser 3 satuan ke kanan dan 2 satuan ke atas. Manakah fungsi hasil transformasinya?”
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { id: 1, text: 'g(x) = (x - 3)² + 2', correct: true },
                    { id: 2, text: 'g(x) = (x + 3)² + 2', correct: false },
                    { id: 3, text: 'g(x) = (x - 3)² - 2', correct: false },
                    { id: 4, text: 'g(x) = (x + 3)² - 2', correct: false },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setQuizAnswers({ ...quizAnswers, 1: opt.id })}
                      className={`p-2.5 rounded-xl text-xs font-mono text-left border transition-all cursor-pointer ${
                        quizAnswers[1] === opt.id
                          ? opt.correct
                            ? 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold'
                            : 'bg-rose-100 border-rose-500 text-rose-950 font-bold'
                          : 'bg-white border-yellow-200 hover:border-yellow-400'
                      }`}
                    >
                      {opt.text}
                    </button>
                  ))}
                </div>

                {quizAnswers[1] !== null && (
                  <div className={`p-2.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                    quizAnswers[1] === 1 ? 'bg-emerald-200 text-emerald-950' : 'bg-rose-200 text-rose-950'
                  }`}>
                    {quizAnswers[1] === 1 ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>Tepat Sekali! Pergeseran ke kanan menggunakan (x - 3) dan ke atas menggunakan + 2.</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4 text-rose-700 shrink-0" />
                        <span>Belum tepat. Ingat: geser ke kanan memakai tanda minus di dalam kurung (x - h) dan ke atas + k.</span>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Soal 2: Linear */}
              <div className="p-4 rounded-2xl bg-yellow-50 border-2 border-yellow-300 space-y-3">
                <span className="text-[11px] font-black uppercase text-amber-800">Soal 2 • Fungsi Linear</span>
                <p className="text-xs sm:text-sm font-bold text-slate-950">
                  “Jika grafik f(x) = x direfleksikan terhadap sumbu-X lalu digeser 4 satuan ke bawah, bagaimana persamaannya?”
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { id: 1, text: 'g(x) = -x - 4', correct: true },
                    { id: 2, text: 'g(x) = -x + 4', correct: false },
                    { id: 3, text: 'g(x) = x - 4', correct: false },
                    { id: 4, text: 'g(x) = -(x - 4)', correct: false },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setQuizAnswers({ ...quizAnswers, 2: opt.id })}
                      className={`p-2.5 rounded-xl text-xs font-mono text-left border transition-all cursor-pointer ${
                        quizAnswers[2] === opt.id
                          ? opt.correct
                            ? 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold'
                            : 'bg-rose-100 border-rose-500 text-rose-950 font-bold'
                          : 'bg-white border-yellow-200 hover:border-yellow-400'
                      }`}
                    >
                      {opt.text}
                    </button>
                  ))}
                </div>

                {quizAnswers[2] !== null && (
                  <div className={`p-2.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                    quizAnswers[2] === 1 ? 'bg-emerald-200 text-emerald-950' : 'bg-rose-200 text-rose-950'
                  }`}>
                    {quizAnswers[2] === 1 ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>Tepat Sekali! Refleksi sumbu-X menghasilkan -f(x) = -x, lalu digeser 4 satuan ke bawah (-4).</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4 text-rose-700 shrink-0" />
                        <span>Belum tepat. Refleksi sumbu-X membuat gradien bernilai negatif (-x) dan geser ke bawah dikurangi 4.</span>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Soal 3: Eksponen */}
              <div className="p-4 rounded-2xl bg-yellow-50 border-2 border-yellow-300 space-y-3">
                <span className="text-[11px] font-black uppercase text-amber-800">Soal 3 • Fungsi Eksponen</span>
                <p className="text-xs sm:text-sm font-bold text-slate-950">
                  “Fungsi g(x) = 2^(x - 1) + 3 memiliki garis asimtot horizontal pada persamaan:”
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { id: 1, text: 'y = 3', correct: true },
                    { id: 2, text: 'y = 1', correct: false },
                    { id: 3, text: 'x = 1', correct: false },
                    { id: 4, text: 'y = 0', correct: false },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setQuizAnswers({ ...quizAnswers, 3: opt.id })}
                      className={`p-2.5 rounded-xl text-xs font-mono text-left border transition-all cursor-pointer ${
                        quizAnswers[3] === opt.id
                          ? opt.correct
                            ? 'bg-emerald-100 border-emerald-500 text-emerald-950 font-bold'
                            : 'bg-rose-100 border-rose-500 text-rose-950 font-bold'
                          : 'bg-white border-yellow-200 hover:border-yellow-400'
                      }`}
                    >
                      {opt.text}
                    </button>
                  ))}
                </div>

                {quizAnswers[3] !== null && (
                  <div className={`p-2.5 rounded-xl text-xs font-bold flex items-center gap-2 ${
                    quizAnswers[3] === 1 ? 'bg-emerald-200 text-emerald-950' : 'bg-rose-200 text-rose-950'
                  }`}>
                    {quizAnswers[3] === 1 ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span>Luar Biasa! Asimtot horizontal fungsi eksponen mengikuti pergeseran vertikal k, yaitu y = 3.</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-4 h-4 text-rose-700 shrink-0" />
                        <span>Belum tepat. Asimtot horizontal ditentukan oleh konstanta vertikal k pada y = 2ˣ + k.</span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 8: RANTAI KONSEP */}
          {/* ======================================================== */}
          {activeSection === '8' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 8</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Rantai Konsep Transformasi
                  </h2>
                </div>
              </div>

              <div className="flex items-center justify-center gap-2">
                {(['linear', 'kuadrat', 'eksponen'] as const).map((fn) => (
                  <button
                    key={fn}
                    type="button"
                    onClick={() => setChainFunctionFocus(fn)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                      chainFunctionFocus === fn
                        ? 'bg-amber-400 text-slate-950 font-black border border-amber-600'
                        : 'bg-slate-100 text-slate-700 hover:bg-yellow-50'
                    }`}
                  >
                    Fokus: {fn}
                  </button>
                ))}
              </div>

              {/* Alur Visual 4 Tahap */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                {chainSteps.map((step, idx) => (
                  <button
                    key={step.title}
                    type="button"
                    onClick={() => setSelectedChainStep(idx)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      selectedChainStep === idx
                        ? 'bg-amber-400 border-amber-600 text-slate-950 font-black shadow-md scale-[1.02]'
                        : 'bg-yellow-50 border-yellow-200 text-slate-800 hover:border-yellow-400'
                    }`}
                  >
                    <span className="text-[10px] uppercase font-bold opacity-75">Tahap {idx + 1}</span>
                    <span className="text-xs font-black">{step.title}</span>
                  </button>
                ))}
              </div>

              {/* Kotak Detail Rantai Konsep */}
              {(() => {
                const current = chainSteps[selectedChainStep];
                return (
                  <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 text-white space-y-2 border-2 border-yellow-400/80">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <h3 className="text-sm sm:text-base font-black text-yellow-300">
                        {current.title} — {current.subtitle}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 font-black capitalize">
                        {chainFunctionFocus}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {current.desc}
                    </p>
                  </div>
                );
              })()}
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 9: HAL PENTING YANG HARUS DIPAHAMI */}
          {/* ======================================================== */}
          {activeSection === '9' && (
            <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-7 border-2 border-yellow-400 shadow-md space-y-4">
              <div className="flex items-center gap-3 border-b border-yellow-200 pb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 font-black">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-700 uppercase tracking-wider">Bagian 9</span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-950">
                    Hal Penting yang Harus Dipahami
                  </h2>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">1</span>
                    f(x) + k → Perubahan Vertikal
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Menambah konstanta di luar fungsi menggeser seluruh grafik ke atas (jika k &gt; 0) atau ke bawah (jika k &lt; 0).
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">2</span>
                    f(x - h) → Pergeseran Horizontal
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Pengurangan variabel di dalam kurung menggeser ke kanan (h &gt; 0), sedangkan penambahan (x + h) menggeser ke kiri.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">3</span>
                    -f(x) → Refleksi terhadap Sumbu-X
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Mengalikan seluruh fungsi dengan minus membalik grafik secara vertikal (atas menjadi bawah).
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">4</span>
                    f(-x) → Refleksi terhadap Sumbu-Y
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Mengalikan variabel x dengan minus membalik grafik secara horizontal (kanan menjadi kiri).
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">5</span>
                    a · f(x) → Dilatasi / Peregangan Vertikal
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Mengalikan faktor a mengubah tinggi nilai output, membuat kurva semakin curam (|a| &gt; 1) atau memipih (|a| &lt; 1).
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-yellow-50 border-2 border-yellow-300 space-y-1">
                  <strong className="text-xs text-slate-950 font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-400 text-slate-950 text-[10px] flex items-center justify-center font-black">6</span>
                    f(b · x) → Perubahan Horizontal
                  </strong>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    Mengalikan x dengan faktor b memampatkan grafik secara horizontal dengan faktor skala 1/b.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-amber-400 border-2 border-yellow-500 sm:col-span-2 space-y-1 text-slate-950">
                  <strong className="text-xs font-black block">
                    ✨ 7. Universalitas Aturan Transformasi
                  </strong>
                  <p className="text-xs leading-relaxed font-bold">
                    Transformasi dapat diterapkan secara seragam pada seluruh jenis fungsi: linear, kuadrat, eksponen, trigonometri, maupun polinomial tingkat tinggi.
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-yellow-200 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('input-catatan-penting-offline');
                    if (el) {
                      el.scrollIntoView({ behavior: 'smooth' });
                      el.focus();
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-950 text-yellow-300 font-black text-xs hover:bg-slate-900 cursor-pointer shadow-md"
                >
                  Tulis Catatan Informasi Penting ↓
                </button>
              </div>
            </div>
          )}

          {/* Navigasi Bawah: Bagian Sebelumnya & Selanjutnya */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrev}
              disabled={activeSection === '1'}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === '1'
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                  : 'bg-white hover:bg-yellow-50 text-slate-900 border-2 border-yellow-400 shadow-sm'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Bagian Sebelumnya</span>
            </button>

            <span className="text-[11px] font-bold text-slate-600">
              Bagian {activeSection} dari 9
            </span>

            <button
              type="button"
              onClick={handleNext}
              disabled={activeSection === '9'}
              className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === '9'
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                  : 'bg-amber-400 hover:bg-amber-500 text-slate-950 border-2 border-amber-600 shadow-md'
              }`}
            >
              <span>Bagian Selanjutnya</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
