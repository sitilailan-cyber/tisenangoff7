import React, { useState } from 'react';
import {
  TrendingUp,
  LineChart as LineChartIcon,
  ScatterChart,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  BookOpen,
  Sparkles,
  Info,
  CheckCircle2,
  Table as TableIcon,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';

interface DataPoint {
  id: number;
  siswa: string;
  x: number; // Jam Belajar per Minggu
  y: number; // Nilai Ujian Matematika
}

const sampleStudentData: DataPoint[] = [
  { id: 1, siswa: 'Ahmad', x: 2, y: 60 },
  { id: 2, siswa: 'Budi', x: 3, y: 65 },
  { id: 3, siswa: 'Citra', x: 4, y: 70 },
  { id: 4, siswa: 'Dewi', x: 5, y: 72 },
  { id: 5, siswa: 'Eko', x: 6, y: 78 },
  { id: 6, siswa: 'Farhan', x: 7, y: 82 },
  { id: 7, siswa: 'Gita', x: 8, y: 85 },
  { id: 8, siswa: 'Hadi', x: 10, y: 90 },
  { id: 9, siswa: 'Indah', x: 11, y: 92 },
  { id: 10, siswa: 'Joko', x: 12, y: 96 },
];

export const MateriRegresiLinear: React.FC = () => {
  // State: apakah sudah klik "🚀 MULAI BELAJAR"
  const [hasStartedReading, setHasStartedReading] = useState(false);

  // Tab section aktif: 'A' | 'B' | 'C' | 'D' | 'E'
  const [activeSection, setActiveSection] = useState<'A' | 'B' | 'C' | 'D' | 'E'>('A');

  // State interaktif Section A: hover data point
  const [hoveredPointA, setHoveredPointA] = useState<DataPoint | null>(null);

  // State interaktif Section B: toggle Line of Best Fit
  const [showBestFitB, setShowBestFitB] = useState(true);

  // State interaktif Section D: slider prediksi nilai x
  const [prediksiX, setPrediksiX] = useState<number>(7);

  // State interaktif Section E: manipulasi nilai a dan b
  const [paramA, setParamA] = useState<number>(55);
  const [paramB, setParamB] = useState<number>(3.5);

  const sections: { id: 'A' | 'B' | 'C' | 'D' | 'E'; label: string; title: string }[] = [
    { id: 'A', label: 'Bagian A', title: 'Diagram Pencar' },
    { id: 'B', label: 'Bagian B', title: 'Regresi Linear' },
    { id: 'C', label: 'Bagian C', title: 'Arah Hubungan Variabel' },
    { id: 'D', label: 'Bagian D', title: 'Line of Best Fit' },
    { id: 'E', label: 'Bagian E', title: 'Persamaan y = a + bx' },
  ];

  const currentSectionIndex = sections.findIndex((s) => s.id === activeSection);

  const handleNextSection = () => {
    if (currentSectionIndex < sections.length - 1) {
      setActiveSection(sections[currentSectionIndex + 1].id);
    }
  };

  const handlePrevSection = () => {
    if (currentSectionIndex > 0) {
      setActiveSection(sections[currentSectionIndex - 1].id);
    }
  };

  // =========================================================================
  // 1. COVER PAGE KHUSUS MATERI (WARNA UNGU - KUNING - PUTIH)
  // =========================================================================
  if (!hasStartedReading) {
    return (
      <div className="w-full rounded-3xl bg-gradient-to-br from-purple-900 via-indigo-950 to-purple-950 border-2 border-amber-400/40 p-6 sm:p-10 text-white shadow-2xl relative overflow-hidden transition-all duration-300">
        {/* Glow ambient accents ungu-kuning */}
        <div className="absolute -top-24 -left-24 w-80 h-80 bg-purple-600/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-amber-400/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto flex flex-col items-center text-center space-y-6">
          {/* Badge Tag */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400/20 border border-amber-400/50 text-amber-300 text-xs sm:text-sm font-bold tracking-wide uppercase shadow-sm">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Materi Pembelajaran Matematika Fase F</span>
          </div>

          {/* Visual Mini Scatter Plot & Line of Best Fit Icon */}
          <div className="w-full max-w-md h-40 sm:h-48 bg-purple-950/70 border border-purple-500/30 rounded-2xl p-4 relative flex items-center justify-center shadow-inner">
            <svg viewBox="0 0 300 120" className="w-full h-full">
              {/* Axes */}
              <line x1="30" y1="100" x2="280" y2="100" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="2,2" />
              <line x1="30" y1="20" x2="30" y2="100" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="2,2" />
              
              {/* Line of Best Fit (Kuning Emas) */}
              <line x1="40" y1="90" x2="270" y2="30" stroke="#FACC15" strokeWidth="3.5" strokeLinecap="round" />

              {/* Scatter Points (Putih Berkilau dengan border ungu) */}
              {[
                { cx: 50, cy: 85 },
                { cx: 80, cy: 82 },
                { cx: 105, cy: 68 },
                { cx: 130, cy: 75 },
                { cx: 160, cy: 55 },
                { cx: 190, cy: 50 },
                { cx: 215, cy: 45 },
                { cx: 245, cy: 32 },
                { cx: 260, cy: 38 },
              ].map((p, i) => (
                <circle
                  key={i}
                  cx={p.cx}
                  cy={p.cy}
                  r="5"
                  fill="#FFFFFF"
                  stroke="#A855F7"
                  strokeWidth="2"
                  className="animate-pulse"
                />
              ))}

              {/* Text label x & y */}
              <text x="250" y="115" fill="#FDE047" fontSize="10" fontWeight="bold">Sumbu x</text>
              <text x="10" y="25" fill="#FDE047" fontSize="10" fontWeight="bold">Sumbu y</text>
            </svg>
            <div className="absolute top-2 right-3 text-[10px] font-bold text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-400/30">
              Line of Best Fit
            </div>
          </div>

          {/* Judul Utama */}
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white drop-shadow-md">
              REGRESI LINEAR
            </h1>
            <p className="text-base sm:text-xl font-medium text-amber-300 max-w-xl">
              Memahami Hubungan, Pola, dan Prediksi dari Data
            </p>
          </div>

          <p className="text-xs sm:text-sm text-slate-200 max-w-lg leading-relaxed">
            Eksplorasi konsep diagram pencar (scatter plot), analisis korelasi, penentuan garis kecenderungan terbaik, dan persamaan matematis regresi linear secara visual dan interaktif.
          </p>

          {/* Tombol MULAI BELAJAR */}
          <button
            id="btn-mulai-belajar-regresi-linear"
            type="button"
            onClick={() => setHasStartedReading(true)}
            className="px-8 py-3.5 sm:px-10 sm:py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-purple-950 font-black text-sm sm:text-base tracking-wide shadow-xl shadow-amber-500/30 hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-3"
          >
            <span>🚀 MULAI BELAJAR</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    );
  }

  // =========================================================================
  // 2. TAMPILAN MATERI PEMBELAJARAN LENGKAP DENGAN KARTU DAN SECTION KHUSUS
  // =========================================================================
  return (
    <div className="w-full space-y-5 transition-all duration-300">
      {/* Top Header Navigation Materi */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-950 rounded-2xl p-4 sm:p-5 text-white border border-purple-500/30 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-purple-950 uppercase tracking-wider">
              Modul Matematika
            </span>
            <span className="text-xs text-purple-200 font-semibold">Fase F SMA</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white mt-1">
            Regresi Linear: {sections[currentSectionIndex].title}
          </h2>
        </div>

        <button
          type="button"
          onClick={() => setHasStartedReading(false)}
          className="self-start sm:self-auto px-3 py-1.5 rounded-xl bg-purple-950/70 hover:bg-purple-900 text-purple-200 hover:text-white border border-purple-400/30 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Kembali ke Cover</span>
        </button>
      </div>

      {/* Navigasi Section Tabs (A, B, C, D, E) */}
      <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-1 scrollbar-none">
        {sections.map((s, idx) => {
          const isActive = s.id === activeSection;
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setActiveSection(s.id)}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-amber-400 text-purple-950 shadow-md font-extrabold ring-2 ring-amber-300/50'
                  : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
              }`}
            >
              <span>{s.id}.</span>
              <span>{s.title}</span>
            </button>
          );
        })}
      </div>

      {/* =====================================================================
          SECTION A: DIAGRAM PANCAR (SCATTER PLOT)
          ===================================================================== */}
      {activeSection === 'A' && (
        <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-purple-500/30 shadow-lg space-y-6 animate-in fade-in">
          {/* Header Bagian A */}
          <div className="border-b border-slate-800 pb-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
              <ScatterChart className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">Bagian A</span>
              <h3 className="text-base sm:text-xl font-bold text-white">Diagram Pancar (Scatter Plot)</h3>
            </div>
          </div>

          {/* Definisi Lengkap Tanpa Meringkas */}
          <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
            <p>
              <strong>Diagram pancar</strong> adalah penyajian data yang menggunakan titik-titik pada bidang koordinat untuk menunjukkan hubungan antara dua variabel numerik.
            </p>
            <p>
              Setiap titik pada diagram pancar mewakili satu pasangan data <strong>(x, y)</strong>, dengan:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-300 pl-2">
              <li>
                <strong className="text-amber-300">x</strong> = variabel pertama atau variabel penjelas;
              </li>
              <li>
                <strong className="text-amber-300">y</strong> = variabel kedua atau variabel yang diamati/diprediksi.
              </li>
            </ul>
          </div>

          {/* Contoh Tabel Data Numerik Relevan Siswa */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TableIcon className="w-4 h-4 text-amber-400" />
              <h4 className="text-xs sm:text-sm font-bold text-white">
                Contoh Tabel Data: Waktu Belajar (x) vs Nilai Ujian Matematika (y)
              </h4>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-700 bg-slate-950/60 shadow-xs">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-purple-950/80 text-amber-300 font-bold border-b border-slate-700">
                  <tr>
                    <th className="p-2.5 sm:p-3">Siswa</th>
                    <th className="p-2.5 sm:p-3">Waktu Belajar (x) [Jam/Minggu]</th>
                    <th className="p-2.5 sm:p-3">Nilai Ujian (y) [Skor 0–100]</th>
                    <th className="p-2.5 sm:p-3">Titik Koordinat (x, y)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {sampleStudentData.map((d) => (
                    <tr
                      key={d.id}
                      onMouseEnter={() => setHoveredPointA(d)}
                      onMouseLeave={() => setHoveredPointA(null)}
                      className={`transition-colors cursor-pointer ${
                        hoveredPointA?.id === d.id ? 'bg-purple-800/40 text-amber-300 font-semibold' : 'hover:bg-slate-800/50'
                      }`}
                    >
                      <td className="p-2.5 sm:p-3 font-medium">{d.siswa}</td>
                      <td className="p-2.5 sm:p-3">{d.x} jam</td>
                      <td className="p-2.5 sm:p-3">{d.y}</td>
                      <td className="p-2.5 sm:p-3 font-mono text-purple-300">({d.x}, {d.y})</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-[11px] text-slate-400 italic">
              *Arahkan kursor atau sentuh baris tabel di atas untuk menyorot titik yang sesuai pada diagram pencar berikut.
            </p>
          </div>

          {/* Diagram Pencar Otomatis Berdasarkan Data */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ScatterChart className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  Visualisasi Diagram Pencar Otomatis
                </h4>
              </div>
              {hoveredPointA && (
                <span className="text-[11px] font-bold text-amber-300 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-400/40 animate-in fade-in">
                  Titik Terpilih: {hoveredPointA.siswa} ({hoveredPointA.x} jam, skor {hoveredPointA.y})
                </span>
              )}
            </div>

            <div className="w-full bg-slate-950 rounded-2xl border border-slate-700 p-4 sm:p-6 flex flex-col items-center">
              <div className="w-full max-w-xl aspect-[16/10] relative">
                <svg viewBox="0 0 500 300" className="w-full h-full">
                  {/* Grid Lines */}
                  {[60, 120, 180, 240].map((yVal, i) => (
                    <line key={i} x1="50" y1={yVal} x2="470" y2={yVal} stroke="#334155" strokeWidth="1" strokeDasharray="3,3" />
                  ))}
                  {[120, 190, 260, 330, 400].map((xVal, i) => (
                    <line key={i} x1={xVal} y1="30" x2={xVal} y2="250" stroke="#334155" strokeWidth="1" strokeDasharray="3,3" />
                  ))}

                  {/* Sumbu X & Sumbu Y */}
                  <line x1="50" y1="250" x2="470" y2="250" stroke="#CBD5E1" strokeWidth="2.5" />
                  <line x1="50" y1="30" x2="50" y2="250" stroke="#CBD5E1" strokeWidth="2.5" />

                  {/* Label Sumbu */}
                  <text x="240" y="285" fill="#FACC15" fontSize="12" fontWeight="bold" textAnchor="middle">
                    Waktu Belajar (x) [Jam/Minggu]
                  </text>
                  <text x="15" y="140" fill="#FACC15" fontSize="12" fontWeight="bold" transform="rotate(-90 15 140)" textAnchor="middle">
                    Nilai Ujian (y)
                  </text>

                  {/* Tick Marks Sumbu X (0 to 14 jam) */}
                  {[0, 2, 4, 6, 8, 10, 12, 14].map((val) => {
                    const cx = 50 + (val / 14) * 410;
                    return (
                      <g key={val}>
                        <line x1={cx} y1="250" x2={cx} y2="255" stroke="#CBD5E1" strokeWidth="2" />
                        <text x={cx} y="268" fill="#94A3B8" fontSize="10" textAnchor="middle">{val}</text>
                      </g>
                    );
                  })}

                  {/* Tick Marks Sumbu Y (50 to 100) */}
                  {[50, 60, 70, 80, 90, 100].map((val) => {
                    const cy = 250 - ((val - 50) / 50) * 210;
                    return (
                      <g key={val}>
                        <line x1="45" y1={cy} x2="50" y2={cy} stroke="#CBD5E1" strokeWidth="2" />
                        <text x="40" y={cy + 3} fill="#94A3B8" fontSize="10" textAnchor="end">{val}</text>
                      </g>
                    );
                  })}

                  {/* Data Points */}
                  {sampleStudentData.map((d) => {
                    const cx = 50 + (d.x / 14) * 410;
                    const cy = 250 - ((d.y - 50) / 50) * 210;
                    const isHovered = hoveredPointA?.id === d.id;

                    return (
                      <g key={d.id} onMouseEnter={() => setHoveredPointA(d)} onMouseLeave={() => setHoveredPointA(null)} className="cursor-pointer">
                        {isHovered && (
                          <circle cx={cx} cy={cy} r="14" fill="#FACC15" fillOpacity="0.25" className="animate-ping" />
                        )}
                        <circle
                          cx={cx}
                          cy={cy}
                          r={isHovered ? 8 : 6}
                          fill={isHovered ? '#FACC15' : '#FFFFFF'}
                          stroke="#9333EA"
                          strokeWidth="2.5"
                          className="transition-all"
                        />
                        <text
                          x={cx}
                          y={cy - 9}
                          fill={isHovered ? '#FACC15' : '#E2E8F0'}
                          fontSize={isHovered ? '11' : '9'}
                          fontWeight={isHovered ? 'bold' : 'normal'}
                          textAnchor="middle"
                        >
                          {d.siswa}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SECTION B: PENGERTIAN REGRESI LINEAR & LINE OF BEST FIT
          ===================================================================== */}
      {activeSection === 'B' && (
        <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-purple-500/30 shadow-lg space-y-6 animate-in fade-in">
          {/* Header Bagian B */}
          <div className="border-b border-slate-800 pb-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">Bagian B</span>
              <h3 className="text-base sm:text-xl font-bold text-white">Pengertian Regresi Linear</h3>
            </div>
          </div>

          {/* Teks Lengkap Tanpa Meringkas */}
          <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
            <p>
              <strong>Regresi linear</strong> merupakan metode untuk memperkirakan hubungan antara dua variabel numerik dengan menggunakan garis lurus yang mewakili kecenderungan atau tren umum dari data. Garis tersebut disebut <strong className="text-amber-300">Line of Best Fit</strong> atau garis kecenderungan terbaik.
            </p>
            <p>
              Dalam diagram pencar (scatter plot), setiap titik mewakili pasangan data dari dua variabel. Line of Best Fit digambarkan sebagai garis lurus yang paling mendekati pola sebaran titik-titik tersebut sehingga dapat membantu kita memahami hubungan antara kedua variabel dan membuat perkiraan berdasarkan data.
            </p>
          </div>

          {/* Contoh Scatter Plot dengan Line of Best Fit */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <LineChartIcon className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  Contoh Scatter Plot dengan Line of Best Fit
                </h4>
              </div>

              <button
                type="button"
                onClick={() => setShowBestFitB((prev) => !prev)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 self-start sm:self-auto ${
                  showBestFitB
                    ? 'bg-amber-400 text-purple-950 shadow-md font-extrabold'
                    : 'bg-slate-800 text-slate-300 border border-slate-700'
                }`}
              >
                <span>{showBestFitB ? '✓ Line of Best Fit Aktif' : 'Tampilkan Line of Best Fit'}</span>
              </button>
            </div>

            <div className="w-full bg-slate-950 rounded-2xl border border-slate-700 p-4 sm:p-6 flex flex-col items-center">
              <div className="w-full max-w-xl aspect-[16/10] relative">
                <svg viewBox="0 0 500 300" className="w-full h-full">
                  {/* Grid */}
                  {[60, 120, 180, 240].map((yVal, i) => (
                    <line key={i} x1="50" y1={yVal} x2="470" y2={yVal} stroke="#334155" strokeWidth="1" strokeDasharray="3,3" />
                  ))}

                  {/* Sumbu */}
                  <line x1="50" y1="250" x2="470" y2="250" stroke="#CBD5E1" strokeWidth="2.5" />
                  <line x1="50" y1="30" x2="50" y2="250" stroke="#CBD5E1" strokeWidth="2.5" />

                  <text x="240" y="285" fill="#FACC15" fontSize="12" fontWeight="bold" textAnchor="middle">
                    Variabel x (Variabel Penjelas)
                  </text>
                  <text x="15" y="140" fill="#FACC15" fontSize="12" fontWeight="bold" transform="rotate(-90 15 140)" textAnchor="middle">
                    Variabel y (Variabel Respon)
                  </text>

                  {/* Data Points */}
                  {sampleStudentData.map((d) => {
                    const cx = 50 + (d.x / 14) * 410;
                    const cy = 250 - ((d.y - 50) / 50) * 210;
                    return (
                      <circle
                        key={d.id}
                        cx={cx}
                        cy={cy}
                        r="6"
                        fill="#FFFFFF"
                        stroke="#9333EA"
                        strokeWidth="2.5"
                      />
                    );
                  })}

                  {/* Line of Best Fit (y = 54.5 + 3.48x) */}
                  {showBestFitB && (
                    <g>
                      <line
                        x1="50"
                        y1="230"
                        x2="450"
                        y2="45"
                        stroke="#FACC15"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        className="animate-pulse"
                      />
                      <rect x="260" y="80" width="160" height="30" rx="6" fill="#581C87" stroke="#FACC15" strokeWidth="1.5" />
                      <text x="340" y="99" fill="#FFFFFF" fontSize="11" fontWeight="bold" textAnchor="middle">
                        Line of Best Fit (Tren Data)
                      </text>
                    </g>
                  )}
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SECTION C: MENGENAL HUBUNGAN ANTARA DUA VARIABEL (KORELASI)
          ===================================================================== */}
      {activeSection === 'C' && (
        <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-purple-500/30 shadow-lg space-y-6 animate-in fade-in">
          {/* Header Bagian C */}
          <div className="border-b border-slate-800 pb-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
              <BookOpen className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">Bagian C</span>
              <h3 className="text-base sm:text-xl font-bold text-white">Mengenal Hubungan antara Dua Variabel</h3>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-200">
            Hubungan antara dua variabel numerik dapat diamati melalui arah dan pola sebaran titik pada diagram pencar.
          </p>

          {/* 3 Macam Korelasi Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 1. Korelasi Positif */}
            <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-3 flex flex-col justify-between">
              <div>
                <div className="inline-block px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-400/30 mb-2">
                  1. Korelasi Positif
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Ketika nilai variabel x meningkat, nilai variabel y cenderung meningkat. Titik-titik pada diagram pencar menunjukkan tren dari <strong>kiri bawah ke kanan atas</strong>.
                </p>
                <div className="p-2.5 mt-2 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-amber-300">
                  <strong>Contoh:</strong> Semakin lama waktu belajar, nilai ujian cenderung semakin tinggi.
                </div>
              </div>

              {/* Grafik Scatter Plot Korelasi Positif Otomatis */}
              <div className="w-full aspect-[4/3] bg-slate-950 rounded-xl border border-slate-800 p-2 flex items-center justify-center">
                <svg viewBox="0 0 160 120" className="w-full h-full">
                  <line x1="20" y1="100" x2="145" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  <line x1="20" y1="15" x2="20" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  {/* Line */}
                  <line x1="25" y1="90" x2="140" y2="25" stroke="#10B981" strokeWidth="2.5" />
                  {/* Points */}
                  {[
                    { cx: 30, cy: 88 },
                    { cx: 45, cy: 78 },
                    { cx: 60, cy: 75 },
                    { cx: 75, cy: 62 },
                    { cx: 90, cy: 55 },
                    { cx: 105, cy: 45 },
                    { cx: 120, cy: 38 },
                    { cx: 135, cy: 26 },
                  ].map((pt, i) => (
                    <circle key={i} cx={pt.cx} cy={pt.cy} r="3.5" fill="#FFFFFF" stroke="#10B981" strokeWidth="1.5" />
                  ))}
                  <text x="80" y="114" fill="#A7F3D0" fontSize="8" textAnchor="middle">Kiri Bawah ↗ Kanan Atas</text>
                </svg>
              </div>
            </div>

            {/* 2. Korelasi Negatif */}
            <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-3 flex flex-col justify-between">
              <div>
                <div className="inline-block px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-400/30 mb-2">
                  2. Korelasi Negatif
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Ketika nilai variabel x meningkat, nilai variabel y cenderung menurun. Titik-titik pada diagram pencar menunjukkan tren dari <strong>kiri atas ke kanan bawah</strong>.
                </p>
                <div className="p-2.5 mt-2 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-amber-300">
                  <strong>Contoh:</strong> Semakin lama durasi menggunakan gawai untuk hiburan, nilai Matematika mungkin cenderung menurun.
                </div>
              </div>

              {/* Grafik Scatter Plot Korelasi Negatif Otomatis */}
              <div className="w-full aspect-[4/3] bg-slate-950 rounded-xl border border-slate-800 p-2 flex items-center justify-center">
                <svg viewBox="0 0 160 120" className="w-full h-full">
                  <line x1="20" y1="100" x2="145" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  <line x1="20" y1="15" x2="20" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  {/* Line */}
                  <line x1="25" y1="25" x2="140" y2="90" stroke="#F43F5E" strokeWidth="2.5" />
                  {/* Points */}
                  {[
                    { cx: 30, cy: 30 },
                    { cx: 45, cy: 40 },
                    { cx: 60, cy: 45 },
                    { cx: 75, cy: 58 },
                    { cx: 90, cy: 65 },
                    { cx: 105, cy: 72 },
                    { cx: 120, cy: 80 },
                    { cx: 135, cy: 88 },
                  ].map((pt, i) => (
                    <circle key={i} cx={pt.cx} cy={pt.cy} r="3.5" fill="#FFFFFF" stroke="#F43F5E" strokeWidth="1.5" />
                  ))}
                  <text x="80" y="114" fill="#FECDD3" fontSize="8" textAnchor="middle">Kiri Atas ↘ Kanan Bawah</text>
                </svg>
              </div>
            </div>

            {/* 3. Tidak Ada Korelasi Linear yang Jelas */}
            <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-3 flex flex-col justify-between">
              <div>
                <div className="inline-block px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-400/30 mb-2">
                  3. Tidak Ada Korelasi Linear yang Jelas
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  Perubahan pada variabel x tidak menunjukkan kecenderungan perubahan yang konsisten pada variabel y. Titik-titik tersebar <strong>tanpa pola garis lurus yang jelas</strong>.
                </p>
                <div className="p-2.5 mt-2 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] text-amber-300">
                  <strong>Contoh:</strong> Hubungan antara nomor urut siswa dan tinggi badan.
                </div>
              </div>

              {/* Grafik Scatter Plot Tanpa Korelasi Otomatis */}
              <div className="w-full aspect-[4/3] bg-slate-950 rounded-xl border border-slate-800 p-2 flex items-center justify-center">
                <svg viewBox="0 0 160 120" className="w-full h-full">
                  <line x1="20" y1="100" x2="145" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  <line x1="20" y1="15" x2="20" y2="100" stroke="#64748B" strokeWidth="1.5" />
                  {/* Points tersebar acak */}
                  {[
                    { cx: 30, cy: 45 },
                    { cx: 40, cy: 80 },
                    { cx: 55, cy: 35 },
                    { cx: 70, cy: 90 },
                    { cx: 85, cy: 40 },
                    { cx: 100, cy: 75 },
                    { cx: 115, cy: 30 },
                    { cx: 130, cy: 65 },
                    { cx: 135, cy: 85 },
                  ].map((pt, i) => (
                    <circle key={i} cx={pt.cx} cy={pt.cy} r="3.5" fill="#FFFFFF" stroke="#FACC15" strokeWidth="1.5" />
                  ))}
                  <text x="80" y="114" fill="#FDE047" fontSize="8" textAnchor="middle">Tersebar Acak (Tanpa Pola)</text>
                </svg>
              </div>
            </div>
          </div>

          {/* Highlight Penting: Korelasi != Sebab-Akibat */}
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-400/10 border-2 border-amber-400/50 flex items-start gap-3.5 shadow-md">
            <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs sm:text-sm text-slate-100 leading-relaxed">
              <strong className="text-amber-300 block mb-1">Perlu Diingat!</strong>
              Perlu diingat bahwa korelasi tidak selalu menunjukkan hubungan sebab-akibat. Dua variabel dapat memiliki hubungan, tetapi belum tentu perubahan salah satunya menyebabkan perubahan pada variabel lainnya.
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SECTION D: MEMPERKIRAKAN LINE OF BEST FIT (5 LANGKAH VISUAL BERNOMOR)
          ===================================================================== */}
      {activeSection === 'D' && (
        <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-purple-500/30 shadow-lg space-y-6 animate-in fade-in">
          {/* Header Bagian D */}
          <div className="border-b border-slate-800 pb-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
              <LineChartIcon className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">Bagian D</span>
              <h3 className="text-base sm:text-xl font-bold text-white">Memperkirakan Line of Best Fit</h3>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed">
            <p>
              <strong>Line of Best Fit</strong> merupakan garis lurus yang menggambarkan tren umum dari sekumpulan data. Garis ini tidak harus melalui setiap titik data, tetapi diupayakan sedekat mungkin dengan pola sebaran titik secara keseluruhan.
            </p>
            <p className="mt-2 text-slate-300">
              Untuk memperkirakan garis kecenderungan terbaik, kita dapat melakukan langkah-langkah berikut:
            </p>
          </div>

          {/* Alur Visual Bernomor (5 Langkah) */}
          <div className="space-y-3">
            {[
              {
                step: 1,
                title: 'Amati diagram pencar.',
                desc: 'Perhatikan pola sebaran titik-titik data, apakah menunjukkan tren naik, turun, atau tidak memiliki pola linear yang jelas.',
                badge: 'Langkah 1',
              },
              {
                step: 2,
                title: 'Tentukan arah garis.',
                desc: 'Perkirakan apakah garis akan memiliki kemiringan positif atau negatif berdasarkan kecenderungan data.',
                badge: 'Langkah 2',
              },
              {
                step: 3,
                title: 'Gambarkan garis kecenderungan.',
                desc: 'Tarik garis lurus yang melewati bagian tengah sebaran titik, dengan mempertimbangkan pola data secara keseluruhan.',
                badge: 'Langkah 3',
              },
              {
                step: 4,
                title: 'Evaluasi posisi garis.',
                desc: 'Perhatikan apakah titik-titik data tersebar relatif seimbang di atas dan di bawah garis serta apakah garis telah mewakili tren umum data dengan baik.',
                badge: 'Langkah 4',
              },
              {
                step: 5,
                title: 'Gunakan garis untuk membuat prediksi.',
                desc: 'Perkirakan nilai variabel y berdasarkan nilai variabel x yang diketahui, selama perkiraan tersebut masih sesuai dengan rentang data dan konteksnya.',
                badge: 'Langkah 5',
              },
            ].map((st) => (
              <div
                key={st.step}
                className="p-3.5 sm:p-4 rounded-xl sm:rounded-2xl bg-slate-950/80 border border-slate-700/80 flex items-start gap-3.5 transition-all hover:border-amber-400/50"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-purple-950 font-black text-sm flex items-center justify-center shrink-0 shadow-sm">
                  {st.step}
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                    <span>{st.title}</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {st.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Contoh Scatter Plot dengan Line of Best Fit & Simulasi Prediksi */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Simulasi Langkah 5: Prediksi Nilai y dari Nilai x</span>
            </h4>

            <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-700 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-purple-950/50 p-3 rounded-xl border border-purple-500/30">
                <div className="text-xs text-slate-200">
                  Geser nilai <strong>Waktu Belajar (x)</strong> untuk memprediksi <strong>Nilai Ujian (ŷ)</strong>:
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="1"
                    max="14"
                    value={prediksiX}
                    onChange={(e) => setPrediksiX(Number(e.target.value))}
                    className="accent-amber-400 cursor-pointer"
                  />
                  <span className="text-xs font-mono font-bold text-amber-300 bg-purple-900 px-2 py-1 rounded">
                    x = {prediksiX} jam
                  </span>
                </div>
              </div>

              {/* Grafik dengan titik proyeksi prediksi */}
              <div className="w-full max-w-xl mx-auto aspect-[16/10] relative">
                <svg viewBox="0 0 500 300" className="w-full h-full">
                  {/* Grid */}
                  {[60, 120, 180, 240].map((yVal, i) => (
                    <line key={i} x1="50" y1={yVal} x2="470" y2={yVal} stroke="#334155" strokeWidth="1" strokeDasharray="3,3" />
                  ))}

                  <line x1="50" y1="250" x2="470" y2="250" stroke="#CBD5E1" strokeWidth="2" />
                  <line x1="50" y1="30" x2="50" y2="250" stroke="#CBD5E1" strokeWidth="2" />

                  {/* Line of Best Fit (y = 54.5 + 3.48x) */}
                  <line x1="50" y1="231" x2="460" y2="40" stroke="#FACC15" strokeWidth="3" strokeLinecap="round" />

                  {/* Scatter points */}
                  {sampleStudentData.map((d) => {
                    const cx = 50 + (d.x / 14) * 410;
                    const cy = 250 - ((d.y - 50) / 50) * 210;
                    return <circle key={d.id} cx={cx} cy={cy} r="4.5" fill="#FFFFFF" stroke="#9333EA" strokeWidth="1.5" />;
                  })}

                  {/* Proyeksi Garis Prediksi */}
                  {(() => {
                    const projY = Math.round(54.5 + 3.48 * prediksiX);
                    const cx = 50 + (prediksiX / 14) * 410;
                    const cy = 250 - ((projY - 50) / 50) * 210;
                    return (
                      <g>
                        <line x1={cx} y1="250" x2={cx} y2={cy} stroke="#A855F7" strokeWidth="2" strokeDasharray="4,4" />
                        <line x1="50" y1={cy} x2={cx} y2={cy} stroke="#A855F7" strokeWidth="2" strokeDasharray="4,4" />
                        <circle cx={cx} cy={cy} r="8" fill="#FACC15" stroke="#7E22CE" strokeWidth="3" />
                        <rect x={cx + 10} y={cy - 20} width="130" height="25" rx="5" fill="#4C1D95" stroke="#FACC15" strokeWidth="1" />
                        <text x={cx + 18} y={cy - 4} fill="#FDE047" fontSize="10" fontWeight="bold">
                          Prediksi ŷ ≈ {projY}
                        </text>
                      </g>
                    );
                  })()}
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          SECTION E: PERSAMAAN GARIS REGRESI LINEAR (y = a + bx)
          ===================================================================== */}
      {activeSection === 'E' && (
        <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-purple-500/30 shadow-lg space-y-6 animate-in fade-in">
          {/* Header Bagian E */}
          <div className="border-b border-slate-800 pb-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-500/40 text-purple-300 flex items-center justify-center shrink-0">
              <TrendingUp className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase text-amber-400 tracking-wider">Bagian E</span>
              <h3 className="text-base sm:text-xl font-bold text-white">Persamaan Garis Regresi Linear</h3>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-200">
            Secara umum, persamaan garis linear dapat dituliskan sebagai:
          </p>

          {/* KARTU VISUAL BESAR y = a + bx (UNGU - KUNING - PUTIH) */}
          <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-950 border-2 border-amber-400/50 shadow-2xl text-center space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-300">
              Bentuk Umum Persamaan
            </span>

            <div className="text-4xl sm:text-6xl font-black tracking-wider text-white drop-shadow-lg flex items-center justify-center gap-3">
              <span className="text-amber-300">y</span>
              <span className="text-white">=</span>
              <span className="text-purple-200">a</span>
              <span className="text-white">+</span>
              <span className="text-amber-300">b</span>
              <span className="text-white">x</span>
            </div>

            {/* Penjelasan Visual untuk a dan b */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl mx-auto pt-2 text-left">
              <div className="p-3.5 rounded-xl bg-purple-950/80 border border-purple-400/30 text-xs">
                <span className="font-bold text-purple-300 block text-sm mb-1">Konstanta (a)</span>
                <span className="text-slate-200">
                  Titik potong garis dengan sumbu y (intersep), yaitu nilai y saat x bernilai nol.
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-950/80 border border-amber-400/40 text-xs">
                <span className="font-bold text-amber-300 block text-sm mb-1">Gradien (b)</span>
                <span className="text-slate-200">
                  Kemiringan garis, menyatakan laju perubahan nilai y untuk setiap pertambahan satu satuan x.
                </span>
              </div>
            </div>
          </div>

          {/* Keterangan Komponen Lengkap Tanpa Meringkas */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-700 text-xs sm:text-sm text-slate-200 space-y-2">
            <h4 className="font-bold text-white text-sm mb-2 text-amber-400">Keterangan:</h4>
            <ul className="space-y-1.5 list-disc list-inside text-slate-300">
              <li>
                <strong className="text-white">y</strong> = nilai variabel y yang diperkirakan.
              </li>
              <li>
                <strong className="text-white">x</strong> = nilai variabel bebas.
              </li>
              <li>
                <strong className="text-white">a</strong> = titik potong garis dengan sumbu y.
              </li>
              <li>
                <strong className="text-white">b</strong> = gradien atau kemiringan garis.
              </li>
            </ul>
            <p className="pt-2 text-slate-400 text-xs italic">
              Dalam pembelajaran ini, nilai a dan b dapat diperkirakan dari garis yang digambar pada diagram pencar.
            </p>
          </div>

          {/* Makna Gradien (b) */}
          <div className="space-y-3">
            <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-400" />
              <span>Makna Gradien (b):</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-2">
                <div className="font-bold text-emerald-400 text-sm">Jika b &gt; 0</div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Garis memiliki arah <strong>naik dari kiri ke kanan</strong> (kemiringan positif).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-rose-500/40 space-y-2">
                <div className="font-bold text-rose-400 text-sm">Jika b &lt; 0</div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Garis memiliki arah <strong>turun dari kiri ke kanan</strong> (kemiringan negatif).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/40 space-y-2">
                <div className="font-bold text-amber-400 text-sm">Jika b = 0</div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Garis <strong>mendatar</strong> dan tidak menunjukkan perubahan linear pada nilai prediksi y.
                </p>
              </div>
            </div>
          </div>

          {/* Eksplorasi Interaktif Parameter a dan b */}
          <div className="p-4 sm:p-5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs sm:text-sm font-bold text-amber-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span>Eksplorasi Interaktif Parameter Garis: y = {paramA} + {paramB}x</span>
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  Ubah Titik Potong (a): <span className="text-amber-300">{paramA}</span>
                </label>
                <input
                  type="range"
                  min="40"
                  max="70"
                  value={paramA}
                  onChange={(e) => setParamA(Number(e.target.value))}
                  className="w-full accent-purple-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  Ubah Kemiringan (b): <span className="text-amber-300">{paramB}</span>
                </label>
                <input
                  type="range"
                  min="-5"
                  max="8"
                  step="0.5"
                  value={paramB}
                  onChange={(e) => setParamB(Number(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Visualisasi Mini Sumbu */}
            <div className="w-full h-32 bg-slate-950 rounded-xl border border-slate-800 p-2 flex items-center justify-center">
              <svg viewBox="0 0 300 100" className="w-full h-full">
                <line x1="30" y1="85" x2="280" y2="85" stroke="#64748B" strokeWidth="1.5" />
                <line x1="30" y1="15" x2="30" y2="85" stroke="#64748B" strokeWidth="1.5" />
                {(() => {
                  const y1 = 85 - ((paramA - 40) / 40) * 60;
                  const y2 = y1 - paramB * 6;
                  return (
                    <g>
                      <line x1="30" y1={y1} x2="250" y2={Math.max(10, Math.min(90, y2))} stroke="#FACC15" strokeWidth="3" strokeLinecap="round" />
                      <circle cx="30" cy={y1} r="4" fill="#A855F7" />
                      <text x="36" y={y1 + 4} fill="#A855F7" fontSize="9" fontWeight="bold">a={paramA}</text>
                    </g>
                  );
                })()}
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* Footer Navigasi Antar Section (Sebelumnya / Selanjutnya) */}
      <div className="flex items-center justify-between gap-3 pt-2">
        <button
          type="button"
          onClick={handlePrevSection}
          disabled={currentSectionIndex === 0}
          className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer border border-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Bagian Sebelumnya</span>
        </button>

        <span className="text-xs text-slate-400 font-medium hidden sm:inline">
          {currentSectionIndex + 1} dari {sections.length} Bagian
        </span>

        {currentSectionIndex < sections.length - 1 ? (
          <button
            type="button"
            onClick={handleNextSection}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md"
          >
            <span>Lanjut: {sections[currentSectionIndex + 1].title}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300 bg-amber-950/60 px-3 py-2 rounded-xl border border-amber-400/30">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Seluruh Materi Telah Dipelajari!</span>
          </div>
        )}
      </div>
    </div>
  );
};
