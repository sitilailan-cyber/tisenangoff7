import React, { useState } from 'react';
import {
  Droplets,
  Plus,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  Heart,
  Users,
} from 'lucide-react';

interface SimulasiGolonganDarahProps {
  onRecordData: (data: {
    param1: string; // Nama Sampel Pasien
    param2: string; // Aglutinasi Anti-A, Anti-B, Anti-D
    param3: string; // Golongan Darah & Rhesus
    catatan: string; // Analisis Aglutinogen & Aglutinin
  }) => void;
}

interface PatientSample {
  id: string;
  name: string;
  code: string;
  bloodType: 'A' | 'B' | 'AB' | 'O';
  rhesus: '+' | '-';
  agglutinationA: boolean; // Menggumpal dengan Anti-A
  agglutinationB: boolean; // Menggumpal dengan Anti-B
  agglutinationD: boolean; // Menggumpal dengan Anti-D (Rhesus)
  aglutinogen: string;
  aglutinin: string;
}

const PATIENTS: PatientSample[] = [
  {
    id: 'pasien-1',
    name: 'Sampel Pasien 1 (Rian)',
    code: 'SP-01',
    bloodType: 'A',
    rhesus: '+',
    agglutinationA: true,
    agglutinationB: false,
    agglutinationD: true,
    aglutinogen: 'Aglutinogen A & Faktor Rh (D)',
    aglutinin: 'Aglutinin anti-B (β)',
  },
  {
    id: 'pasien-2',
    name: 'Sampel Pasien 2 (Nadia)',
    code: 'SP-02',
    bloodType: 'B',
    rhesus: '+',
    agglutinationA: false,
    agglutinationB: true,
    agglutinationD: true,
    aglutinogen: 'Aglutinogen B & Faktor Rh (D)',
    aglutinin: 'Aglutinin anti-A (α)',
  },
  {
    id: 'pasien-3',
    name: 'Sampel Pasien 3 (Dimas)',
    code: 'SP-03',
    bloodType: 'AB',
    rhesus: '+',
    agglutinationA: true,
    agglutinationB: true,
    agglutinationD: true,
    aglutinogen: 'Aglutinogen A, B & Faktor Rh (D)',
    aglutinin: 'Tidak memiliki aglutinin',
  },
  {
    id: 'pasien-4',
    name: 'Sampel Pasien 4 (Siti)',
    code: 'SP-04',
    bloodType: 'O',
    rhesus: '-',
    agglutinationA: false,
    agglutinationB: false,
    agglutinationD: false,
    aglutinogen: 'Tidak memiliki aglutinogen',
    aglutinin: 'Aglutinin anti-A (α) dan anti-B (β)',
  },
];

export const SimulasiGolonganDarah: React.FC<SimulasiGolonganDarahProps> = ({ onRecordData }) => {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('pasien-1');
  const [droppedA, setDroppedA] = useState<boolean>(false);
  const [droppedB, setDroppedB] = useState<boolean>(false);
  const [droppedD, setDroppedD] = useState<boolean>(false);
  const [isStirred, setIsStirred] = useState<boolean>(false);

  const activePatient = PATIENTS.find((p) => p.id === selectedPatientId) || PATIENTS[0];

  const handleSelectPatient = (pId: string) => {
    setSelectedPatientId(pId);
    setDroppedA(false);
    setDroppedB(false);
    setDroppedD(false);
    setIsStirred(false);
  };

  const handleResetSlide = () => {
    setDroppedA(false);
    setDroppedB(false);
    setDroppedD(false);
    setIsStirred(false);
  };

  const allReagentsAdded = droppedA && droppedB && droppedD;

  const handleRecord = () => {
    const resA = activePatient.agglutinationA ? 'Menggumpal (+)' : 'Tidak Menggumpal (-)';
    const resB = activePatient.agglutinationB ? 'Menggumpal (+)' : 'Tidak Menggumpal (-)';
    const resD = activePatient.agglutinationD ? 'Menggumpal (+)' : 'Tidak Menggumpal (-)';

    onRecordData({
      param1: `${activePatient.name} [${activePatient.code}]`,
      param2: `Anti-A: ${resA} • Anti-B: ${resB} • Anti-D: ${resD}`,
      param3: `Golongan Darah ${activePatient.bloodType} (Rh ${activePatient.rhesus})`,
      catatan: `Memiliki ${activePatient.aglutinogen} pada eritrosit dan ${activePatient.aglutinin} pada plasma darah.`,
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-6">
      {/* Header Simulasi Biologi */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 text-[10px] font-black uppercase">
            Biologi: Sistem Peredaran Darah & Imunologi
          </span>
          <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-600 fill-rose-600" />
            <span>Simulasi Uji Golongan Darah & Aglutinasi</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Lakukan uji reaksi antibodi-antigen menggunakan Serum Anti-A, Anti-B, dan Anti-D (Rhesus) pada kaca objek untuk menentukan golongan darah ABO.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRecord}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Catat ke Tabel</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Kaca Objek Uji Golongan Darah (Slide Glass) */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-5 sm:p-6 border border-slate-800 flex flex-col items-center justify-between relative shadow-xl min-h-[410px]">
          {/* Label Sampel Aktif */}
          <div className="text-center space-y-0.5 mb-2 z-10">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Kaca Preparat Darah Pasien
            </span>
            <div className="text-base font-black text-white flex items-center justify-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <span>{activePatient.name}</span>
            </div>
          </div>

          {/* Visual Kaca Objek Preparat dengan 3 Sumur (Anti-A, Anti-B, Anti-D) */}
          <div className="w-full max-w-md bg-gradient-to-r from-slate-900/90 via-slate-850 to-slate-900/90 rounded-2xl border-2 border-slate-600/60 p-4 shadow-2xl backdrop-blur-md my-4">
            <div className="grid grid-cols-3 gap-3">
              {/* SUMUR 1: ANTI-A */}
              <div className="flex flex-col items-center space-y-2">
                <span className="px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[10px] font-mono font-black">
                  Anti-A (Biru)
                </span>
                <div className="relative w-24 h-24 rounded-full border-2 border-slate-600 bg-slate-950 flex items-center justify-center overflow-hidden shadow-inner">
                  {/* Tetesan Darah Merah */}
                  <div className="w-16 h-16 rounded-full bg-rose-600/80 flex items-center justify-center relative overflow-hidden transition-all duration-300">
                    {/* Efek Reagen Anti-A ditambahkan */}
                    {droppedA && (
                      <div className="absolute inset-0 bg-blue-500/30 rounded-full" />
                    )}

                    {/* Efek Penggumpalan (Aglutinasi) jika sudah diaduk */}
                    {isStirred && droppedA && activePatient.agglutinationA ? (
                      <div className="absolute inset-0 p-1 grid grid-cols-3 gap-1 place-items-center">
                        {[...Array(9)].map((_, i) => (
                          <span
                            key={i}
                            className="w-2.5 h-2.5 rounded-full bg-rose-950 border border-rose-400 shadow-xs"
                          />
                        ))}
                      </div>
                    ) : isStirred && droppedA && !activePatient.agglutinationA ? (
                      <div className="absolute inset-0 bg-rose-600/90 flex items-center justify-center text-[9px] text-white/80 font-bold">
                        Homogen
                      </div>
                    ) : null}
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-slate-300 text-center">
                  {!droppedA
                    ? 'Belum diberi serum'
                    : !isStirred
                    ? 'Serum diteteskan'
                    : activePatient.agglutinationA
                    ? '🔴 Menggumpal (+)'
                    : '⚪ Tidak Menggumpal (-)'}
                </span>
              </div>

              {/* SUMUR 2: ANTI-B */}
              <div className="flex flex-col items-center space-y-2">
                <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-black">
                  Anti-B (Kuning)
                </span>
                <div className="relative w-24 h-24 rounded-full border-2 border-slate-600 bg-slate-950 flex items-center justify-center overflow-hidden shadow-inner">
                  {/* Tetesan Darah Merah */}
                  <div className="w-16 h-16 rounded-full bg-rose-600/80 flex items-center justify-center relative overflow-hidden transition-all duration-300">
                    {/* Efek Reagen Anti-B ditambahkan */}
                    {droppedB && (
                      <div className="absolute inset-0 bg-amber-400/30 rounded-full" />
                    )}

                    {/* Efek Penggumpalan (Aglutinasi) jika sudah diaduk */}
                    {isStirred && droppedB && activePatient.agglutinationB ? (
                      <div className="absolute inset-0 p-1 grid grid-cols-3 gap-1 place-items-center">
                        {[...Array(9)].map((_, i) => (
                          <span
                            key={i}
                            className="w-2.5 h-2.5 rounded-full bg-rose-950 border border-rose-400 shadow-xs"
                          />
                        ))}
                      </div>
                    ) : isStirred && droppedB && !activePatient.agglutinationB ? (
                      <div className="absolute inset-0 bg-rose-600/90 flex items-center justify-center text-[9px] text-white/80 font-bold">
                        Homogen
                      </div>
                    ) : null}
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-slate-300 text-center">
                  {!droppedB
                    ? 'Belum diberi serum'
                    : !isStirred
                    ? 'Serum diteteskan'
                    : activePatient.agglutinationB
                    ? '🔴 Menggumpal (+)'
                    : '⚪ Tidak Menggumpal (-)'}
                </span>
              </div>

              {/* SUMUR 3: ANTI-D (RHESUS) */}
              <div className="flex flex-col items-center space-y-2">
                <span className="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono font-black">
                  Anti-D (Rh)
                </span>
                <div className="relative w-24 h-24 rounded-full border-2 border-slate-600 bg-slate-950 flex items-center justify-center overflow-hidden shadow-inner">
                  {/* Tetesan Darah Merah */}
                  <div className="w-16 h-16 rounded-full bg-rose-600/80 flex items-center justify-center relative overflow-hidden transition-all duration-300">
                    {/* Efek Reagen Anti-D ditambahkan */}
                    {droppedD && (
                      <div className="absolute inset-0 bg-purple-400/30 rounded-full" />
                    )}

                    {/* Efek Penggumpalan (Aglutinasi) jika sudah diaduk */}
                    {isStirred && droppedD && activePatient.agglutinationD ? (
                      <div className="absolute inset-0 p-1 grid grid-cols-3 gap-1 place-items-center">
                        {[...Array(9)].map((_, i) => (
                          <span
                            key={i}
                            className="w-2.5 h-2.5 rounded-full bg-rose-950 border border-rose-400 shadow-xs"
                          />
                        ))}
                      </div>
                    ) : isStirred && droppedD && !activePatient.agglutinationD ? (
                      <div className="absolute inset-0 bg-rose-600/90 flex items-center justify-center text-[9px] text-white/80 font-bold">
                        Homogen
                      </div>
                    ) : null}
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-slate-300 text-center">
                  {!droppedD
                    ? 'Belum diberi serum'
                    : !isStirred
                    ? 'Serum diteteskan'
                    : activePatient.agglutinationD
                    ? '🔴 Menggumpal (+)'
                    : '⚪ Tidak Menggumpal (-)'}
                </span>
              </div>
            </div>
          </div>

          {/* Tombol Reagen Serum & Pengaduk */}
          <div className="w-full flex flex-wrap items-center justify-center gap-2 mt-2 z-10">
            <button
              type="button"
              onClick={() => setDroppedA(true)}
              disabled={droppedA}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Droplets className="w-3.5 h-3.5" />
              <span>Teteskan Anti-A</span>
            </button>

            <button
              type="button"
              onClick={() => setDroppedB(true)}
              disabled={droppedB}
              className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Droplets className="w-3.5 h-3.5" />
              <span>Teteskan Anti-B</span>
            </button>

            <button
              type="button"
              onClick={() => setDroppedD(true)}
              disabled={droppedD}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Droplets className="w-3.5 h-3.5" />
              <span>Teteskan Anti-D</span>
            </button>

            <button
              type="button"
              onClick={() => setIsStirred(true)}
              disabled={!allReagentsAdded || isStirred}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Aduk Sampel (Uji)</span>
            </button>

            <button
              type="button"
              onClick={handleResetSlide}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-1 border border-slate-700 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Bersihkan Kaca</span>
            </button>
          </div>
        </div>

        {/* Panel Pilihan Pasien & Kesimpulan Hasil */}
        <div className="lg:col-span-5 space-y-4">
          {/* 1. Pilih Sampel Pasien */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              1. Pilih Sampel Pasien
            </label>
            <div className="space-y-1.5">
              {PATIENTS.map((p) => {
                const isSelected = p.id === selectedPatientId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectPatient(p.id)}
                    className={`w-full p-2.5 rounded-xl text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between border ${
                      isSelected
                        ? 'bg-slate-900 text-white border-rose-500 shadow-md ring-1 ring-rose-500/50'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 shrink-0" />
                      <span className="truncate">{p.name}</span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300 shrink-0">
                      {p.code}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Kesimpulan Diagnosis Golongan Darah */}
          {isStirred && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs space-y-2 animate-in fade-in">
              <div className="font-bold flex items-center gap-1.5 text-rose-300">
                <CheckCircle2 className="w-4 h-4 text-rose-400" />
                <span>Diagnosis Golongan Darah:</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-rose-500/30 text-center">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                  Golongan Darah ABO & Rhesus
                </span>
                <span className="text-2xl font-black text-white font-mono mt-0.5 inline-block">
                  Tipe {activePatient.bloodType} (Rh {activePatient.rhesus})
                </span>
              </div>
              <div className="text-[11px] space-y-1 pt-1 text-slate-300">
                <p>
                  <strong className="text-rose-300">Aglutinogen:</strong> {activePatient.aglutinogen}
                </p>
                <p>
                  <strong className="text-rose-300">Aglutinin:</strong> {activePatient.aglutinin}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
