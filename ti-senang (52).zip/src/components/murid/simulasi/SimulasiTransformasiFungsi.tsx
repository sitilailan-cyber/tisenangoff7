import React, { useState, useMemo } from 'react';
import {
  RotateCcw,
  Plus,
  HelpCircle,
  Sliders,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';

interface SimulasiTransformasiFungsiProps {
  onRecordData: (data: {
    param1: string; // Fungsi & Transformasi
    param2: string; // Nilai Parameter (a, b, k)
    param3: string; // Titik Puncak / Pergeseran
    catatan: string;
  }) => void;
}

type FunctionType = 'kuadrat' | 'linear' | 'mutlak' | 'kubik';

export const SimulasiTransformasiFungsi: React.FC<SimulasiTransformasiFungsiProps> = ({
  onRecordData,
}) => {
  const [funcType, setFuncType] = useState<FunctionType>('kuadrat');
  const [a, setA] = useState<number>(0); // Translasi horizontal: f(x - a)
  const [b, setB] = useState<number>(0); // Translasi vertikal: + b
  const [k, setK] = useState<number>(1); // Dilatasi vertikal: k * f(...)
  const [reflectY, setReflectY] = useState<boolean>(false); // f(-x)
  const [showOriginal, setShowOriginal] = useState<boolean>(true);

  // Evaluasi fungsi dasar f(x)
  const evalBase = (x: number): number => {
    switch (funcType) {
      case 'kuadrat':
        return x * x;
      case 'linear':
        return x;
      case 'mutlak':
        return Math.abs(x);
      case 'kubik':
        return x * x * x;
      default:
        return x * x;
    }
  };

  // Evaluasi fungsi transformasi g(x) = k * f(±(x - a)) + b
  const evalTransformed = (x: number): number => {
    const effectiveX = reflectY ? -(x - a) : x - a;
    return k * evalBase(effectiveX) + b;
  };

  // Persamaan teks g(x)
  const equationText = useMemo(() => {
    const kStr = k === 1 ? '' : k === -1 ? '-' : `${k}`;
    const signA = a > 0 ? ` - ${a}` : a < 0 ? ` + ${Math.abs(a)}` : '';
    const signB = b > 0 ? ` + ${b}` : b < 0 ? ` - ${Math.abs(b)}` : '';
    const xInner = reflectY ? `(-x${signA})` : a !== 0 ? `(x${signA})` : 'x';

    switch (funcType) {
      case 'kuadrat':
        return `g(x) = ${kStr}${xInner}²${signB}`;
      case 'linear':
        return `g(x) = ${kStr}${xInner}${signB}`;
      case 'mutlak':
        return `g(x) = ${kStr}|${xInner}|${signB}`;
      case 'kubik':
        return `g(x) = ${kStr}${xInner}³${signB}`;
    }
  }, [funcType, a, b, k, reflectY]);

  // Titik Puncak atau Titik Acuan
  const vertex = useMemo(() => {
    const vx = a;
    const vy = b;
    return { x: vx, y: vy };
  }, [a, b]);

  // Generate SVG path koordinat kartesius (-8 s.d. +8)
  const width = 440;
  const height = 360;
  const scale = 22; // 22 pixels per 1 unit
  const originX = width / 2;
  const originY = height / 2;

  const toSvgX = (x: number) => originX + x * scale;
  const toSvgY = (y: number) => originY - y * scale;

  // Path data fungsi dasar
  const baseCurvePath = useMemo(() => {
    const points: string[] = [];
    const step = 0.1;
    for (let x = -8; x <= 8; x += step) {
      const y = evalBase(x);
      if (y >= -8 && y <= 8) {
        const sx = toSvgX(x);
        const sy = toSvgY(y);
        points.push(`${points.length === 0 ? 'M' : 'L'} ${sx.toFixed(1)} ${sy.toFixed(1)}`);
      }
    }
    return points.join(' ');
  }, [funcType]);

  // Path data fungsi transformasi
  const transformedCurvePath = useMemo(() => {
    const points: string[] = [];
    const step = 0.1;
    for (let x = -8; x <= 8; x += step) {
      const y = evalTransformed(x);
      if (y >= -8 && y <= 8) {
        const sx = toSvgX(x);
        const sy = toSvgY(y);
        points.push(`${points.length === 0 ? 'M' : 'L'} ${sx.toFixed(1)} ${sy.toFixed(1)}`);
      }
    }
    return points.join(' ');
  }, [funcType, a, b, k, reflectY]);

  const handleReset = () => {
    setA(0);
    setB(0);
    setK(1);
    setReflectY(false);
  };

  const handleSaveToTable = () => {
    let catatan = `Translasi horisontal ${a >= 0 ? 'kanan' : 'kiri'} ${Math.abs(a)}, vertikal ${b >= 0 ? 'atas' : 'bawah'} ${Math.abs(b)}`;
    if (k < 0) catatan += ', refleksi sumbu X';
    if (reflectY) catatan += ', refleksi sumbu Y';

    onRecordData({
      param1: equationText,
      param2: `a=${a}, b=${b}, k=${k}`,
      param3: `Titik Acuan (${vertex.x}, ${vertex.y})`,
      catatan,
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-6">
      {/* Header Simulasi */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 text-[10px] font-black uppercase">
            Matematika: Aljabar & Analisis Grafik
          </span>
          <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>Simulasi Transformasi Fungsi</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Eksplorasi pengaruh translasi horizontal (<code className="font-mono text-indigo-600 font-bold">a</code>),
            translasi vertikal (<code className="font-mono text-purple-600 font-bold">b</code>),
            dilatasi skala (<code className="font-mono text-amber-600 font-bold">k</code>), dan refleksi pada kurva fungsi.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSaveToTable}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Catat ke Tabel</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Kanvas Grafik Koordinat Kartesius */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-4 border border-slate-800 flex flex-col items-center justify-center relative overflow-hidden shadow-xl min-h-[390px]">
          {/* Rumus Aktif Floating */}
          <div className="absolute top-3 left-3 bg-slate-900/90 border border-slate-700/80 px-3 py-1.5 rounded-xl text-left z-20 shadow-md">
            <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-mono">
              Fungsi Transformasi
            </span>
            <span className="text-sm font-mono font-black text-amber-300">
              {equationText}
            </span>
          </div>

          {/* Legenda Kurva */}
          <div className="absolute top-3 right-3 bg-slate-900/90 border border-slate-700/80 px-2.5 py-1.5 rounded-xl flex items-center gap-3 text-[10px] font-mono z-20 shadow-md">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 border-t-2 border-dashed border-slate-400" />
              <span className="text-slate-400">f(x) Awal</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-1 bg-amber-400 rounded-full" />
              <span className="text-amber-300 font-bold">g(x) Hasil</span>
            </div>
          </div>

          {/* SVG Grafik Kartesius */}
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto max-h-[350px]">
            {/* Grid Garis */}
            {[-6, -4, -2, 2, 4, 6].map((gridVal) => (
              <g key={`grid-${gridVal}`}>
                <line
                  x1={toSvgX(gridVal)}
                  y1={0}
                  x2={toSvgX(gridVal)}
                  y2={height}
                  stroke="#1e293b"
                  strokeWidth="1"
                />
                <line
                  x1={0}
                  y1={toSvgY(gridVal)}
                  x2={width}
                  y2={toSvgY(gridVal)}
                  stroke="#1e293b"
                  strokeWidth="1"
                />
                <text
                  x={toSvgX(gridVal)}
                  y={originY + 12}
                  fill="#64748b"
                  fontSize="8"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  {gridVal}
                </text>
                <text
                  x={originX - 6}
                  y={toSvgY(gridVal) + 3}
                  fill="#64748b"
                  fontSize="8"
                  textAnchor="end"
                  fontFamily="monospace"
                >
                  {gridVal}
                </text>
              </g>
            ))}

            {/* Sumbu X dan Y Utama */}
            <line
              x1={0}
              y1={originY}
              x2={width}
              y2={originY}
              stroke="#475569"
              strokeWidth="1.5"
            />
            <line
              x1={originX}
              y1={0}
              x2={originX}
              y2={height}
              stroke="#475569"
              strokeWidth="1.5"
            />
            <text x={width - 12} y={originY - 6} fill="#94a3b8" fontSize="10" fontWeight="bold">
              X
            </text>
            <text x={originX + 8} y={14} fill="#94a3b8" fontSize="10" fontWeight="bold">
              Y
            </text>

            {/* Kurva Awal (Dashed) */}
            {showOriginal && (
              <path
                d={baseCurvePath}
                fill="none"
                stroke="#64748b"
                strokeWidth="1.5"
                strokeDasharray="4 3"
                opacity="0.8"
              />
            )}

            {/* Kurva Transformasi (Solid Bersinar) */}
            <path
              d={transformedCurvePath}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2.5"
              strokeLinecap="round"
              className="transition-all duration-150"
            />

            {/* Titik Acuan (Vertex) */}
            {toSvgX(vertex.x) >= 0 &&
              toSvgX(vertex.x) <= width &&
              toSvgY(vertex.y) >= 0 &&
              toSvgY(vertex.y) <= height && (
                <g>
                  <circle
                    cx={toSvgX(vertex.x)}
                    cy={toSvgY(vertex.y)}
                    r="4"
                    fill="#38bdf8"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                  <text
                    x={toSvgX(vertex.x) + 6}
                    y={toSvgY(vertex.y) - 6}
                    fill="#38bdf8"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    ({vertex.x}, {vertex.y})
                  </text>
                </g>
              )}
          </svg>
        </div>

        {/* Panel Kontrol & Slider Transformasi */}
        <div className="lg:col-span-5 space-y-4">
          {/* Pilihan Jenis Fungsi Dasar */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              1. Pilih Bentuk Fungsi Dasar
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'kuadrat' as FunctionType, label: 'Kuadrat x²' },
                { id: 'linear' as FunctionType, label: 'Linear x' },
                { id: 'mutlak' as FunctionType, label: 'Mutlak |x|' },
                { id: 'kubik' as FunctionType, label: 'Kubik x³' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFuncType(f.id)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    funcType === f.id
                      ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-blue-300'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Slider Parameter Transformasi */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-500">
                2. Parameter Transformasi
              </label>
              <button
                type="button"
                onClick={handleReset}
                className="text-[10px] font-bold text-slate-500 hover:text-blue-600 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset (0, 0, 1)</span>
              </button>
            </div>

            {/* Slider a (Translasi Horizontal) */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-600 dark:text-slate-400">
                  Translasi Horisontal (a):
                </span>
                <span className="text-indigo-600 font-mono font-black">
                  {a > 0 ? `+${a} (Kanan)` : a < 0 ? `${a} (Kiri)` : '0 (Netral)'}
                </span>
              </div>
              <input
                type="range"
                min="-5"
                max="5"
                step="1"
                value={a}
                onChange={(e) => setA(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>

            {/* Slider b (Translasi Vertikal) */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-600 dark:text-slate-400">
                  Translasi Vertikal (b):
                </span>
                <span className="text-purple-600 font-mono font-black">
                  {b > 0 ? `+${b} (Atas)` : b < 0 ? `${b} (Bawah)` : '0 (Netral)'}
                </span>
              </div>
              <input
                type="range"
                min="-5"
                max="5"
                step="1"
                value={b}
                onChange={(e) => setB(Number(e.target.value))}
                className="w-full accent-purple-600 cursor-pointer"
              />
            </div>

            {/* Slider k (Dilatasi & Refleksi X) */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-600 dark:text-slate-400">
                  Dilatasi & Refleksi X (k):
                </span>
                <span className="text-amber-600 font-mono font-black">
                  {k}x {k < 0 ? '(Terbalik)' : ''}
                </span>
              </div>
              <input
                type="range"
                min="-3"
                max="3"
                step="0.5"
                value={k}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setK(val === 0 ? 0.5 : val);
                }}
                className="w-full accent-amber-600 cursor-pointer"
              />
            </div>

            {/* Tombol Toggle Refleksi Sumbu Y & Tampilkan Kurva Awal */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setReflectY(!reflectY)}
                className={`flex-1 py-1.5 px-2.5 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                  reflectY
                    ? 'bg-rose-500/20 text-rose-700 border-rose-400 font-black'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-600'
                }`}
              >
                Refleksi Sumbu Y: {reflectY ? 'ON' : 'OFF'}
              </button>

              <button
                type="button"
                onClick={() => setShowOriginal(!showOriginal)}
                className={`flex-1 py-1.5 px-2.5 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                  showOriginal
                    ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 border-slate-400'
                    : 'bg-white dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700'
                }`}
              >
                Kurva Awal: {showOriginal ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
