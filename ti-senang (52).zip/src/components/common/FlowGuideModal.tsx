import React from 'react';
import { Modal } from './Modal';
import {
  Database,
  Cloud,
  FolderOpen,
  ArrowRight,
  CheckCircle2,
  BookOpen,
  Share2,
  Sparkles,
  Users,
  Award,
  Link,
  UploadCloud,
  FileQuestion,
  GraduationCap,
} from 'lucide-react';
import { TI_SENANG_FIREBASE_CONFIG } from '../../services/firebaseSync';

interface FlowGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlowGuideModal: React.FC<FlowGuideModalProps> = ({ isOpen, onClose }) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Panduan Lengkap Alur Pembelajaran & Integrasi TI SENANG"
      subtitle="Panduan langkah demi langkah menghubungkan Firebase, Google Drive, Guru, Murid, dan Portofolio Beranda"
      maxWidth="xl"
    >
      <div className="space-y-5 text-slate-700 text-xs sm:text-sm max-h-[75vh] overflow-y-auto pr-2">
        {/* Banner Konfigurasi Firebase yang sudah Terhubung */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-indigo-500/10 to-blue-500/10 border border-amber-400/40 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-display font-black text-amber-900 text-sm flex items-center gap-2">
              <Cloud className="w-5 h-5 text-amber-600" />
              Status Firebase Realtime Database: AKTIF & TERINISIALISASI
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono text-[11px] font-bold border border-emerald-300">
              Online
            </span>
          </div>
          <p className="text-slate-600 text-xs leading-relaxed">
            Aplikasi TI SENANG telah berhasil dihubungkan dengan Firebase Realtime Database menggunakan kredensial:
          </p>
          <div className="p-2.5 rounded-xl bg-white border border-slate-200 font-mono text-[11px] space-y-1">
            <div><strong>Database URL:</strong> <code>{TI_SENANG_FIREBASE_CONFIG.databaseURL}</code></div>
            <div><strong>API Key:</strong> <code>{TI_SENANG_FIREBASE_CONFIG.apiKey}</code></div>
            <div><strong>Region:</strong> <code>asia-southeast1 (Jakarta/Singapura)</code></div>
          </div>
        </div>

        {/* ALUR UTAMA (4 LANGKAH LENGKAP) */}
        <div className="space-y-3">
          <h3 className="font-display font-bold text-slate-900 text-base flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-600" />
            Alur Lengkap Pembelajaran Berbasis Misi TI SENANG
          </h3>

          {/* STEP 1: GURU MENGINPUT MISI */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 text-indigo-700 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-mono text-xs flex items-center justify-center">1</span>
              <span>Langkah 1: Guru Menginput Misi (Dashboard Guru ➔ Kelola Misi)</span>
            </div>
            <p className="text-xs text-slate-600">
              Guru membuka menu <strong>Kelola Misi</strong>, lalu klik tombol <strong>"Buat Misi Baru"</strong> atau Edit Misi:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">🎯 Misi 1 — Pahami Konsep:</span>
                <p className="text-[11px] text-slate-600">Guru menempelkan tautan materi berupa PDF Google Drive, video YouTube, atau link web edukasi.</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">💡 Misi 2 — Selesaikan Masalah Nyata:</span>
                <p className="text-[11px] text-slate-600">Guru mengetikkan narasi masalah kontekstual dan dapat menambahkan foto bukti / data pendukung.</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">🔬 Misi 3 — Eksperimen & Simulasi Virtual:</span>
                <p className="text-[11px] text-slate-600">Instruksi praktikum Kit TI SENANG (5 Port Sensor IoT real-time dari Firebase) atau tautan Simulasi Virtual interaktif.</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">🎮 Misi 4 — Game Edukasi:</span>
                <p className="text-[11px] text-slate-600">Guru memasukkan tautan link game sains interaktif (PhET simulation, quizizz, dll).</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">🧠 Misi 5 — Latihan & Refleksi:</span>
                <p className="text-[11px] text-slate-600">Guru menggunakan <strong>Pembuat Soal</strong> untuk menyusun butir soal PG, PG Kompleks (PGK), Isian, dan butir refleksi metakognitif.</p>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="font-bold text-slate-800">🏆 Misi 6 — Asesmen Akhir:</span>
                <p className="text-[11px] text-slate-600">Guru menyusun 6 kategori soal komprehensif: Pilihan Ganda, Benar/Salah, MCMA, Isian, Menjodohkan, dan Mengurutkan.</p>
              </div>
            </div>
            <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Pilih status <strong>"Published"</strong> dan kelas target (misal Kelas XII-1) agar langsung tersinkronisasi.</span>
            </div>
          </div>

          {/* STEP 2: MISI MASUK KE MURID & SISIPAN ALME */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 text-indigo-700 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-mono text-xs flex items-center justify-center">2</span>
              <span>Langkah 2: Misi Masuk ke Akun Murid & Misi Sisipan ALME Otomatis</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Ketika murid login (misal murid Kelas XII-1), aplikasi secara otomatis memuat seluruh misi yang dirilis oleh guru pada peta petualangan misi.
            </p>
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 space-y-1">
              <div className="font-bold text-amber-900 text-xs flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>✨ Kepastian Misi Sisipan ALME:</span>
              </div>
              <p className="text-[11px] text-slate-700 leading-relaxed">
                Di bagian atas kotak misi murid, <strong>Sisipan Misi Adaptif ALME</strong> akan <strong>muncul secara otomatis</strong>. ALME membaca hasil asesmen diagnostik awal serta rekam jejak literasi & numerasi masing-masing murid, lalu menyisipkan tantangan adaptif yang dipersonalisasi. Murid cukup mengklik kartu sisipan tersebut untuk menyelesaikannya (+120 XP).
              </p>
            </div>
          </div>

          {/* STEP 3: MURID MENGERJAKAN & UPLOAD PORTOFOLIO */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 text-indigo-700 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-mono text-xs flex items-center justify-center">3</span>
              <span>Langkah 3: Murid Mengerjakan Misi & Mengunggah Portofolio</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Murid membuka misi yang tersedia, mempelajari materi / menjalankan simulasi sensor, menjawab soal interaktif, dan merefleksikan hasil belajarnya.
            </p>
            <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 space-y-1.5">
              <span className="font-bold text-blue-950 text-xs flex items-center gap-1.5">
                <UploadCloud className="w-4 h-4 text-blue-600" />
                Cara Mengunggah Foto Tugas / Laporan Praktikum:
              </span>
              <ol className="list-decimal list-inside text-[11px] text-slate-700 space-y-1 pl-1">
                <li>Klik tombol <strong>"Unggah Portofolio"</strong> (di Beranda Murid atau setelah menyelesaikan misi).</li>
                <li>Pilih file foto dari laptop/HP <strong>ATAU</strong> tempelkan tautan foto/dokumen dari <strong>Google Drive</strong>.</li>
                <li>Isi judul karya, refleksi konsep saintifik, dan kesimpulan pembelajaran.</li>
                <li>Klik <strong>"Publikasikan Portofolio"</strong>. Portofolio tersimpan ke Firebase dan database lokal.</li>
              </ol>
            </div>
          </div>

          {/* STEP 4: PORTOFOLIO MUNCUL DI BERANDA TEMAN-TEMAN & GURU */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2 text-indigo-700 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-mono text-xs flex items-center justify-center">4</span>
              <span>Langkah 4: Portofolio Muncul di Beranda Teman-Teman & Guru</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Setelah murid menekan tombol publikasi, portofolio langsung disinkronkan:
            </p>
            <ul className="list-disc list-inside text-xs text-slate-700 space-y-1 pl-1">
              <li><strong>Di Beranda Teman Sebayanya:</strong> Karya foto praktikum muncul di feed <em>"Galeri Portofolio & Karya Praktikum Kelas"</em>. Teman-teman dapat membaca laporan, melihat foto resolusi tinggi, serta memberikan apresiasi emoji (👏 Hebat, 💡 Keren, 🔥 Inspiratif).</li>
              <li><strong>Di Dashboard Guru:</strong> Portofolio murid langsung masuk ke tab <em>"Rekap Portofolio Murid"</em> pada Beranda Guru untuk ditinjau, dinilai, atau ditandai sebagai <em>Karya Unggulan (Featured)</em>.</li>
            </ul>
          </div>
        </div>

        {/* CARA MENGGUNAKAN LINK GOOGLE DRIVE UNTUK FOTO & MATERI */}
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
          <h4 className="font-bold text-emerald-950 text-sm flex items-center gap-2">
            <Link className="w-4 h-4 text-emerald-700" />
            <span>Petunjuk Mengambil Tautan Foto / Dokumen dari Google Drive:</span>
          </h4>
          <ol className="list-decimal list-inside text-xs text-slate-700 space-y-1.5 pl-1">
            <li>Buka <strong>Google Drive</strong> Anda, lalu klik kanan pada file foto atau PDF materi yang ingin dibagikan.</li>
            <li>Pilih <strong>Bagikan (Share)</strong> ➔ ubah Akses Umum menjadi <strong>"Siapa saja yang memiliki link" (Anyone with the link can view)</strong>.</li>
            <li>Klik <strong>Salin Link (Copy Link)</strong>.</li>
            <li>Tempelkan tautan tersebut ke kolom input URL di TI SENANG. Aplikasi akan secara otomatis mengonversinya menjadi preview gambar beresolusi tinggi atau embed PDF langsung!</li>
          </ol>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-colors"
          >
            Mengerti & Tutup Panduan
          </button>
        </div>
      </div>
    </Modal>
  );
};
