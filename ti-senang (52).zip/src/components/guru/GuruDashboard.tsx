import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Compass,
  BookOpen,
  Target,
  BarChart3,
  Award,
  Sparkles,
  ChevronRight,
  Filter,
  CheckCircle2,
  Clock,
  LogOut,
  UserCheck,
  FolderOpen,
  HelpCircle,
  GraduationCap,
  ClipboardCheck,
  Plus,
  Layers,
  TrendingUp,
  Mail,
  ShieldCheck,
} from 'lucide-react';
import { User, TeacherProfileData, ClassRoom, Subject, Mission, Student, PortfolioItem, TujuanPembelajaran } from '../../types';
import { storage } from '../../services/storage';
import { GuruBottomNav, GuruTabType } from './GuruBottomNav';
import { GuruBeranda } from './GuruBeranda';
import { GuruMisiManager } from './GuruMisiManager';
import { GuruTujuanPembelajaran } from './GuruTujuanPembelajaran';
import { GuruAsesmenAwal } from './GuruAsesmenAwal';
import { GuruAsesmenAkhir } from './GuruAsesmenAkhir';
import { GuruTugasReview } from './GuruTugasReview';
import { BagiKelompokModal } from './BagiKelompokModal';
import { DashboardGuideBanner } from '../common/DashboardGuideBanner';
import logoTiSenang from '../../assets/images/logo_ti_senang.png';

interface GuruDashboardProps {
  user: User;
  onLogout: () => void;
}

export const GuruDashboard: React.FC<GuruDashboardProps> = ({ user, onLogout }) => {
  const [activeBottomTab, setActiveBottomTab] = useState<GuruTabType>('navigasi');
  const [showBagiKelompokModal, setShowBagiKelompokModal] = useState<boolean>(false);
  const [hasStartedTeaching, setHasStartedTeaching] = useState<boolean>(false);
  const [showGuideModal, setShowGuideModal] = useState<boolean>(false);

  // Load teacher profile from storage
  const [profileData, setProfileData] = useState<TeacherProfileData | null>(() =>
    storage.getTeacherProfile(user.id),
  );

  const teacher = profileData?.teacher;
  const subjects = profileData?.subjects || [];
  const classes = profileData?.classes || [];

  // Real Tujuan Pembelajaran from storage
  const [tujuanPembelajaranList, setTujuanPembelajaranList] = useState<TujuanPembelajaran[]>(() =>
    storage.getTujuanPembelajaran(),
  );

  // Cascading Selection: Mata Pelajaran ↓ Kelas ↓ Semester
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(
    subjects?.[0]?.id || 'sbj-fisika',
  );
  const [selectedClassId, setSelectedClassId] = useState<string>(
    classes?.[0]?.id || 'cls-xii-1',
  );
  const [selectedSemester, setSelectedSemester] = useState<string>('Ganjil');

  // Sub-navigation view under "Navigasi Guru"
  const [navSubTab, setNavSubTab] = useState<
    'murid' | 'misi' | 'tugas' | 'tp' | 'asesmen' | 'asesmen_akhir'
  >('murid');

  // Data states
  const [classStudents, setClassStudents] = useState<Student[]>([]);
  const [classMissions, setClassMissions] = useState<Mission[]>([]);
  const [classPortfolios, setClassPortfolios] = useState<PortfolioItem[]>([]);

  const refreshData = () => {
    const updatedProfile = storage.getTeacherProfile(user.id);
    setProfileData(updatedProfile);

    // Otomatis ambil data murid berdasarkan classId yang dipilih
    const students = storage.getStudentsByClass(selectedClassId);
    setClassStudents(students);

    // Misi kelas disaring sesuai mata pelajaran dan kelas aktif
    const allMissions = storage.getAllMissions();
    const currentSubj = subjects.find((s) => s.id === selectedSubjectId);
    const missions = allMissions.filter(
      (m) =>
        m &&
        (m.classId === selectedClassId || !m.classId) &&
        (m.subjectId === selectedSubjectId ||
          (currentSubj?.name &&
            m.subjectName &&
            m.subjectName.toLowerCase() === currentSubj.name.toLowerCase())),
    );
    setClassMissions(missions);

    // Tujuan Pembelajaran disesuaikan dengan mata pelajaran terpilih
    setTujuanPembelajaranList(storage.getTujuanPembelajaran(selectedSubjectId));

    // Portofolio semua kelas binaan untuk Beranda
    const allPortfolios = storage.getAllPortfolios();
    const teacherClassIds = classes.map((c) => c.id);
    const relevantPortfolios = allPortfolios.filter(
      (p) => p && p.classId && teacherClassIds.includes(p.classId),
    );
    setClassPortfolios(relevantPortfolios);
  };

  useEffect(() => {
    refreshData();
  }, [selectedClassId, selectedSubjectId, selectedSemester, user.id]);

  useEffect(() => {
    if (activeBottomTab === 'profil') {
      setTujuanPembelajaranList(storage.getTujuanPembelajaran());
    }
  }, [activeBottomTab]);

  // Real-time listener for Firebase and Storage TP updates
  useEffect(() => {
    const handleTpUpdated = (e: any) => {
      const list = e.detail || storage.getTujuanPembelajaran();
      if (Array.isArray(list)) {
        setTujuanPembelajaranList(list);
      }
    };
    const handleDataUpdated = () => {
      refreshData();
    };

    window.addEventListener('tisenang_tp_updated', handleTpUpdated);
    window.addEventListener('tisenang_tasks_updated', handleDataUpdated);
    window.addEventListener('tisenang_portfolios_updated', handleDataUpdated);
    window.addEventListener('tisenang_students_updated', handleDataUpdated);

    return () => {
      window.removeEventListener('tisenang_tp_updated', handleTpUpdated);
      window.removeEventListener('tisenang_tasks_updated', handleDataUpdated);
      window.removeEventListener('tisenang_portfolios_updated', handleDataUpdated);
      window.removeEventListener('tisenang_students_updated', handleDataUpdated);
    };
  }, []);

  const [profilTpSubjectFilter, setProfilTpSubjectFilter] = useState<string>('all');

  const currentSubject = subjects.find((s) => s.id === selectedSubjectId) || subjects?.[0];
  const currentClass = classes.find((c) => c.id === selectedClassId) || classes?.[0];

  // Taught subjects determination
  const teacherSubjectIds = Array.from(
    new Set(
      profileData?.assignedTeacherClasses?.map((tc) => tc.subjectId) ||
        subjects.map((s) => s.id),
    ),
  );
  const teacherSubjects = subjects.filter((s) => teacherSubjectIds.includes(s.id));
  const subjectNames =
    teacherSubjects.length > 0
      ? teacherSubjects.map((s) => s.name).join(', ')
      : (subjects.map((s) => s.name).join(', ') || 'MIPA');

  // Active missions count
  const activeMissionsCount = classMissions.filter((m) => m.status === 'PUBLISHED').length;

  // Filter kelas asli yang diajar: hilangkan kelas dummy kosong tanpa siswa
  const taughtClasses = useMemo(() => {
    const assignedIds = profileData?.assignedTeacherClasses?.map((tc) => tc.classId) || [];
    const withStudents = classes.filter((c) => {
      const count = storage.getStudentsByClass(c.id).length;
      return count > 0 || assignedIds.includes(c.id);
    });
    return withStudents.length > 0 ? withStudents : (currentClass ? [currentClass] : classes.slice(0, 1));
  }, [classes, profileData, currentClass]);

  // Perhitungan Ketercapaian Tujuan Pembelajaran secara riil
  const calculateTpMetric = (tp: TujuanPembelajaran) => {
    const allStudents = storage.getStudents();
    const studentsInClass = currentClass 
      ? allStudents.filter((s) => s.classId === currentClass.id)
      : allStudents;
    const totalStudents = studentsInClass.length;

    // Ambil semua misi yang selaras dengan TP ini
    const allMissions = storage.getAllMissions();
    const matchedMissions = allMissions.filter(
      (m) =>
        m.tpId === tp.id ||
        m.tpCode === tp.code ||
        (m.subjectId === tp.subjectId && (!tp.classId || m.classId === tp.classId)),
    );
    const matchedMissionIds = matchedMissions.map((m) => m.id);

    // Ambil tugas siswa
    const allTasks = storage.getStudentTasks();
    const relevantTasks = allTasks.filter((t) => {
      const matchMission = matchedMissionIds.includes(t.missionId);
      const mission = allMissions.find((m) => m.id === t.missionId);
      const matchSubject = mission ? mission.subjectId === tp.subjectId : false;
      return matchMission || matchSubject;
    });

    // Ambil portofolio siswa
    const allPortfolios = storage.getAllPortfolios();
    const relevantPortfolios = allPortfolios.filter(
      (p) =>
        p.subjectId === tp.subjectId ||
        (p.reflectionSummary && p.reflectionSummary.includes(tp.code)),
    );

    // Ambil asesmen akhir
    const allAsesmen = storage.getAsesmenAkhir();
    const relevantAsesmen = allAsesmen.filter((a) => !tp.classId || a.classId === tp.classId);

    // Kumpulkan nilai-nilai tugas & asesmen murid yang sudah dinilai
    const scores: number[] = [];
    relevantTasks.forEach((t) => {
      if (typeof t.score === 'number' && t.score > 0) scores.push(t.score);
    });
    relevantAsesmen.forEach((a) => {
      if (typeof a.score === 'number' && a.score > 0) scores.push(a.score);
    });

    const activeStudentIds = new Set<string>();
    relevantTasks.forEach((t) => t.studentId && activeStudentIds.add(t.studentId));
    relevantPortfolios.forEach((p) => p.studentId && activeStudentIds.add(p.studentId));
    relevantAsesmen.forEach((a) => a.studentId && activeStudentIds.add(a.studentId));

    const submittedStudentsCount = activeStudentIds.size;
    const targetKktp = tp.targetScore || 75;

    let percentage = 0;
    let avgScore = 0;
    let tuntasCount = 0;

    if (scores.length > 0) {
      avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
      tuntasCount = scores.filter((s) => s >= targetKktp).length;
      percentage = Math.min(100, Math.round((tuntasCount / scores.length) * 100));
    } else if (totalStudents > 0 && submittedStudentsCount > 0) {
      // Jika murid sudah menyerahkan tugas/portofolio tapi belum diberi skor numerik
      percentage = Math.min(100, Math.round((submittedStudentsCount / totalStudents) * 100));
      tuntasCount = submittedStudentsCount;
    } else if (typeof tp.achievedPercentage === 'number' && tp.achievedPercentage > 0 && tp.achievedPercentage !== 80 && tp.achievedPercentage !== 85) {
      percentage = tp.achievedPercentage;
      tuntasCount = Math.round((percentage / 100) * totalStudents);
    }

    let statusText: 'Optimal' | 'Cukup' | 'Perlu Pendampingan' | 'Belum Berjalan' = 'Optimal';
    if (percentage >= 85) {
      statusText = 'Optimal';
    } else if (percentage >= 70) {
      statusText = 'Cukup';
    } else if (percentage > 0) {
      statusText = 'Perlu Pendampingan';
    } else {
      statusText = 'Belum Berjalan';
    }

    return {
      percentage,
      totalStudents,
      submittedStudentsCount,
      tuntasCount,
      avgScore,
      targetKktp,
      statusText,
    };
  };

  // Average completion calculated dynamically from real TP metrics
  const averageProgress = useMemo(() => {
    if (tujuanPembelajaranList.length === 0) return 0;
    const total = tujuanPembelajaranList.reduce((acc, tp) => {
      return acc + calculateTpMetric(tp).percentage;
    }, 0);
    return Math.round(total / tujuanPembelajaranList.length);
  }, [tujuanPembelajaranList, currentClass, classStudents]);

  return (
    <div className="relative w-full h-[100dvh] overflow-hidden">
      {/* Pop-up Petunjuk (Muncul saat pertama kali masuk atau saat diklik dari header) */}
      {(!hasStartedTeaching || showGuideModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 lg:p-6 bg-slate-950/35 backdrop-blur-[2px] overflow-hidden">
          <div className="w-full max-w-[96vw] sm:max-w-xl lg:max-w-4xl my-auto animate-beranda-enter drop-shadow-2xl">
            <DashboardGuideBanner
              role="guru"
              userName={user.fullName || user.name || 'Bapak/Ibu Guru'}
              onClose={() => {
                setHasStartedTeaching(true);
                setShowGuideModal(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Dashboard Guru (Terlihat samar-samar di belakang pop-up saat pop-up aktif) */}
      <div
        style={{
          height: '100dvh',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
        className={`bg-slate-50 text-slate-800 transition-all duration-300 ${
          (!hasStartedTeaching || showGuideModal)
            ? 'filter blur-[2px] opacity-85 select-none pointer-events-none'
            : ''
        }`}
      >
        {/* Top Application Bar */}
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between shadow-xs shrink-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white flex items-center justify-center font-display font-extrabold text-sm shadow-sm">
            TS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-extrabold text-sm tracking-tight text-slate-900">
                TI SENANG
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                Akun Guru
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Sistem Pembelajaran Adaptif & Menggembirakan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-bold text-slate-800">{user.name}</div>
            <div className="text-[11px] text-slate-400 font-medium">
              @{user.username}
            </div>
          </div>

          <button
            onClick={() => setShowGuideModal(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-2xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/80 text-xs font-bold transition-all cursor-pointer shadow-2xs hover:scale-102"
            title="Buka Petunjuk Langkah Mengajar Guru"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Petunjuk</span>
          </button>

          <button
            onClick={() => setActiveBottomTab('profil')}
            className="w-9 h-9 rounded-xl bg-indigo-100 text-indigo-700 hover:bg-indigo-200 flex items-center justify-center font-display font-bold text-xs transition-colors border border-indigo-200"
            title="Buka Profil Guru"
          >
            {(user.fullName || user.name || 'G')[0]}
          </button>
        </div>
      </header>

      {/* Main Scrollable Content Area */}
      <main
        style={{
          flex: 1,
          overflowY: 'auto',
          paddingBottom: '90px', // space for fixed bottom nav
        }}
        className="p-4 sm:p-6 lg:p-8"
      >
        {/* ====================================================== */}
        {/* TAB 1: BERANDA (Student Uploaded Portfolios) */}
        {/* ====================================================== */}
        {activeBottomTab === 'beranda' && (
          <GuruBeranda
            portfolios={classPortfolios}
            classes={classes}
            teacherName={user.fullName || user.name || 'Guru Pengampu'}
            onRefreshPortfolios={refreshData}
          />
        )}

        {/* ====================================================== */}
        {/* TAB 2: NAVIGASI GURU (TP, Misi, Asesmen, Murid) */}
        {/* ====================================================== */}
        {activeBottomTab === 'navigasi' && (
          <div className="relative max-w-5xl mx-auto space-y-6">
            {/* Ambient background glow layers */}
            <div className="absolute -top-12 -left-12 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
            <div className="absolute top-1/3 -right-12 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
            <div className="absolute bottom-16 left-1/4 w-80 h-80 bg-fuchsia-500/5 rounded-full blur-3xl pointer-events-none -z-10" />

            {/* Greeting & Header Stats Banner (Cosmic Futuristic Theme matching Beranda & Profil) */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#060c24] via-[#0d1c4f] to-[#201048] p-5 sm:p-7 text-white shadow-[0_18px_50px_rgba(2,6,23,0.38),0_0_35px_rgba(59,130,246,0.12)] border border-indigo-500/30">
              {/* Holographic light border accent on top edge */}
              <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent pointer-events-none" />

              {/* Delicate digital grid overlay */}
              <div className="absolute inset-0 bg-[radial-gradient(#38bdf814_1px,transparent_1px)] [background-size:22px_22px] pointer-events-none opacity-60" />

              {/* Dynamic ambient glowing orbs */}
              <div className="absolute -top-20 -left-16 w-72 h-72 rounded-full bg-cyan-500/16 blur-3xl pointer-events-none animate-pulse-subtle" />
              <div className="absolute -bottom-20 -right-16 w-80 h-80 rounded-full bg-fuchsia-600/16 blur-3xl pointer-events-none" />
              <div className="absolute top-1/2 left-1/3 w-56 h-56 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

              {/* Abstract flowing waves - Futuristic delicate vector curves */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30 animate-wave-float">
                <svg viewBox="0 0 1200 160" preserveAspectRatio="none" className="w-full h-full">
                  <defs>
                    <linearGradient id="guruNavWaveGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.05" />
                      <stop offset="40%" stopColor="#38bdf8" stopOpacity="0.3" />
                      <stop offset="70%" stopColor="#818cf8" stopOpacity="0.35" />
                      <stop offset="100%" stopColor="#c084fc" stopOpacity="0.05" />
                    </linearGradient>
                    <linearGradient id="guruNavWaveGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#818cf8" stopOpacity="0.05" />
                      <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#f472b6" stopOpacity="0.05" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 0 90 C 250 145, 550 35, 850 95 C 1020 130, 1120 60, 1200 85"
                    fill="none"
                    stroke="url(#guruNavWaveGrad1)"
                    strokeWidth="1.6"
                  />
                  <path
                    d="M 0 115 C 300 55, 600 155, 900 80 C 1040 45, 1140 120, 1200 100"
                    fill="none"
                    stroke="url(#guruNavWaveGrad2)"
                    strokeWidth="1.2"
                    strokeDasharray="4 6"
                  />
                </svg>
              </div>

              {/* Kelap-kelip Bintang (Twinkling Cosmic & Cyber Stars) */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
                <div className="absolute top-[16%] left-[10%] animate-twinkle-1 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-cyan-300/60 drop-shadow-[0_0_5px_rgba(56,189,248,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>
                <div className="absolute top-[22%] right-[14%] animate-twinkle-2 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-amber-300/60 drop-shadow-[0_0_6px_rgba(252,211,77,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>
                <div className="absolute top-[68%] left-[24%] animate-twinkle-3 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-300/60 shadow-[0_0_6px_rgba(56,189,248,0.8)]" />
                </div>
                <div className="absolute top-[62%] right-[22%] animate-twinkle-5 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-300/60 shadow-[0_0_7px_rgba(240,171,252,0.8)]" />
                </div>
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
                <div className="space-y-1 max-w-xl">
                  <h1 className="text-xl sm:text-2xl font-display font-black tracking-tight text-white drop-shadow-sm leading-tight">
                    Halo,{' '}
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-200">
                      {user.name}
                    </span>{' '}
                    👋
                  </h1>
                  <p className="text-xs text-slate-300 font-normal">
                    Kelola kelas, misi belajar, dan asesmen perkembangan murid.
                  </p>
                </div>

                {/* Cascading Selector: Mata Pelajaran ↓ Kelas */}
                <div className="bg-slate-900/75 backdrop-blur-md p-3 sm:p-4 rounded-2xl border border-cyan-400/30 shadow-inner space-y-2 min-w-[260px] shrink-0">
                  <div className="text-[10px] font-mono font-bold text-cyan-300 uppercase tracking-wider">
                    Konteks Mengajar:
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {/* Mata Pelajaran Dropdown */}
                    <div>
                      <select
                        value={selectedSubjectId}
                        onChange={(e) => setSelectedSubjectId(e.target.value)}
                        className="w-full h-9 px-2.5 rounded-xl bg-white text-slate-800 text-xs font-bold shadow-xs cursor-pointer border border-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/40"
                      >
                        {subjects.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Kelas Dropdown */}
                    <div>
                      <select
                        value={selectedClassId}
                        onChange={(e) => setSelectedClassId(e.target.value)}
                        className="w-full h-9 px-2.5 rounded-xl bg-white text-slate-800 text-xs font-bold shadow-xs cursor-pointer border border-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/40"
                      >
                        {classes.map((c) => (
                          <option key={c.id} value={c.id}>
                            Kelas {c.className}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Semester Dropdown */}
                    <div>
                      <select
                        value={selectedSemester}
                        onChange={(e) => setSelectedSemester(e.target.value)}
                        className="w-full h-9 px-2.5 rounded-xl bg-white text-slate-800 text-xs font-bold shadow-xs cursor-pointer border border-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400/40"
                      >
                        <option value="Ganjil">Sem 1 (Ganjil)</option>
                        <option value="Genap">Sem 2 (Genap)</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3 Metric Summary Cards (Non-redundant, clean) */}
              <div className="mt-4 pt-3 border-t border-white/15 grid grid-cols-3 gap-2 sm:gap-3 text-white relative z-10">
                <div className="bg-white/10 backdrop-blur-md border border-white/15 p-2.5 sm:p-3 rounded-2xl shadow-inner text-center">
                  <div className="text-[10px] text-blue-200/90 font-medium">Murid</div>
                  <div className="text-sm sm:text-base font-display font-bold font-mono text-white mt-0.5">{classStudents.length} Murid</div>
                </div>

                <div className="bg-white/10 backdrop-blur-md border border-white/15 p-2.5 sm:p-3 rounded-2xl shadow-inner text-center">
                  <div className="text-[10px] text-blue-200/90 font-medium">Misi Rilis</div>
                  <div className="text-sm sm:text-base font-display font-bold font-mono text-white mt-0.5">{activeMissionsCount} Misi</div>
                </div>

                <div className="bg-white/10 backdrop-blur-md border border-white/15 p-2.5 sm:p-3 rounded-2xl shadow-inner text-center">
                  <div className="text-[10px] text-emerald-300 font-medium">Capaian</div>
                  <div className="text-sm sm:text-base font-display font-bold font-mono text-emerald-300 mt-0.5">{averageProgress}% Tuntas</div>
                </div>
              </div>
            </div>

            {/* Sub-Navigation Tabs: Mudah di handphone & ringkas */}
            <div className="flex items-center gap-1.5 p-1.5 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-x-auto scrollbar-none">
              <button
                type="button"
                id="btn-subnav-murid"
                onClick={() => setNavSubTab('murid')}
                className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'murid'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Murid</span>
              </button>

              <button
                type="button"
                id="btn-subnav-tp"
                onClick={() => setNavSubTab('tp')}
                className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'tp'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>Tujuan (TP)</span>
              </button>

              <button
                type="button"
                id="btn-subnav-asesmen"
                onClick={() => setNavSubTab('asesmen')}
                className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'asesmen'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>Asesmen Awal</span>
              </button>

              <button
                type="button"
                id="btn-subnav-misi"
                onClick={() => setNavSubTab('misi')}
                className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'misi'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Target className="w-4 h-4" />
                <span>Kelola Misi</span>
              </button>

              <button
                type="button"
                id="btn-subnav-tugas"
                onClick={() => setNavSubTab('tugas')}
                className={`flex-1 min-w-[95px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'tugas'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <ClipboardCheck className="w-4 h-4" />
                <span>Tugas</span>
              </button>

              <button
                type="button"
                id="btn-subnav-asesmen-akhir"
                onClick={() => setNavSubTab('asesmen_akhir')}
                className={`flex-1 min-w-[100px] py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 min-h-[42px] cursor-pointer ${
                  navSubTab === 'asesmen_akhir'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-800 bg-amber-50 hover:bg-amber-100/70 border border-amber-200/60'
                }`}
              >
                <Award className="w-4 h-4" />
                <span>Nilai Akhir</span>
              </button>
            </div>

            {/* SUB-VIEW 1: DAFTAR MURID OTOMATIS */}
            {navSubTab === 'murid' && (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-display font-bold text-slate-800 text-base flex items-center gap-2">
                      <UserCheck className="w-5 h-5 text-indigo-600" />
                      Daftar Murid Kelas {currentClass?.className}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Daftar murid tersinkronisasi otomatis dari database kelas <code>{selectedClassId}</code>. Anda dapat memetakan murid ke dalam Kelompok 1-5 untuk sinkronisasi otomatis ke dashboard & sensor murid.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                    <button
                      type="button"
                      id="btn-guru-bagi-kelompok"
                      onClick={() => setShowBagiKelompokModal(true)}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm shadow-indigo-200 transition-all cursor-pointer active:scale-95"
                    >
                      <Users className="w-4 h-4" />
                      <span>Bagi Kelompok</span>
                    </button>

                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
                      {classStudents.length} Murid Terdaftar
                    </span>
                  </div>
                </div>

                {classStudents.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-400">
                    Belum ada data murid terdaftar di kelas {currentClass?.className}.
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-2xl border border-slate-200">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="py-3 px-4">Murid</th>
                          <th className="py-3 px-4 text-center">Kelompok</th>
                          <th className="py-3 px-4">Misi Terakhir</th>
                          <th className="py-3 px-4 text-center">XP</th>
                          <th className="py-3 px-4 text-center">Status</th>
                          <th className="py-3 px-4 text-center">Aksi Asesmen</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {classStudents.map((std, idx) => (
                          <tr key={std.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center font-display font-bold text-xs">
                                  {(std.name || std.user?.fullName || 'M')[0]}
                                </div>
                                <div>
                                  <div className="font-bold text-slate-800">{std.name || std.user?.fullName || 'Murid'}</div>
                                  <div className="text-[10px] text-slate-400">{std.email || std.user?.username || '-'}</div>
                                </div>
                              </div>
                            </td>
                            <td className="py-3 px-4 text-center">
                              {std.kelompok ? (
                                <span
                                  className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border ${
                                    std.kelompok === 'Kelompok 1'
                                      ? 'bg-blue-50 text-blue-700 border-blue-200'
                                      : std.kelompok === 'Kelompok 2'
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                      : std.kelompok === 'Kelompok 3'
                                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                                      : std.kelompok === 'Kelompok 4'
                                      ? 'bg-purple-50 text-purple-700 border-purple-200'
                                      : 'bg-rose-50 text-rose-700 border-rose-200'
                                  }`}
                                >
                                  <Users className="w-3 h-3" />
                                  {std.kelompok}
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setShowBagiKelompokModal(true)}
                                  className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold italic hover:underline cursor-pointer"
                                >
                                  + Bagi Kelompok
                                </button>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-semibold text-slate-700">
                                Misi {idx % 2 === 0 ? '2: Eksplorasi Lab' : '1: Regresi Linear'}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-center font-mono font-bold text-purple-700">
                              {450 + idx * 80} XP
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3" />
                                Aktif
                              </span>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <button
                                type="button"
                                onClick={() => setNavSubTab('asesmen')}
                                className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] border border-indigo-200 transition-colors inline-flex items-center gap-1"
                              >
                                <Sparkles className="w-3 h-3 text-indigo-600" />
                                <span>Input Asesmen</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* SUB-VIEW 2: TUJUAN PEMBELAJARAN (TP) */}
            {navSubTab === 'tp' && (
              <GuruTujuanPembelajaran
                selectedSubjectId={selectedSubjectId}
                selectedClassId={selectedClassId}
                selectedSemester={selectedSemester}
                subjects={subjects}
                classes={classes}
                missions={classMissions}
                onRefresh={refreshData}
                onNavigateToMisi={() => setNavSubTab('misi')}
              />
            )}

            {/* SUB-VIEW 3: ASESMEN AWAL & REKOMENDASI ALME */}
            {navSubTab === 'asesmen' && (
              <GuruAsesmenAwal
                selectedClassId={selectedClassId}
                selectedSubjectId={selectedSubjectId}
                classes={classes}
                subjects={subjects}
                students={classStudents}
                teacherName={user.name || user.fullName || 'Guru'}
                onRefresh={refreshData}
              />
            )}

            {/* SUB-VIEW 4: KELOLA MISI */}
            {navSubTab === 'misi' && (
              <GuruMisiManager
                missions={classMissions}
                classes={classes}
                subjects={subjects}
                selectedClassId={selectedClassId}
                selectedSubjectId={selectedSubjectId}
                selectedSemester={selectedSemester}
                onRefresh={refreshData}
              />
            )}

            {/* SUB-VIEW 5: TUGAS MURID */}
            {navSubTab === 'tugas' && (
              <GuruTugasReview
                classId={selectedClassId}
                className={currentClass?.className || 'XII-1'}
                missions={classMissions}
                students={classStudents}
              />
            )}

            {/* SUB-VIEW 6: ASESMEN AKHIR */}
            {navSubTab === 'asesmen_akhir' && (
              <GuruAsesmenAkhir
                selectedClassId={selectedClassId}
                selectedSubjectId={selectedSubjectId}
                classes={classes}
                subjects={subjects}
                students={classStudents}
                teacherName={user.name || user.fullName || 'Guru'}
                onRefresh={refreshData}
              />
            )}
          </div>
        )}

        {/* ====================================================== */}
        {/* TAB 3: PROFIL GURU (Info, Mapel, Kelas, TP Progress) */}
        {/* ====================================================== */}
        {activeBottomTab === 'profil' && (
          <div className="relative max-w-4xl mx-auto space-y-6">
            {/* Ambient background glow layers */}
            <div className="absolute -top-12 -left-12 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
            <div className="absolute top-1/3 -right-12 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none -z-10" />
            <div className="absolute bottom-16 left-1/4 w-80 h-80 bg-fuchsia-500/5 rounded-full blur-3xl pointer-events-none -z-10" />

            {/* Profile Card (Matching Student Profile Header Visuals) */}
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-[#060a19] via-[#0c163b] to-[#190e3f] border border-indigo-500/30 text-white p-6 sm:p-8 shadow-[0_20px_50px_rgba(2,6,23,0.45),0_0_40px_rgba(59,130,246,0.18)]">
              {/* Futuristic digital grid texture */}
              <div className="absolute inset-0 bg-[radial-gradient(#38bdf815_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-50" />

              {/* Dynamic ambient glowing orbs */}
              <div className="absolute -top-24 -left-20 w-80 h-80 rounded-full bg-cyan-500/12 blur-3xl pointer-events-none animate-pulse-subtle" />
              <div className="absolute -bottom-28 -right-20 w-96 h-96 rounded-full bg-fuchsia-600/12 blur-3xl pointer-events-none" />
              <div className="absolute top-1/3 left-1/2 w-64 h-64 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none" />

              {/* Kelap-kelip Bintang (Twinkling Cosmic & Cyber Stars) */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
                {/* Star 1 - Top Left */}
                <div className="absolute top-[14%] left-[12%] animate-twinkle-1 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-cyan-300/60 drop-shadow-[0_0_5px_rgba(56,189,248,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 2 - Top Right */}
                <div className="absolute top-[20%] right-[16%] animate-twinkle-2 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 text-amber-300/60 drop-shadow-[0_0_6px_rgba(252,211,77,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 3 - Center Top */}
                <div className="absolute top-[12%] left-[48%] animate-twinkle-3 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-white/70 shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                </div>

                {/* Star 4 - Mid Left */}
                <div className="absolute top-[42%] left-[6%] animate-twinkle-4 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-300/60 shadow-[0_0_6px_rgba(56,189,248,0.8)]" />
                </div>

                {/* Star 5 - Mid Right */}
                <div className="absolute top-[40%] right-[8%] animate-twinkle-5 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3 h-3 text-indigo-300/60 drop-shadow-[0_0_5px_rgba(165,180,252,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 6 - Bottom Center */}
                <div className="absolute top-[75%] left-[55%] animate-twinkle-2 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-fuchsia-300/60 shadow-[0_0_7px_rgba(240,171,252,0.8)]" />
                </div>

                {/* Star 7 - Bottom Right */}
                <div className="absolute top-[78%] right-[22%] animate-twinkle-1 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3 h-3 text-cyan-200/50 drop-shadow-[0_0_4px_rgba(165,243,252,0.6)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 8 - Top Mid-Left */}
                <div className="absolute top-[18%] left-[28%] animate-twinkle-6 pointer-events-none">
                  <div className="w-1 h-1 rounded-full bg-amber-200/60 shadow-[0_0_5px_rgba(253,230,138,0.7)]" />
                </div>

                {/* Star 9 - Top Mid-Right */}
                <div className="absolute top-[28%] right-[32%] animate-twinkle-3 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-2.5 h-2.5 text-cyan-200/55 drop-shadow-[0_0_4px_rgba(165,243,252,0.6)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 10 - Bottom Left */}
                <div className="absolute top-[82%] left-[18%] animate-twinkle-5 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-300/60 shadow-[0_0_6px_rgba(165,180,252,0.7)]" />
                </div>

                {/* Star 11 - Lower Mid-Left */}
                <div className="absolute top-[68%] left-[38%] animate-twinkle-4 pointer-events-none">
                  <div className="w-1 h-1 rounded-full bg-white/60 shadow-[0_0_5px_rgba(255,255,255,0.7)]" />
                </div>

                {/* Star 12 - Far Top Right */}
                <div className="absolute top-[16%] right-[5%] animate-twinkle-1 pointer-events-none">
                  <svg viewBox="0 0 24 24" className="w-3 h-3 text-fuchsia-300/55 drop-shadow-[0_0_5px_rgba(240,171,252,0.7)]">
                    <path fill="currentColor" d="M12 0L14 9.5L24 12L14 14.5L12 24L10 14.5L0 12L10 9.5L12 0Z" />
                  </svg>
                </div>

                {/* Star 13 - Mid Lower Right */}
                <div className="absolute top-[62%] right-[14%] animate-twinkle-6 pointer-events-none">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-300/60 shadow-[0_0_6px_rgba(103,232,249,0.7)]" />
                </div>

                {/* Star 14 - Bottom Center-Right */}
                <div className="absolute top-[85%] right-[44%] animate-twinkle-2 pointer-events-none">
                  <div className="w-1 h-1 rounded-full bg-violet-300/60 shadow-[0_0_5px_rgba(196,181,253,0.7)]" />
                </div>
              </div>

              <div className="relative z-10">
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                  {/* Avatar dengan Ring Gradient Biru-Ungu-Magenta & Soft Glow */}
                  <div className="relative group shrink-0">
                    <div className="relative p-[3px] rounded-[28px] bg-gradient-to-tr from-cyan-400 via-indigo-500 to-fuchsia-500 shadow-[0_0_28px_rgba(56,189,248,0.35)] transition-all duration-300 group-hover:scale-105 group-hover:shadow-[0_0_38px_rgba(168,85,247,0.5)]">
                      <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-[25px] bg-slate-950 overflow-hidden flex items-center justify-center relative">
                        {user.avatarUrl ? (
                          <img
                            src={user.avatarUrl}
                            alt={user.fullName || user.username}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <span className="font-display font-black text-3xl sm:text-4xl text-transparent bg-clip-text bg-gradient-to-br from-white via-cyan-100 to-indigo-200">
                            {(user.fullName || user.name || user.username).charAt(0).toUpperCase()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Identitas di Bagian Tengah */}
                  <div className="flex-1 text-center sm:text-left min-w-0">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-black text-white tracking-tight">
                            {user.fullName || user.name || 'Guru Pengampu'}
                          </h1>
                          <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 text-[11px] font-bold flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3 text-cyan-400" />
                            Pendidik TI SENANG
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-3 gap-y-1 text-xs text-slate-300 font-mono">
                          <span>@{user.username}</span>
                          {user.email && (
                            <span className="flex items-center gap-1 text-slate-400">
                              <Mail className="w-3 h-3 text-indigo-400" />
                              {user.email}
                            </span>
                          )}
                          {(teacher?.nip || user.nip) && (
                            <span className="text-slate-400">
                              NIP: {teacher?.nip || user.nip}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Tombol Keluar Akun */}
                      <button
                        type="button"
                        onClick={onLogout}
                        className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-300 hover:text-rose-300 border border-white/10 hover:border-rose-500/30 text-xs font-bold transition-all flex items-center justify-center gap-2 self-center sm:self-start cursor-pointer backdrop-blur-md shrink-0 active:scale-95"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Keluar Akun</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 4 Ringkasan Statistik Riil Guru (Tanpa Data Dummy) */}
                <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-white">
                  <div className="bg-white/5 backdrop-blur-md border border-white/10 p-3 rounded-2xl">
                    <div className="text-[10px] text-indigo-200 font-semibold uppercase tracking-wider">Tujuan Pembelajaran</div>
                    <div className="text-sm sm:text-base font-display font-black font-mono text-white mt-0.5">
                      {tujuanPembelajaranList.length} TP
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Ditambahkan Guru</div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md border border-white/10 p-3 rounded-2xl">
                    <div className="text-[10px] text-cyan-200 font-semibold uppercase tracking-wider">Kelas Binaan</div>
                    <div className="text-sm sm:text-base font-display font-black font-mono text-cyan-300 mt-0.5">
                      {taughtClasses.length} Kelas
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {taughtClasses.map((c) => c.className).join(', ') || 'Aktif'}
                    </div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md border border-white/10 p-3 rounded-2xl">
                    <div className="text-[10px] text-purple-200 font-semibold uppercase tracking-wider">Murid Aktif</div>
                    <div className="text-sm sm:text-base font-display font-black font-mono text-white mt-0.5">
                      {classStudents.length} Murid
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Kelas {currentClass?.className}</div>
                  </div>

                  <div className="bg-white/5 backdrop-blur-md border border-white/10 p-3 rounded-2xl">
                    <div className="text-[10px] text-emerald-300 font-semibold uppercase tracking-wider">Rata-rata Ketercapaian</div>
                    <div className="text-sm sm:text-base font-display font-black font-mono text-emerald-300 mt-0.5">
                      {averageProgress}%
                    </div>
                    <div className="text-[10px] text-emerald-400/80 mt-0.5">Sesuai TP & Tugas Murid</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Daftar Kelas yang Diajar (Hanya Kelas Riil Tanpa Kelas Dummy) */}
            <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-3">
              <h3 className="font-display font-bold text-xs sm:text-sm text-slate-800 uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-indigo-600" />
                Daftar Kelas yang Diajar
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {taughtClasses.map((c) => {
                  const studentCount = storage.getStudentsByClass(c.id).length;
                  return (
                    <div
                      key={c.id}
                      className="p-4 bg-slate-50 hover:bg-indigo-50/40 rounded-2xl border border-slate-200 text-xs flex justify-between items-center transition-colors"
                    >
                      <div>
                        <div className="font-bold text-slate-800 text-sm">Kelas {c.className}</div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          Tahun Ajaran {c.academicYear || '2025/2026'}
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[11px] font-mono">
                        {studentCount} Murid
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Progress Ketercapaian Tujuan Pembelajaran Sesuai TP Guru */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-display font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-indigo-600" />
                    Progress Ketercapaian Tujuan Pembelajaran
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Data riil berdasarkan Tujuan Pembelajaran yang ditambahkan guru dan ketuntasan tugas murid
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold font-mono px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                    {tujuanPembelajaranList.length} TP Terdaftar
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setNavSubTab('tp');
                      setActiveBottomTab('navigasi');
                    }}
                    className="px-3 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs cursor-pointer transition-all active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Kelola TP</span>
                  </button>
                </div>
              </div>

              {/* Filter Subjek/Mapel jika guru mengampu beberapa mapel */}
              {tujuanPembelajaranList.length > 0 && subjects.length > 1 && (
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setProfilTpSubjectFilter('all')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      profilTpSubjectFilter === 'all'
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Semua Mapel ({tujuanPembelajaranList.length})
                  </button>
                  {subjects.map((sub) => {
                    const count = tujuanPembelajaranList.filter((tp) => tp.subjectId === sub.id).length;
                    if (count === 0) return null;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => setProfilTpSubjectFilter(sub.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                          profilTpSubjectFilter === sub.id
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {sub.name} ({count})
                      </button>
                    );
                  })}
                </div>
              )}

              {tujuanPembelajaranList.length === 0 ? (
                <div className="text-center py-10 px-4 bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-3">
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-800">Belum Ada Tujuan Pembelajaran yang Ditambahkan</h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                      Silakan tambahkan Tujuan Pembelajaran (TP) untuk mata pelajaran dan kelas Anda melalui menu Kelola TP.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setNavSubTab('tp');
                      setActiveBottomTab('navigasi');
                    }}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tambah Tujuan Pembelajaran (TP)</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3.5">
                  {tujuanPembelajaranList
                    .filter(
                      (tp) => profilTpSubjectFilter === 'all' || tp.subjectId === profilTpSubjectFilter,
                    )
                    .map((tp) => {
                      const subject = subjects.find((s) => s.id === tp.subjectId);
                      const metric = calculateTpMetric(tp);

                      const badgeStyle =
                        metric.statusText === 'Optimal'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : metric.statusText === 'Cukup'
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : metric.statusText === 'Perlu Pendampingan'
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200';

                      const progressColor =
                        metric.statusText === 'Optimal'
                          ? 'from-emerald-500 to-teal-500'
                          : metric.statusText === 'Cukup'
                          ? 'from-blue-500 to-indigo-600'
                          : metric.statusText === 'Perlu Pendampingan'
                          ? 'from-amber-500 to-orange-500'
                          : 'from-slate-400 to-slate-500';

                      return (
                        <div
                          key={tp.id}
                          className="p-4 sm:p-5 bg-slate-50/80 hover:bg-indigo-50/20 rounded-2xl border border-slate-200 transition-colors space-y-3"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                            <div className="space-y-1.5 flex-1 min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-mono font-bold text-xs text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-md border border-indigo-200/60">
                                  {tp.code}
                                </span>
                                {subject && (
                                  <span className="text-[11px] font-semibold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                                    {subject.name}
                                  </span>
                                )}
                                {tp.allocatedJp && (
                                  <span className="text-[10px] font-mono text-slate-500 bg-white border border-slate-200 px-1.5 py-0.5 rounded flex items-center gap-1">
                                    <Clock className="w-3 h-3 text-slate-400" />
                                    {tp.allocatedJp} JP ({tp.timeAllocationMinutes || tp.allocatedJp * 45}m)
                                  </span>
                                )}
                                {tp.targetMissionCount && (
                                  <span className="text-[10px] font-mono text-slate-500 bg-white border border-slate-200 px-1.5 py-0.5 rounded flex items-center gap-1">
                                    <Layers className="w-3 h-3 text-emerald-500" />
                                    {tp.targetMissionCount} Misi
                                  </span>
                                )}
                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${badgeStyle}`}>
                                  {metric.statusText}
                                </span>
                              </div>

                              <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
                                {tp.title}
                              </h4>

                              {tp.description && (
                                <p className="text-[11px] text-slate-600 line-clamp-2 leading-relaxed">
                                  {tp.description}
                                </p>
                              )}
                            </div>

                            <div className="text-left sm:text-right shrink-0">
                              <div className="flex sm:flex-col items-baseline sm:items-end gap-2 sm:gap-0">
                                <span className="font-mono text-lg sm:text-xl font-black text-slate-900">
                                  {metric.percentage}%
                                </span>
                                <span className="text-[11px] font-mono text-slate-500 font-medium">
                                  KKTP: {metric.targetKktp}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Progress Bar Ketercapaian */}
                          <div className="space-y-1">
                            <div className="h-2.5 bg-slate-200 rounded-full overflow-hidden">
                              <div
                                className={`h-full bg-gradient-to-r ${progressColor} rounded-full transition-all duration-500`}
                                style={{ width: `${metric.percentage}%` }}
                              />
                            </div>
                          </div>

                          {/* Rincian Ketercapaian Riil Murid */}
                          <div className="pt-2 border-t border-slate-200/60 grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
                            <div className="flex items-center gap-1.5 text-slate-600">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span>
                                Ketuntasan: <strong>{metric.tuntasCount} / {metric.totalStudents} Murid</strong>
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 text-slate-600">
                              <TrendingUp className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                              <span>
                                Rata-rata Skor: <strong>{metric.avgScore > 0 ? `${metric.avgScore}/100` : (metric.submittedStudentsCount > 0 ? 'Menunggu Penilaian' : 'Belum Ada Tugas')}</strong>
                              </span>
                            </div>
                            <div className="col-span-2 sm:col-span-1 flex items-center gap-1.5 text-slate-500">
                              <span>Target KKTP: Nilai Minimal <strong>{metric.targetKktp}</strong></span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Fixed Bottom Navigation */}
      <GuruBottomNav activeTab={activeBottomTab} onTabChange={setActiveBottomTab} />

      {/* Modal Bagi Kelompok Siswa (Kelompok 1-5) */}
      {showBagiKelompokModal && (
        <BagiKelompokModal
          isOpen={showBagiKelompokModal}
          onClose={() => setShowBagiKelompokModal(false)}
          classNameTitle={currentClass?.className || 'Kelas'}
          students={classStudents}
          onSaved={() => {
            refreshData();
          }}
        />
      )}
      </div>
    </div>
  );
};
