import React from 'react';
import {
  Home,
  Compass,
  User,
} from 'lucide-react';

export type GuruTabType = 'beranda' | 'navigasi' | 'profil';

interface GuruBottomNavProps {
  activeTab: GuruTabType;
  onTabChange: (tab: GuruTabType) => void;
}

export const GuruBottomNav: React.FC<GuruBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  // Hanya 3 Menu Utama: Beranda, Navigasi Guru, Profil
  const tabs = [
    {
      id: 'beranda' as GuruTabType,
      label: 'Beranda',
      icon: Home,
      accentColor: 'from-blue-600 to-indigo-600',
      activeColor: 'text-blue-600',
      activeBg: 'bg-blue-50 text-blue-600',
    },
    {
      id: 'navigasi' as GuruTabType,
      label: 'Navigasi Guru',
      icon: Compass,
      accentColor: 'from-indigo-600 to-purple-600',
      activeColor: 'text-indigo-600',
      activeBg: 'bg-indigo-50 text-indigo-600',
    },
    {
      id: 'profil' as GuruTabType,
      label: 'Profil',
      icon: User,
      accentColor: 'from-purple-600 to-pink-600',
      activeColor: 'text-purple-600',
      activeBg: 'bg-purple-50 text-purple-600',
    },
  ];

  return (
    <nav
      id="guru-bottom-navigation"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 9999,
        paddingBottom: 'env(safe-area-inset-bottom, 8px)',
      }}
      className="bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-2xl transition-all"
    >
      <div className="max-w-md mx-auto px-4 py-1.5 flex items-center justify-around gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              id={`btn-guru-tab-${tab.id}`}
              onClick={() => onTabChange(tab.id)}
              className={`flex-1 max-w-[130px] min-h-[48px] py-1 px-2 flex flex-col items-center justify-center gap-1 rounded-2xl transition-all relative select-none active:scale-95 ${
                isActive
                  ? `${tab.activeColor} font-bold`
                  : 'text-slate-400 hover:text-slate-600 font-medium'
              }`}
            >
              {isActive && (
                <span className={`absolute -top-1.5 w-8 h-1 rounded-full bg-gradient-to-r ${tab.accentColor}`} />
              )}
              <div
                className={`w-12 h-7 rounded-xl flex items-center justify-center transition-all ${
                  isActive ? tab.activeBg : 'text-slate-500 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span className="text-xs leading-tight tracking-tight whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

