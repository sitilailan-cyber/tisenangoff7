export interface GameContentData {
  subjectName: string;
  topicTitle: string;
  isAiGenerated: boolean;
  cards: Array<{ pairId: number; text: string }>;
  puzzleTarget: string[];
  puzzleInitial: string[];
  raceQuestions: Array<{
    q: string;
    options: string[];
    correct: number;
  }>;
  triviaQuestions: Array<{
    q: string;
    options: string[];
    correct: number;
  }>;
  snakeMessages: {
    ladder1: string;
    ladder2: string;
    snake1: string;
    snake2: string;
  };
}

// Fallback cerdas berdasarkan Mata Pelajaran & Topik jika offline / tanpa API key
export function getOfflineGameContent(subjectName = 'Fisika', topicTitle = 'Kalor & Termodinamika'): GameContentData {
  const sLower = subjectName.toLowerCase();
  const tLower = topicTitle.toLowerCase();

  // 1. MATEMATIKA
  if (sLower.includes('matematika') || tLower.includes('aljabar') || tLower.includes('regresi') || tLower.includes('fungsi') || tLower.includes('statistika')) {
    return {
      subjectName: 'Matematika',
      topicTitle: topicTitle || 'Regresi Linear & Statistika Terapan',
      isAiGenerated: false,
      cards: [
        { pairId: 1, text: '📈 Model Regresi Linear' },
        { pairId: 1, text: '📐 ŷ = a + bx' },
        { pairId: 2, text: '🎯 Koefisien Korelasi (r)' },
        { pairId: 2, text: '🔗 Derajat Keeratan Hubungan' },
        { pairId: 3, text: '📊 Determinasi (R²)' },
        { pairId: 3, text: '✨ Proporsi Variasi Variabel Terikat' },
        { pairId: 4, text: '📍 Titik Pusat Data' },
        { pairId: 4, text: '⚖️ Rata-rata (x̄, ȳ)' },
      ],
      puzzleTarget: ['ŷ', '=', 'a', '+', 'b', '·', 'x'],
      puzzleInitial: ['·', 'b', 'x', '=', 'ŷ', '+', 'a'],
      raceQuestions: [
        {
          q: 'Pada persamaan garis regresi ŷ = 2x + 5, jika nilai x = 4 maka prediksi ŷ adalah...',
          options: ['13', '10', '15'],
          correct: 0,
        },
        {
          q: 'Jika koefisien korelasi r = -0.92, hubungan antara kedua variabel adalah...',
          options: ['Sangat kuat dan berbanding terbalik', 'Lemah dan searah', 'Tidak memiliki hubungan linier'],
          correct: 0,
        },
        {
          q: 'Metode standar untuk menentukan garis regresi terbaik dinamakan...',
          options: ['Metode Kuadrat Terkecil (Least Squares)', 'Metode Interpolasi Lagrange', 'Metode Pembagian Rata-rata'],
          correct: 0,
        },
      ],
      triviaQuestions: [
        {
          q: 'Apa interpretasi dari nilai determinasi R² = 0.85 dalam analisis regresi data sains?',
          options: [
            '85% variasi variabel terikat dapat dijelaskan oleh model regresi',
            'Tingkat kesalahan prediksi mencapai 85%',
            'Hubungan variabel bersifat acak sebesar 85%',
          ],
          correct: 0,
        },
        {
          q: 'Titik koordinat yang dipastikan selalu dilewati oleh garis regresi linear terbaik adalah...',
          options: ['(x̄, ȳ) atau titik rata-rata', '(0, 0) atau titik asal', '(1, 1) atau titik satuan'],
          correct: 0,
        },
      ],
      snakeMessages: {
        ladder1: '🪜 Tangga Matematika! Anda teliti menghitung gradien regresi b, naik ke kotak 10!',
        ladder2: '🪜 Tangga Logika! Korelasi data bernilai kuat dan akurat, naik ke kotak 15!',
        snake1: '🐍 Ular Tantangan! Keliru menghitung nilai kuadrat residu, turun ke kotak 7!',
        snake2: '🐍 Ular Tantangan! Tertukar antara variabel bebas (x) dan terikat (y), turun ke kotak 11!',
      },
    };
  }

  // 2. KIMIA
  if (sLower.includes('kimia') || tLower.includes('reaksi') || tLower.includes('larutan') || tLower.includes('asam') || tLower.includes('stoikiometri')) {
    return {
      subjectName: 'Kimia',
      topicTitle: topicTitle || 'Laju Reaksi & Termokimia',
      isAiGenerated: false,
      cards: [
        { pairId: 1, text: '🧪 Reaksi Eksoterm' },
        { pairId: 1, text: '🔥 ΔH < 0 (Melepas Kalor)' },
        { pairId: 2, text: '❄️ Reaksi Endoterm' },
        { pairId: 2, text: '🌡️ ΔH > 0 (Menyerap Kalor)' },
        { pairId: 3, text: '⚡ Katalisator' },
        { pairId: 3, text: '📉 Menurunkan Energi Aktivasi (Ea)' },
        { pairId: 4, text: '⚖️ Hukum Kekekalan Massa' },
        { pairId: 4, text: '🔬 Lavoisier' },
      ],
      puzzleTarget: ['ΔH', '=', 'H_produk', '-', 'H_reaktan'],
      puzzleInitial: ['H_reaktan', '-', 'ΔH', '=', 'H_produk'],
      raceQuestions: [
        {
          q: 'Reaksi kimia yang melepaskan kalor ke lingkungan disebut reaksi...',
          options: ['Eksoterm', 'Endoterm', 'Sublimasi'],
          correct: 0,
        },
        {
          q: 'Zat yang mempercepat laju reaksi tanpa ikut habis bereaksi disebut...',
          options: ['Katalis', 'Indikator', 'Inhibitor'],
          correct: 0,
        },
        {
          q: 'Kenaikan suhu umumnya mempercepat laju reaksi kimia karena...',
          options: ['Frekuensi tumbukan efektif partikel meningkat', 'Energi aktivasi bertambah besar', 'Jumlah mol reaktan berkurang'],
          correct: 0,
        },
      ],
      triviaQuestions: [
        {
          q: 'Pada calorimeter sederhana, kalor reaksi larutan dihitung dengan persamaan...',
          options: ['q = m · c · ΔT', 'q = P · V · T', 'q = n · R · T'],
          correct: 0,
        },
        {
          q: 'Larutan dengan pH 3 diklasifikasikan sebagai larutan bersifat...',
          options: ['Asam kuat', 'Basa kuat', 'Netral'],
          correct: 0,
        },
      ],
      snakeMessages: {
        ladder1: '🪜 Tangga Kimia! Penyetaraan koefisien reaksi sempurna, naik ke kotak 10!',
        ladder2: '🪜 Tangga Lab! Pengukuran suhu kalorimeter sangat presisi, naik ke kotak 15!',
        snake1: '🐍 Ular Tantangan! Lupa menghitung kapasitas kalor kalorimeter, turun ke kotak 7!',
        snake2: '🐍 Ular Tantangan! Salah mengidentifikasi tanda minus entalpi ΔH, turun ke kotak 11!',
      },
    };
  }

  // 3. BIOLOGI
  if (sLower.includes('biologi') || tLower.includes('sel') || tLower.includes('fotosintesis') || tLower.includes('ekosistem') || tLower.includes('genetika')) {
    return {
      subjectName: 'Biologi',
      topicTitle: topicTitle || 'Metabolisme & Ekosistem Terapan',
      isAiGenerated: false,
      cards: [
        { pairId: 1, text: '🌿 Fotosintesis' },
        { pairId: 1, text: '☀️ 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂' },
        { pairId: 2, text: '⚡ Mitokondria' },
        { pairId: 2, text: '🔋 Respirasi Seluler (ATP)' },
        { pairId: 3, text: '🧬 DNA' },
        { pairId: 3, text: '🔬 Materi Genetik & Hereditas' },
        { pairId: 4, text: '🌱 Klorofil' },
        { pairId: 4, text: '🎨 Pigmen Penyerap Cahaya' },
      ],
      puzzleTarget: ['CO₂', '+', 'H₂O', '→', 'Glukosa', '+', 'O₂'],
      puzzleInitial: ['O₂', '+', 'Glukosa', '→', 'H₂O', '+', 'CO₂'],
      raceQuestions: [
        {
          q: 'Organel sel yang berfungsi sebagai tempat fotosintesis adalah...',
          options: ['Kloroplas', 'Ribosom', 'Badan Golgi'],
          correct: 0,
        },
        {
          q: 'Gas yang diserap tanaman pada reaksi terang fotosintesis adalah...',
          options: ['Karbon dioksida (CO₂)', 'Oksigen (O₂)', 'Nitrogen (N₂)'],
          correct: 0,
        },
        {
          q: 'Hubungan timbal balik antara makhluk hidup dengan lingkungannya disebut...',
          options: ['Ekosistem', 'Habitat', 'Biosfer'],
          correct: 0,
        },
      ],
      triviaQuestions: [
        {
          q: 'Faktor eksternal yang paling mempengaruhi laju fotosintesis adalah...',
          options: ['Intensitas cahaya, konsentrasi CO₂, dan suhu', 'Kelembaban tanah saja', 'Warna pot tanaman'],
          correct: 0,
        },
        {
          q: 'Dalam rantai makanan, tumbuhan hijau bertindak sebagai...',
          options: ['Produsen', 'Konsumen primer', 'Dekomposer'],
          correct: 0,
        },
      ],
      snakeMessages: {
        ladder1: '🪜 Tangga Biologi! Berhasil mengidentifikasi pigmen klorofil kloroplas, naik ke kotak 10!',
        ladder2: '🪜 Tangga Sains Hayati! Memahami siklus transfer energi rantai makanan, naik ke kotak 15!',
        snake1: '🐍 Ular Tantangan! Tertukar antara fotosintesis dan respirasi aerob, turun ke kotak 7!',
        snake2: '🐍 Ular Tantangan! Salah membaca variabel intensitas lux cahaya, turun ke kotak 11!',
      },
    };
  }

  // 4. FISIKA & UMUM (Default Sains Termodinamika & Kalor)
  return {
    subjectName: 'Fisika',
    topicTitle: topicTitle || 'Kalor, Termodinamika & Regresi Sains',
    isAiGenerated: false,
    cards: [
      { pairId: 1, text: '📈 Model Regresi Linear' },
      { pairId: 1, text: '📐 ŷ = mx + c' },
      { pairId: 2, text: '⚡ Kalor Termal' },
      { pairId: 2, text: '🔥 Q = m · c · ΔT' },
      { pairId: 3, text: '🎯 Koefisien Korelasi (r)' },
      { pairId: 3, text: '🔗 Keeratan Hubungan Data' },
      { pairId: 4, text: '📊 Nilai R²' },
      { pairId: 4, text: '✨ Proporsi Variasi Model' },
    ],
    puzzleTarget: ['Q', '=', 'm', '·', 'c', '·', 'ΔT'],
    puzzleInitial: ['·', 'ΔT', 'm', 'Q', '=', 'c', '·'],
    raceQuestions: [
      {
        q: 'Jika pemanasan 5 menit menaikkan suhu fluida 20°C, laju kenaikan per menit adalah...',
        options: ['4°C/menit', '2°C/menit', '5°C/menit'],
        correct: 0,
      },
      {
        q: 'Sensor digital untuk merekam suhu fluida cair secara real-time adalah...',
        options: ['Sensor Suhu Probe (DS18B20/NTC)', 'Sensor Barometer Gas', 'Sensor Fotodioda'],
        correct: 0,
      },
      {
        q: 'Pada Azas Black, hubungan pelepasan kalor (Q_lepas) dan penerimaan kalor (Q_terima) adalah...',
        options: ['Q_lepas = Q_terima', 'Q_lepas > Q_terima', 'Q_lepas = 2 × Q_terima'],
        correct: 0,
      },
    ],
    triviaQuestions: [
      {
        q: 'Korelasi negatif pada diagram pencar ditunjukkan dengan tren titik data...',
        options: ['Turun dari kiri ke kanan', 'Naik dari kiri ke kanan', 'Membentuk lingkaran simetris'],
        correct: 0,
      },
      {
        q: 'Kondisi kesetimbangan termal dua zat dalam kalorimeter dicapai saat...',
        options: ['Kedua zat memiliki suhu akhir yang sama', 'Massa kedua zat menjadi seimbang', 'Volume kedua zat melebur'],
        correct: 0,
      },
    ],
    snakeMessages: {
      ladder1: '🪜 Tangga Sains! Anda memahami konsep Azas Black, naik ke kotak 10!',
      ladder2: '🪜 Tangga Prestasi! Menemukan garis regresi linier terbaik, naik ke kotak 15!',
      snake1: '🐍 Ular Tantangan! Kurang teliti dalam membaca skala sensor suhu, turun ke kotak 7!',
      snake2: '🐍 Ular Tantangan! Satuan kalor belum dikonversi ke Joule, turun ke kotak 11!',
    },
  };
}

// Request AI Game Content dari Backend Gemini API dengan graceful fallback
export async function fetchAiGameContent(
  subjectName: string,
  topicTitle: string,
  topicDescription = ''
): Promise<GameContentData> {
  try {
    const response = await fetch('/api/ai/generate-game', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subject: subjectName,
        topic: topicTitle,
        description: topicDescription,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.cards && Array.isArray(data.cards) && data.cards.length >= 4) {
        return {
          ...data,
          isAiGenerated: Boolean(data.isAiGenerated ?? true),
        };
      }
    }
  } catch (err) {
    console.warn('Gagal memuat AI game content via backend, beralih ke generator cerdas lokal:', err);
  }

  // Intelligent fallback disesuaikan mata pelajaran
  return getOfflineGameContent(subjectName, topicTitle);
}
