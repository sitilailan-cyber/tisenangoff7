/**
 * TI SENANG - Joyful Game Music Synthesizer Engine
 * Web Audio API based joyful, uplifting background music loop for Misi 4 Game.
 * Plays continuously in a loop until the student closes/exits the mission.
 */

class JoyfulGameMusicEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private isMuted = false;
  private volume = 0.28;
  private masterGain: GainNode | null = null;
  private timerId: number | null = null;
  private step = 0;
  private onStateChangeListeners: Array<(playing: boolean, muted: boolean) => void> = [];

  // Cheerful C Major scale frequencies
  private noteFreq: Record<string, number> = {
    C3: 130.81, D3: 146.83, E3: 164.81, F3: 174.61, G3: 196.0, A3: 220.0, B3: 246.94,
    C4: 261.63, D4: 293.66, E4: 329.63, F4: 349.23, G4: 392.0, A4: 440.0, B4: 493.88,
    C5: 523.25, D5: 587.33, E5: 659.25, F5: 698.46, G5: 783.99, A5: 880.0, B5: 987.77,
    C6: 1046.5, D6: 1174.66, E6: 1318.51,
  };

  // 32-step uplifting joyful melody (16th notes / eighth notes)
  private melodyScore: (string | null)[] = [
    // Bar 1 (C)
    'E5', null, 'G5', 'A5', 'G5', null, 'E5', 'C5',
    // Bar 2 (G)
    'D5', null, 'B4', 'C5', 'D5', 'E5', 'D5', null,
    // Bar 3 (Am)
    'C5', 'D5', 'E5', 'G5', 'A5', null, 'G5', 'E5',
    // Bar 4 (F)
    'F5', 'G5', 'A5', 'C6', 'B5', 'A5', 'G5', 'F5',
    // Bar 5 (C)
    'E5', null, 'G5', 'C6', 'G5', 'E5', 'C5', 'E5',
    // Bar 6 (F)
    'A5', null, 'C6', 'D6', 'C6', null, 'A5', 'F5',
    // Bar 7 (G)
    'B5', 'C6', 'D6', 'G5', 'A5', 'B5', 'C6', 'D6',
    // Bar 8 (C Turnaround)
    'C6', null, 'G5', null, 'E5', 'G5', 'C6', null,
  ];

  // Cheerful bouncy bass line
  private bassScore: (string | null)[] = [
    // Bar 1 (C)
    'C3', null, 'G3', null, 'C3', null, 'E3', null,
    // Bar 2 (G)
    'G3', null, 'D3', null, 'G3', null, 'B3', null,
    // Bar 3 (Am)
    'A3', null, 'E3', null, 'A3', null, 'C3', null,
    // Bar 4 (F)
    'F3', null, 'C3', null, 'F3', null, 'A3', null,
    // Bar 5 (C)
    'C3', null, 'G3', null, 'C3', null, 'E3', null,
    // Bar 6 (F)
    'F3', null, 'C3', null, 'F3', null, 'A3', null,
    // Bar 7 (G)
    'G3', null, 'D3', null, 'G3', null, 'B3', null,
    // Bar 8 (C)
    'C3', null, 'G3', null, 'C3', null, 'C4', null,
  ];

  private initAudio() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
  }

  /**
   * Play single joyful synth bell tone
   */
  private playTone(freq: number, startTime: number, duration: number, isBass = false) {
    if (!this.ctx || !this.masterGain) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      if (isBass) {
        osc.type = 'triangle';
        gain.gain.setValueAtTime(0.18, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
      } else {
        // Bright playful marimba / bell tone
        osc.type = 'sine';
        // Add subtle harmonic sparkle
        gain.gain.setValueAtTime(0.22, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
      }

      osc.frequency.setValueAtTime(freq, startTime);
      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(startTime);
      osc.stop(startTime + duration);
    } catch {
      // Audio node scheduling guard
    }
  }

  /**
   * Play cheerful hi-hat / shaker tap on upbeat
   */
  private playHat(startTime: number) {
    if (!this.ctx || !this.masterGain) return;
    try {
      const bufferSize = this.ctx.sampleRate * 0.03; // 30ms noise
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.08;
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 6000;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.06, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.03);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(startTime);
    } catch {
      // Guard
    }
  }

  /**
   * Step through score at cheerful tempo (128 BPM -> 16th note ~117ms)
   */
  private tick = () => {
    if (!this.isPlaying || !this.ctx) return;

    const now = this.ctx.currentTime;
    const noteLength = 0.16;

    // 1. Play melody note if defined
    const melodyNote = this.melodyScore[this.step % this.melodyScore.length];
    if (melodyNote && this.noteFreq[melodyNote]) {
      this.playTone(this.noteFreq[melodyNote], now, noteLength, false);
    }

    // 2. Play bass note
    const bassNote = this.bassScore[this.step % this.bassScore.length];
    if (bassNote && this.noteFreq[bassNote]) {
      this.playTone(this.noteFreq[bassNote], now, noteLength * 1.5, true);
    }

    // 3. Play light joyful percussion swing
    if (this.step % 2 === 1) {
      this.playHat(now);
    }

    this.step++;
  };

  /**
   * Start playing joyful game music continuously in a loop
   */
  public start(): void {
    if (this.isPlaying) return;

    this.initAudio();

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    this.isPlaying = true;
    this.step = 0;
    this.notifyState();

    // 130 BPM (approx ~115ms per 16th step)
    this.timerId = window.setInterval(this.tick, 120);

    // Setup gesture resume if user hasn't clicked yet
    const resumeOnGesture = () => {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      window.removeEventListener('click', resumeOnGesture);
      window.removeEventListener('keydown', resumeOnGesture);
      window.removeEventListener('touchstart', resumeOnGesture);
    };

    window.addEventListener('click', resumeOnGesture, { once: true });
    window.addEventListener('keydown', resumeOnGesture, { once: true });
    window.addEventListener('touchstart', resumeOnGesture, { once: true });
  }

  /**
   * Stop music when game mission closes
   */
  public stop(): void {
    if (!this.isPlaying) return;

    this.isPlaying = false;
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }

    if (this.ctx) {
      try {
        if (this.ctx.state !== 'closed') {
          this.ctx.suspend().catch(() => {});
        }
      } catch {
        // Guard
      }
    }

    this.notifyState();
  }

  /**
   * Toggle mute
   */
  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    }
    this.notifyState();
    return this.isMuted;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Sound effect: Jawaban Benar (Cheerful rising chime)
   */
  public playCorrect(): void {
    if (this.isMuted) return;
    this.initAudio();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      [
        { f: 523.25, t: 0, d: 0.12 },
        { f: 659.25, t: 0.08, d: 0.12 },
        { f: 783.99, t: 0.16, d: 0.25 },
        { f: 1046.5, t: 0.24, d: 0.35 },
      ].forEach(({ f, t, d }) => {
        const osc = this.ctx!.createOscillator();
        const g = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now + t);
        g.gain.setValueAtTime(0.25, now + t);
        g.gain.exponentialRampToValueAtTime(0.001, now + t + d);
        osc.connect(g);
        g.connect(this.masterGain!);
        osc.start(now + t);
        osc.stop(now + t + d);
      });
    } catch {
      // Guard
    }
  }

  /**
   * Sound effect: Jawaban Salah (Gentle soft buzz/low note)
   */
  public playWrong(): void {
    if (this.isMuted) return;
    this.initAudio();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.25);
      g.gain.setValueAtTime(0.18, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // Guard
    }
  }

  /**
   * Sound effect: Kemenangan (Fanfare)
   */
  public playVictory(): void {
    if (this.isMuted) return;
    this.initAudio();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      [
        { f: 523.25, t: 0, d: 0.15 },
        { f: 659.25, t: 0.15, d: 0.15 },
        { f: 783.99, t: 0.3, d: 0.2 },
        { f: 1046.5, t: 0.5, d: 0.6 },
      ].forEach(({ f, t, d }) => {
        const osc = this.ctx!.createOscillator();
        const g = this.ctx!.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now + t);
        g.gain.setValueAtTime(0.3, now + t);
        g.gain.exponentialRampToValueAtTime(0.001, now + t + d);
        osc.connect(g);
        g.connect(this.masterGain!);
        osc.start(now + t);
        osc.stop(now + t + d);
      });
    } catch {
      // Guard
    }
  }

  public subscribe(fn: (playing: boolean, muted: boolean) => void): () => void {
    this.onStateChangeListeners.push(fn);
    fn(this.isPlaying, this.isMuted);
    return () => {
      this.onStateChangeListeners = this.onStateChangeListeners.filter((l) => l !== fn);
    };
  }

  private notifyState() {
    for (const fn of this.onStateChangeListeners) {
      fn(this.isPlaying, this.isMuted);
    }
  }
}

export const joyfulGameMusic = new JoyfulGameMusicEngine();
