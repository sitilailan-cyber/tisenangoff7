import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Safety guard against NotFoundError: Failed to execute 'removeChild' on 'Node'
// Caused when external scripts or DOM mutations alter React-managed nodes
if (typeof window !== 'undefined' && typeof Node !== 'undefined' && Node.prototype) {
  const originalRemoveChild = Node.prototype.removeChild;
  Node.prototype.removeChild = function <T extends Node>(child: T): T {
    if (child.parentNode !== this) {
      return child;
    }
    return originalRemoveChild.apply(this, [child]) as T;
  };

  const originalInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function <T extends Node>(newNode: T, referenceNode: Node | null): T {
    if (referenceNode && referenceNode.parentNode !== this) {
      if (this.contains(referenceNode)) {
        return originalInsertBefore.apply(this, [newNode, referenceNode]) as T;
      }
      return this.appendChild(newNode) as T;
    }
    return originalInsertBefore.apply(this, [newNode, referenceNode]) as T;
  };
}

createRoot(document.getElementById('root')!).render(<App />);

