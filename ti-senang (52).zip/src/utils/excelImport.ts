import * as XLSX from 'xlsx';
import { AsesmenAwalInput, Student } from '../types';
import { storage } from '../services/storage';
import { AlmeEngine } from '../services/alme/almeEngine';

export interface ParsedAsesmenRow {
  no?: number;
  rowNumber?: number;
  studentName: string;
  username?: string;
  diagnosticScore: number;
  readinessLevel: 'Siap Mandiri' | 'Berkembang' | 'Perlu Pendampingan';
  notes?: string;
  isExistingStudent?: boolean;
  matchedStudentId?: string;
  status: 'valid' | 'invalid' | 'error';
  errorMessage?: string;
}

/**
 * Unduh Template File Excel untuk Input Hasil Asesmen Awal
 * Format kolom disamakan 100% dengan formulir pengisian manual asesmen awal guru
 */
export function downloadAsesmenAwalTemplate(
  className: string,
  existingStudents: Array<{ id: string; name: string; username?: string }> = [],
): void {
  const headerInfo = [
    ['TI SENANG — TEMPLATE IMPORT HASIL ASESMEN AWAL DIAGNOSTIK'],
    ['Kelas Target', className],
    ['Tanggal Unduh', new Date().toLocaleDateString('id-ID')],
    [
      'Petunjuk Pengisian:',
      'Isi nama murid, nilai asesmen awal (angka 0 - 100), kesiapan belajar (Siap Mandiri / Berkembang / Perlu Pendampingan), dan catatan guru.',
    ],
    [],
    ['No', 'Nama Murid', 'Nilai Asesmen Awal', 'Kesiapan Belajar', 'Catatan Guru'],
  ];

  const studentRows =
    existingStudents.length > 0
      ? existingStudents.map((s, idx) => [
          idx + 1,
          s.name,
          '', // Kosongkan nilai agar diisi guru dengan angka 0-100
          'Berkembang', // Pilihan kesiapan: Siap Mandiri / Berkembang / Perlu Pendampingan
          'Murid terdaftar di kelas',
        ])
      : [
          [1, 'Ahmad Fauzan', 85, 'Siap Mandiri', 'Pemahaman konsep dasar sangat baik'],
          [2, 'Bella Anatasya', 74, 'Berkembang', 'Perlu penguatan aljabar sains'],
          [3, 'Citra Lestari', 65, 'Perlu Pendampingan', 'Perlu bimbingan intensif konsep dasar kalor'],
        ];

  const worksheet = XLSX.utils.aoa_to_sheet([...headerInfo, ...studentRows]);

  worksheet['!cols'] = [
    { wch: 6 },
    { wch: 28 },
    { wch: 20 },
    { wch: 22 },
    { wch: 36 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Asesmen Awal');

  const fileName = `Template_Asesmen_Awal_${className.replace(/\s+/g, '_')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Parsing file Excel / CSV yang diunggah guru
 * Memastikan nilai yang ada di file Excel 100% sama persis dengan yang tampil di aplikasi
 */
export async function parseAsesmenAwalExcel(
  file: File,
  currentClassStudents: Student[] = [],
): Promise<{ success: boolean; data: ParsedAsesmenRow[]; totalRows: number; error?: string }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });

    if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
      return { success: false, data: [], totalRows: 0, error: 'File Excel kosong atau tidak terbaca.' };
    }

    const firstSheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheetName];
    const rawRows = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1 });

    if (!rawRows || rawRows.length === 0) {
      return { success: false, data: [], totalRows: 0, error: 'Lembar kerja (sheet) tidak memiliki data.' };
    }

    // 1. Cari baris header kolom yang sebenarnya (harus memiliki indikator nama DAN nilai/skor di baris yang sama)
    let headerRowIndex = -1;
    let colNameIdx = -1;
    let colScoreIdx = -1;
    let colReadinessIdx = -1;
    let colUsernameIdx = -1;
    let colNotesIdx = -1;

    for (let r = 0; r < Math.min(rawRows.length, 25); r++) {
      const row = rawRows[r];
      if (!Array.isArray(row)) continue;

      let tempNameIdx = -1;
      let tempScoreIdx = -1;
      let tempReadinessIdx = -1;
      let tempUsernameIdx = -1;
      let tempNotesIdx = -1;

      for (let c = 0; c < row.length; c++) {
        const cell = String(row[c] || '').trim().toLowerCase();
        if (!cell || cell.length > 40) continue; // Abaikan banner judul panjang

        if (cell === 'nama' || cell === 'nama siswa' || cell === 'nama murid' || cell === 'name' || cell === 'student name') {
          tempNameIdx = c;
        } else if (tempNameIdx === -1 && (cell.includes('nama') || cell.includes('siswa') || cell.includes('murid'))) {
          tempNameIdx = c;
        }

        if (
          cell === 'nilai' ||
          cell === 'nilai asesmen awal' ||
          cell === 'skor' ||
          cell === 'skor diagnostik' ||
          cell === 'nilai asesmen' ||
          cell === 'score'
        ) {
          tempScoreIdx = c;
        } else if (
          tempScoreIdx === -1 &&
          (cell.includes('nilai') || cell.includes('skor') || cell.includes('diagnostik')) &&
          !cell.includes('laporan') &&
          !cell.includes('template')
        ) {
          tempScoreIdx = c;
        }

        if (cell.includes('kesiapan') || cell.includes('readiness') || cell.includes('level')) {
          tempReadinessIdx = c;
        }
        if (cell.includes('username') || cell.includes('nisn') || cell.includes('nis')) {
          tempUsernameIdx = c;
        }
        if (cell.includes('catatan') || cell.includes('notes') || cell.includes('keterangan')) {
          tempNotesIdx = c;
        }
      }

      // Validasi baris ini benar-benar header tabel jika memiliki nama DAN skor
      if (tempNameIdx !== -1 && tempScoreIdx !== -1) {
        headerRowIndex = r;
        colNameIdx = tempNameIdx;
        colScoreIdx = tempScoreIdx;
        colReadinessIdx = tempReadinessIdx;
        colUsernameIdx = tempUsernameIdx;
        colNotesIdx = tempNotesIdx;
        break;
      }
    }

    // Fallback jika tidak ada header terdeteksi secara otomatis: asumsikan kolom 1 nama, kolom 2 skor
    if (headerRowIndex === -1) {
      headerRowIndex = 0;
      colNameIdx = 1;
      colScoreIdx = 2;
      colReadinessIdx = 3;
      colNotesIdx = 4;
    }

    const parsedResults: ParsedAsesmenRow[] = [];

    for (let r = headerRowIndex + 1; r < rawRows.length; r++) {
      const row = rawRows[r];
      if (!Array.isArray(row) || row.length === 0) continue;

      const rawName = String(row[colNameIdx] ?? '').trim();
      const rawScore = row[colScoreIdx];
      const rawReadiness = colReadinessIdx !== -1 ? String(row[colReadinessIdx] ?? '').trim() : '';
      const rawUsername = colUsernameIdx !== -1 ? String(row[colUsernameIdx] ?? '').trim() : '';
      const rawNotes = colNotesIdx !== -1 ? String(row[colNotesIdx] ?? '').trim() : '';

      // Lewati baris kosong atau baris teks metadata
      if (!rawName || rawName.toLowerCase().startsWith('ti senang') || rawName.toLowerCase().startsWith('kelas')) {
        continue;
      }

      let parsedScore: number | null = null;
      if (typeof rawScore === 'number' && !isNaN(rawScore)) {
        parsedScore = rawScore;
      } else if (typeof rawScore === 'string') {
        const cleanScoreStr = rawScore.replace(',', '.').replace(/[^0-9.]/g, '');
        const n = parseFloat(cleanScoreStr);
        if (!isNaN(n)) parsedScore = n;
      }

      if (parsedScore === null || isNaN(parsedScore) || parsedScore < 0) {
        parsedResults.push({
          studentName: rawName,
          username: rawUsername,
          diagnosticScore: 0,
          readinessLevel: 'Perlu Pendampingan',
          notes: rawNotes,
          status: 'invalid',
          errorMessage: 'Nilai tidak valid (harus angka 0 - 100).',
        });
        continue;
      }

      // Pastikan rentang skor 0 - 100 persis sesuai angka di Excel
      parsedScore = Math.min(100, Math.max(0, Math.round(parsedScore)));

      let readinessLevel: 'Siap Mandiri' | 'Berkembang' | 'Perlu Pendampingan';
      const rLower = rawReadiness.toLowerCase();
      if (rLower.includes('siap') || rLower.includes('mandiri')) {
        readinessLevel = 'Siap Mandiri';
      } else if (rLower.includes('damping') || rLower.includes('perlu')) {
        readinessLevel = 'Perlu Pendampingan';
      } else if (rLower.includes('kembang')) {
        readinessLevel = 'Berkembang';
      } else {
        // Otomatis hitung jika kosong
        if (parsedScore >= 85) {
          readinessLevel = 'Siap Mandiri';
        } else if (parsedScore >= 70) {
          readinessLevel = 'Berkembang';
        } else {
          readinessLevel = 'Perlu Pendampingan';
        }
      }

      // Cek apakah siswa sudah terdaftar di kelas
      const matched = currentClassStudents.find(
        (s) =>
          (s.name && s.name.trim().toLowerCase() === rawName.toLowerCase()) ||
          (rawUsername && (s as any).username?.toLowerCase() === rawUsername.toLowerCase()) ||
          (rawUsername && (s as any).user?.username?.toLowerCase() === rawUsername.toLowerCase()),
      );

      parsedResults.push({
        no: parsedResults.length + 1,
        studentName: rawName,
        username: rawUsername,
        diagnosticScore: parsedScore,
        readinessLevel,
        notes: rawNotes,
        isExistingStudent: !!matched,
        matchedStudentId: matched?.id,
        status: 'valid',
      });
    }

    return {
      success: true,
      data: parsedResults,
      totalRows: parsedResults.length,
    };
  } catch (err: any) {
    return {
      success: false,
      data: [],
      totalRows: 0,
      error: `Gagal membaca file Excel: ${err?.message || 'Format tidak didukung.'}`,
    };
  }
}

/**
 * Simpan seluruh hasil parsing Excel ke Database (localStorage + Firebase RTDB)
 */
export function commitAsesmenAwalImport(
  parsedRows: ParsedAsesmenRow[],
  classId: string,
  subjectId: string,
): { importedCount: number; newStudentsCount: number } {
  let importedCount = 0;
  let newStudentsCount = 0;

  const validRows = parsedRows.filter((r) => r.status === 'valid');

  validRows.forEach((row) => {
    let studentId = row.matchedStudentId;

    // Jika siswa belum terdaftar, otomatis buat akun & siswa di database
    if (!studentId) {
      const generatedUsername = (row.username || row.studentName)
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '')
        .slice(0, 15) || `siswa${Date.now().toString().slice(-4)}`;

      const newStudent = storage.addStudent(
        row.studentName,
        generatedUsername,
        classId,
        'siswa123',
      );
      studentId = newStudent.id;
      newStudentsCount++;
    }

    // ALME Engine menghitung literasi & numerasi dari skor diagnostik
    const derivedLit = storage.calculateStudentLiteracy(studentId, row.diagnosticScore);
    const derivedNum = storage.calculateStudentNumeracy(studentId, row.diagnosticScore);
    const derivedReas = Math.round((derivedLit + derivedNum) / 2);

    const almeRec = AlmeEngine.analyze({
      assessmentResult: row.diagnosticScore,
      literacy: derivedLit,
      numeracy: derivedNum,
      reasoning: derivedReas,
    });

    storage.saveAlmeRecommendation(studentId, almeRec);

    const record: AsesmenAwalInput = {
      id: `asw-${studentId}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentId,
      studentName: row.studentName,
      classId,
      subjectId,
      diagnosticScore: row.diagnosticScore,
      literacyScore: derivedLit,
      numeracyScore: derivedNum,
      reasoningScore: derivedReas,
      readinessLevel: row.readinessLevel,
      notes: row.notes || 'Hasil import Excel asesmen awal murid.',
      createdAt: new Date().toISOString(),
      almeRecommendationId: almeRec.recommendedMissionId,
    };

    storage.saveAsesmenAwal(record);
    importedCount++;
  });

  // Siarkan event pembaruan ke seluruh aplikasi
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('tisenang_asesmen_awal_updated'));
    window.dispatchEvent(new CustomEvent('tisenang_students_updated'));
    window.dispatchEvent(new CustomEvent('tisenang_alme_updated'));
  }

  return { importedCount, newStudentsCount };
}
